package fr.block2block.core.commands.rank;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Gere /rankup et /rank (set/info/top).
 */
public class RankCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public RankCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("rankup")) {
            return handleRankup(sender);
        }
        return handleRank(sender, args);
    }

    private boolean handleRankup(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getRankupGUI().open(player);
        return true;
    }

    private boolean handleRank(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /rank <set|info|top>"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "set" -> handleSet(sender, args);
            case "info" -> handleInfo(sender, args);
            case "top" -> handleTop(sender);
            default -> sender.sendMessage(TextUtil.parse("<yellow>Usage : /rank <set|info|top>"));
        }
        return true;
    }

    private void handleSet(CommandSender sender, String[] args) {
        // Permission dediee et distincte de "block2core.command.rank" (accordee a tous par
        // defaut pour /rankup, /rank info, /rank top) : sans cela, n'importe quel joueur
        // pouvait s'auto-promouvoir Partenaire via /rank set.
        if (!sender.hasPermission("block2core.command.rank.set")) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("no-permission", null));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /rank set <joueur> <grade>"));
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return;
        }
        Grade grade = Grade.fromKey(args[2]);
        if (grade == null) {
            sender.sendMessage(TextUtil.parse("<red>Grade invalide. Grades valides : paysan, aventurier, aguerris, master, partenaire"));
            return;
        }
        plugin.getRankManager().setGrade(target.getUniqueId(), grade, () -> {
            sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " est maintenant " +
                    plugin.getConfigManager().gradeDisplayName(grade)));
            target.sendMessage(TextUtil.parse("<green>Ton grade a ete change en " + plugin.getConfigManager().gradeDisplayName(grade)));
            plugin.getDisplayManager().applyTabSort(target, plugin.getPlayerData(target.getUniqueId()));
            plugin.getDisplayManager().refreshScoreboard(target);
        });
    }

    private void handleInfo(CommandSender sender, String[] args) {
        String targetName = args.length > 1 ? args[1] : (sender instanceof Player p ? p.getName() : null);
        if (targetName == null) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /rank info <joueur>"));
            return;
        }
        plugin.getRankManager().getGradeInfo(targetName, info -> {
            if (info == null) {
                sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-found", java.util.Map.of("joueur", targetName)));
                return;
            }
            sender.sendMessage(TextUtil.parse("<aqua><bold>--- " + info.name() + " ---"));
            sender.sendMessage(TextUtil.parse("<gray>Grade : " + plugin.getConfigManager().gradeDisplayName(info.grade())));
            if (info.staffRank() != null) {
                sender.sendMessage(TextUtil.parse("<gray>Staff : " + plugin.getConfigManager().staffDisplayName(info.staffRank())));
            }
            sender.sendMessage(TextUtil.parse("<gray>Playtime : <white>" + TimeUtil.formatHoursMinutes(info.playtimeSeconds())));
            sender.sendMessage(TextUtil.parse("<gray>Solde : <gold>" + (long) info.balance() + " Block2Coins"));
        });
    }

    private void handleTop(CommandSender sender) {
        plugin.getRankManager().getTop(10, list -> {
            sender.sendMessage(TextUtil.parse("<aqua><bold>--- TOP 10 GRADES ---"));
            int position = 1;
            for (var entry : list) {
                sender.sendMessage(TextUtil.parse("<gray>#" + position + " <white>" + entry.name() + " <gray>- " +
                        plugin.getConfigManager().gradeDisplayName(entry.grade())));
                position++;
            }
        });
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("rank")) {
            if (args.length == 1) {
                return filter(List.of("set", "info", "top"), args[0]);
            }
            if (args.length == 2 && (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("info"))) {
                return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
            }
            if (args.length == 3 && args[0].equalsIgnoreCase("set")) {
                return filter(List.of("paysan", "aventurier", "aguerris", "master", "partenaire"), args[2]);
            }
        }
        return new ArrayList<>();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
