package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.TagDefinition;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Interface pour /tag : liste tous les tags du registre (voir TagManager) - qu'ils viennent
 * d'une recompense de quete ou d'un tag cree par le staff pour un evenement (/tagadmin) -
 * debloques ou non, et permet d'en equiper un, ou de n'en afficher aucun. Les tags non
 * debloques sont affiches verrouilles avec leur description en indice, pour motiver le joueur.
 */
public class TagGUI implements Listener {

    private static final int NONE_SLOT = 0;
    private static final String NONE_KEY = "__none__";

    private final Block2Core plugin;

    public TagGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerData data = plugin.getPlayerData(uuid);
        if (data == null) return;

        Set<String> unlocked = plugin.getTagManager().getUnlockedTags(uuid);
        String active = data.getTitle();

        List<TagDefinition> tags = plugin.getTagManager().getAllTags().stream()
                .sorted(Comparator.comparing(TagDefinition::name, String.CASE_INSENSITIVE_ORDER))
                .toList();

        int size = Math.max(27, ((tags.size() + 1 + 8) / 9) * 9);
        Map<Integer, String> slotMap = new HashMap<>();
        Inventory inventory = plugin.getServer().createInventory(new TagHolder(slotMap), size,
                TextUtil.parse("<light_purple><bold>Choisir mon tag"));

        ItemStack filler = new ItemBuilder(Material.PURPLE_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < size; i++) {
            inventory.setItem(i, filler);
        }

        inventory.setItem(NONE_SLOT, buildNoneItem(active));
        slotMap.put(NONE_SLOT, NONE_KEY);

        int slot = 1;
        for (TagDefinition tag : tags) {
            if (slot >= size) break;
            boolean isUnlocked = unlocked.stream().anyMatch(t -> t.equalsIgnoreCase(tag.name()));
            boolean isActive = tag.name().equalsIgnoreCase(active);
            inventory.setItem(slot, buildTagItem(tag, isUnlocked, isActive));
            slotMap.put(slot, tag.name());
            slot++;
        }

        player.openInventory(inventory);
    }

    private ItemStack buildNoneItem(String active) {
        boolean isActive = active == null || active.isBlank();
        return new ItemBuilder(Material.BARRIER)
                .glow(isActive)
                .name(isActive ? "<white><bold>Aucun tag <gray>(actif)" : "<white>Aucun tag")
                .loreLine("<gray>Ne rien afficher devant ton pseudo.")
                .build();
    }

    private ItemStack buildTagItem(TagDefinition tag, boolean unlocked, boolean active) {
        if (!unlocked) {
            ItemBuilder builder = new ItemBuilder(Material.GRAY_DYE)
                    .name("<dark_gray>??? <gray>(verrouille)")
                    .loreLine("<dark_gray>🔒 Non debloque");
            if (tag.description() != null && !tag.description().isBlank()) {
                builder.loreLine("<gray>" + tag.description());
            }
            return builder.build();
        }
        ItemBuilder builder = new ItemBuilder(active ? Material.NAME_TAG : Material.PAPER)
                .glow(active)
                .name(plugin.getTagManager().formatTag(tag.name()));
        if (tag.description() != null && !tag.description().isBlank()) {
            builder.loreLine("<gray>" + tag.description()).loreLine(" ");
        }
        builder.loreLine(active ? "<yellow>➡ Actuellement affiche" : "<gray>Clique pour afficher ce tag");
        return builder.build();
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof TagHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !(event.getClickedInventory().getHolder() instanceof TagHolder)) return;

        String key = holder.tagAt(event.getSlot());
        if (key == null) return;
        Player player = (Player) event.getWhoClicked();

        boolean success = plugin.getTagManager().setActiveTitle(player, key.equals(NONE_KEY) ? null : key);
        if (success) {
            player.sendMessage(TextUtil.parse(key.equals(NONE_KEY) ? "<green>Tag retire." : "<green>Tag mis a jour !"));
            Bukkit.getScheduler().runTask(plugin, () -> open(player));
        } else {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas encore debloque ce tag."));
        }
    }

    public static class TagHolder implements InventoryHolder {
        private final Map<Integer, String> slotMap;

        public TagHolder(Map<Integer, String> slotMap) {
            this.slotMap = slotMap;
        }

        public String tagAt(int slot) {
            return slotMap.get(slot);
        }

        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
