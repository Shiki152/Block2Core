package fr.block2block.core;

import fr.block2block.core.commands.auth.AuthCommand;
import fr.block2block.core.commands.claims.ClaimCommand;
import fr.block2block.core.commands.claims.UnescoCommand;
import fr.block2block.core.commands.economy.B2CAdminCommand;
import fr.block2block.core.commands.economy.CoinflipCommand;
import fr.block2block.core.commands.economy.EconomyCommand;
import fr.block2block.core.commands.economy.ShopCommand;
import fr.block2block.core.commands.help.HelpCommand;
import fr.block2block.core.commands.info.InfoCommand;
import fr.block2block.core.commands.kit.KitCommand;
import fr.block2block.core.commands.moderation.MaintenanceCommand;
import fr.block2block.core.commands.moderation.PunishmentCommand;
import fr.block2block.core.commands.moderation.StaffAdvancedCommand;
import fr.block2block.core.commands.moderation.StaffModeCommand;
import fr.block2block.core.commands.moderation.StaffToolCommand;
import fr.block2block.core.commands.qol.SocialCommand;
import fr.block2block.core.commands.qol.TeleportQolCommand;
import fr.block2block.core.commands.quest.QuestCommand;
import fr.block2block.core.commands.rank.PlaytimeCommand;
import fr.block2block.core.commands.rank.RankCommand;
import fr.block2block.core.commands.rank.StaffRankCommand;
import fr.block2block.core.commands.report.ReportCommand;
import fr.block2block.core.commands.report.ReportsAdminCommand;
import fr.block2block.core.commands.skin.SkinCommand;
import fr.block2block.core.commands.teams.TeamCommand;
import fr.block2block.core.commands.tutorial.TutorialCommand;
import fr.block2block.core.config.ConfigManager;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.database.DatabaseManager;
import fr.block2block.core.gui.HelpGUI;
import fr.block2block.core.gui.InvSeeGUI;
import fr.block2block.core.gui.ShopGUI;
import fr.block2block.core.listeners.AuthListener;
import fr.block2block.core.listeners.BlockLogListener;
import fr.block2block.core.listeners.ChatListener;
import fr.block2block.core.listeners.JoinQuitListener;
import fr.block2block.core.listeners.ProtectionListener;
import fr.block2block.core.listeners.QuestProgressListener;
import fr.block2block.core.listeners.TutorialListener;
import fr.block2block.core.managers.AuthManager;
import fr.block2block.core.managers.BedrockSupport;
import fr.block2block.core.managers.ChatModerationManager;
import fr.block2block.core.managers.ClaimManager;
import fr.block2block.core.managers.DisplayManager;
import fr.block2block.core.managers.EconomyManager;
import fr.block2block.core.managers.CacheCleanupManager;
import fr.block2block.core.managers.JailManager;
import fr.block2block.core.managers.KitManager;
import fr.block2block.core.managers.LocationManager;
import fr.block2block.core.managers.LogManager;
import fr.block2block.core.managers.PlayerStateManager;
import fr.block2block.core.managers.PlaytimeManager;
import fr.block2block.core.managers.PunishmentManager;
import fr.block2block.core.managers.QuestManager;
import fr.block2block.core.managers.RankManager;
import fr.block2block.core.managers.ReportManager;
import fr.block2block.core.managers.SocialManager;
import fr.block2block.core.managers.TeamManager;
import fr.block2block.core.managers.TutorialManager;
import fr.block2block.core.placeholder.Block2CorePlaceholders;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Classe principale du plugin Block2Core. Initialise l'ensemble des
 * managers, enregistre les listeners/commandes/GUIs et expose des accesseurs
 * utilises dans tout le plugin.
 */
public final class Block2Core extends JavaPlugin {

    private static Block2Core instance;

    private final Map<UUID, PlayerData> playerDataMap = new ConcurrentHashMap<>();

    // Config / DB
    private ConfigManager configManager;
    private DatabaseManager databaseManager;

    // Managers
    private RankManager rankManager;
    private PlaytimeManager playtimeManager;
    private EconomyManager economyManager;
    private KitManager kitManager;
    private TutorialManager tutorialManager;
    private QuestManager questManager;
    private ReportManager reportManager;
    private ClaimManager claimManager;
    private TeamManager teamManager;
    private LocationManager locationManager;
    private PunishmentManager punishmentManager;
    private AuthManager authManager;
    private PlayerStateManager playerStateManager;
    private JailManager jailManager;
    private CacheCleanupManager cacheCleanupManager;
    private SocialManager socialManager;
    private ChatModerationManager chatModerationManager;
    private LogManager logManager;
    private DisplayManager displayManager;
    private BedrockSupport bedrockSupport;

    // GUIs
    private HelpGUI helpGUI;
    private ShopGUI shopGUI;
    private InvSeeGUI invSeeGUI;

    // Listeners ayant besoin d'un start()/stop()
    private AuthListener authListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.configManager = new ConfigManager(this);
        this.databaseManager = new DatabaseManager(this);

        if (!databaseManager.connect()) {
            getLogger().severe("Initialisation de la base SQLite impossible, desactivation du plugin. Verifie la section 'database' de config.yml et les droits d'ecriture du dossier plugins/Block2Core.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        initManagers();
        initGuis();
        registerVaultEconomy();
        registerPlaceholderApi();
        registerListeners();
        registerCommands();
        startTasks();

        getLogger().info("Block2Core active avec succes.");
    }

    @Override
    public void onDisable() {
        if (playtimeManager != null) {
            for (var entry : playerDataMap.entrySet()) {
                playtimeManager.persistBlocking(entry.getKey(), entry.getValue().getPlaytimeSeconds());
            }
        }
        if (playtimeManager != null) playtimeManager.stop();
        if (playerStateManager != null) playerStateManager.stop();
        if (jailManager != null) jailManager.stop();
        if (cacheCleanupManager != null) cacheCleanupManager.stop();
        if (displayManager != null) displayManager.stop();
        if (authListener != null) authListener.stop();
        if (databaseManager != null) databaseManager.disconnect();
        getLogger().info("Block2Core desactive.");
    }

    private void initManagers() {
        this.rankManager = new RankManager(this);
        this.playtimeManager = new PlaytimeManager(this);
        this.economyManager = new EconomyManager(this);
        this.kitManager = new KitManager(this);
        this.tutorialManager = new TutorialManager(this);
        this.questManager = new QuestManager(this);
        this.reportManager = new ReportManager(this);
        this.claimManager = new ClaimManager(this);
        this.teamManager = new TeamManager(this);
        this.locationManager = new LocationManager(this);
        this.punishmentManager = new PunishmentManager(this);
        this.authManager = new AuthManager(this);
        this.playerStateManager = new PlayerStateManager(this);
        this.jailManager = new JailManager(this);
        this.cacheCleanupManager = new CacheCleanupManager(this);
        this.socialManager = new SocialManager(this);
        this.chatModerationManager = new ChatModerationManager();
        this.logManager = new LogManager(this);
        this.displayManager = new DisplayManager(this);
        this.bedrockSupport = new BedrockSupport(this);

        claimManager.loadAll(claimManager::protectSpawnChunks);
        teamManager.loadAll();
        locationManager.loadWarps();
        questManager.loadAllQuests();
        jailManager.loadAll();
    }

    private void initGuis() {
        this.helpGUI = new HelpGUI(this);
        this.shopGUI = new ShopGUI(this);
        this.invSeeGUI = new InvSeeGUI(this);
    }

    private void registerVaultEconomy() {
        getServer().getServicesManager().register(Economy.class, economyManager, this, ServicePriority.Highest);
        getLogger().info("Block2Core enregistre comme fournisseur d'economie Vault (Block2Coins).");
    }

    private void registerPlaceholderApi() {
        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new Block2CorePlaceholders(this).register();
            getLogger().info("Expansion PlaceholderAPI enregistree.");
        } else {
            getLogger().info("PlaceholderAPI non detecte : les placeholders %block2core_*% ne seront pas disponibles.");
        }
    }

    private void registerListeners() {
        var pm = getServer().getPluginManager();
        pm.registerEvents(new JoinQuitListener(this), this);
        this.authListener = new AuthListener(this);
        pm.registerEvents(authListener, this);
        authListener.start();
        pm.registerEvents(new ChatListener(this), this);
        pm.registerEvents(new ProtectionListener(this), this);
        pm.registerEvents(new QuestProgressListener(this), this);
        pm.registerEvents(new BlockLogListener(this), this);
        pm.registerEvents(new TutorialListener(this), this);
        pm.registerEvents(helpGUI, this);
        pm.registerEvents(shopGUI, this);
        pm.registerEvents(invSeeGUI, this);
    }

    private void registerCommands() {
        // Rank
        setExecutor("rankup", new RankCommand(this));
        setExecutor("rank", new RankCommand(this));
        setExecutor("staff", new StaffRankCommand(this));
        setExecutor("playtime", new PlaytimeCommand(this));

        // Economie
        setExecutor("bal", new EconomyCommand(this));
        setExecutor("pay", new EconomyCommand(this));
        setExecutor("b2c", new B2CAdminCommand(this));
        setExecutor("coinflip", new CoinflipCommand(this));
        setExecutor("shop", new ShopCommand(this));

        // Kits / Tuto / Quetes
        setExecutor("kit", new KitCommand(this));
        setExecutor("tuto", new TutorialCommand(this));
        setExecutor("quest", new QuestCommand(this));

        // Infos
        setExecutor("discord", new InfoCommand(this, "discord", "DISCORD"));
        setExecutor("don", new InfoCommand(this, "don", "DON"));
        setExecutor("youtube", new InfoCommand(this, "youtube", "YOUTUBE"));
        setExecutor("site", new InfoCommand(this, "site", "SITE"));
        setExecutor("ip", new InfoCommand(this, "server-ip", "IP DU SERVEUR", true));

        // Aide / Reports
        setExecutor("help", new HelpCommand(this));
        setExecutor("report", new ReportCommand(this));
        setExecutor("reports", new ReportsAdminCommand(this));

        // Moderation
        PunishmentCommand punishmentCommand = new PunishmentCommand(this);
        for (String name : new String[]{"ban", "tempban", "unban", "mute", "tempmute", "unmute", "kick",
                "warn", "warnings", "delwarn", "clearwarns", "ipban", "unipban", "blacklist", "unblacklist"}) {
            setExecutor(name, punishmentCommand);
        }
        StaffToolCommand staffToolCommand = new StaffToolCommand(this);
        for (String name : new String[]{"gm", "fly", "god", "heal", "feed", "repair", "clear", "clearlag",
                "kill", "sudo", "broadcast", "staffchat", "stafflist"}) {
            setExecutor(name, staffToolCommand);
        }
        StaffAdvancedCommand staffAdvancedCommand = new StaffAdvancedCommand(this);
        for (String name : new String[]{"vanish", "invsee", "enderchest", "tp", "tphere", "tpall", "tppos",
                "back", "freeze", "jail", "unjail", "mutechat", "unmutechat", "slowchat", "history", "logs", "co"}) {
            setExecutor(name, staffAdvancedCommand);
        }
        setExecutor("maintenance", new MaintenanceCommand(this));
        setExecutor("staffmode", new StaffModeCommand(this));

        // Claims / Teams
        ClaimCommand claimCommand = new ClaimCommand(this);
        for (String name : new String[]{"claim", "unclaim", "trust", "claims"}) {
            setExecutor(name, claimCommand);
        }
        setExecutor("unesco", new UnescoCommand(this));
        setExecutor("team", new TeamCommand(this));

        // QOL / Teleportation / Social
        TeleportQolCommand teleportQolCommand = new TeleportQolCommand(this);
        for (String name : new String[]{"spawn", "setspawn", "home", "sethome", "delhome", "warp", "setwarp", "delwarp",
                "tpa", "tpaccept", "tpdeny", "rtp"}) {
            setExecutor(name, teleportQolCommand);
        }
        SocialCommand socialCommand = new SocialCommand(this);
        for (String name : new String[]{"msg", "reply", "ignore"}) {
            setExecutor(name, socialCommand);
        }

        // Auth / Skin
        AuthCommand authCommand = new AuthCommand(this);
        for (String name : new String[]{"register", "login", "changepassword"}) {
            setExecutor(name, authCommand);
        }
        setExecutor("skin", new SkinCommand(this));
    }

    /** Enregistre un CommandExecutor (et son TabCompleter s'il en implemente un) pour la commande donnee. */
    private void setExecutor(String name, org.bukkit.command.CommandExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().warning("Commande '" + name + "' introuvable dans plugin.yml !");
            return;
        }
        command.setExecutor(executor);
        if (executor instanceof org.bukkit.command.TabCompleter tabCompleter) {
            command.setTabCompleter(tabCompleter);
        }
    }

    private void startTasks() {
        playtimeManager.start();
        playerStateManager.start();
        jailManager.start();
        cacheCleanupManager.start();
        displayManager.start();
    }

    // ---------------------------------------------------------------
    // CACHE PLAYERDATA
    // ---------------------------------------------------------------

    public PlayerData getPlayerData(UUID uuid) {
        return playerDataMap.get(uuid);
    }

    public void putPlayerData(UUID uuid, PlayerData data) {
        playerDataMap.put(uuid, data);
    }

    public void removePlayerData(UUID uuid) {
        playerDataMap.remove(uuid);
    }

    // ---------------------------------------------------------------
    // ACCESSEURS
    // ---------------------------------------------------------------

    public static Block2Core getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public RankManager getRankManager() {
        return rankManager;
    }

    public PlaytimeManager getPlaytimeManager() {
        return playtimeManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public TutorialManager getTutorialManager() {
        return tutorialManager;
    }

    public QuestManager getQuestManager() {
        return questManager;
    }

    public ReportManager getReportManager() {
        return reportManager;
    }

    public ClaimManager getClaimManager() {
        return claimManager;
    }

    public TeamManager getTeamManager() {
        return teamManager;
    }

    public LocationManager getLocationManager() {
        return locationManager;
    }

    public PunishmentManager getPunishmentManager() {
        return punishmentManager;
    }

    public AuthManager getAuthManager() {
        return authManager;
    }

    public PlayerStateManager getPlayerStateManager() {
        return playerStateManager;
    }

    public JailManager getJailManager() {
        return jailManager;
    }

    public CacheCleanupManager getCacheCleanupManager() {
        return cacheCleanupManager;
    }

    public SocialManager getSocialManager() {
        return socialManager;
    }

    public ChatModerationManager getChatModerationManager() {
        return chatModerationManager;
    }

    public LogManager getLogManager() {
        return logManager;
    }

    public DisplayManager getDisplayManager() {
        return displayManager;
    }

    public BedrockSupport getBedrockSupport() {
        return bedrockSupport;
    }

    public HelpGUI getHelpGUI() {
        return helpGUI;
    }

    public ShopGUI getShopGUI() {
        return shopGUI;
    }

    public InvSeeGUI getInvSeeGUI() {
        return invSeeGUI;
    }
}
