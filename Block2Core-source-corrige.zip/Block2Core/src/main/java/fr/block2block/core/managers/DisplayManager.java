package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.StaffRank;
import fr.block2block.core.util.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.List;

/**
 * Gere l'affichage du tab (header/footer + tri des joueurs par grade via
 * des scoreboard teams, avec le nom du grade en prefixe) et du scoreboard
 * lateral personnel (stats par grade).
 */
public class DisplayManager {

    private static final String SIDEBAR_OBJECTIVE = "b2c_sidebar";
    private static final String[] INVISIBLE_ENTRIES;

    static {
        ChatColor[] colors = ChatColor.values();
        INVISIBLE_ENTRIES = new String[colors.length];
        for (int i = 0; i < colors.length; i++) {
            INVISIBLE_ENTRIES[i] = colors[i].toString();
        }
    }

    private final Block2Core plugin;
    private BukkitTask tabTask;
    private BukkitTask scoreboardTask;

    public DisplayManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void start() {
        int tabInterval = Math.max(1, plugin.getConfigManager().tabRefreshSeconds());
        tabTask = Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAllTab, 5L, 20L * tabInterval);

        if (plugin.getConfigManager().scoreboardEnabled()) {
            int sbInterval = Math.max(1, plugin.getConfigManager().scoreboardRefreshSeconds());
            scoreboardTask = Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAllScoreboards, 5L, 20L * sbInterval);
        }
    }

    public void stop() {
        if (tabTask != null) tabTask.cancel();
        if (scoreboardTask != null) scoreboardTask.cancel();
    }

    /** Remplace %server_online% s'il est encore present apres PlaceholderAPI (fonctionne meme sans l'expansion "Server"). */
    private String ensureServerOnlinePlaceholder(String text) {
        if (text != null && text.contains("%server_online%")) {
            return text.replace("%server_online%", String.valueOf(Bukkit.getOnlinePlayers().size()));
        }
        return text;
    }

    // ---------------------------------------------------------------
    // TAB
    // ---------------------------------------------------------------

    private void refreshAllTab() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            refreshTab(player);
        }
    }

    public void refreshTab(Player player) {
        String header = ensureServerOnlinePlaceholder(TextUtil.applyPapi(player, plugin.getConfigManager().tabHeader()));
        String footer = ensureServerOnlinePlaceholder(TextUtil.applyPapi(player, plugin.getConfigManager().tabFooter()));
        player.sendPlayerListHeaderAndFooter(TextUtil.parse(header), TextUtil.parse(footer));
    }

    /** Place le joueur dans une equipe du scoreboard principal pour trier/colorer le tab selon son grade, avec le nom du grade en prefixe. */
    public void applyTabSort(Player player, PlayerData data) {
        Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        int tier;
        String key;
        Component formattedRank;

        if (data.getStaffRank() != null) {
            tier = data.getStaffRank().ordinal(); // 0 (Helper) .. 4 (Owner), on veut Owner en premier -> inverser
            tier = 4 - tier; // 0 = Owner, 4 = Helper
            key = data.getStaffRank().key();
            formattedRank = plugin.getConfigManager().staffFormatted(data.getStaffRank());
        } else {
            int gradeTier = data.getGrade().ordinal(); // 0 Paysan .. 4 Partenaire
            tier = 9 - gradeTier; // Partenaire=5 .. Paysan=9 (apres les 5 grades staff 0-4)
            key = data.getGrade().key();
            formattedRank = plugin.getConfigManager().gradeFormatted(data.getGrade());
        }
        NamedTextColor color = colorFromComponent(formattedRank);

        String teamName = tier + "_" + key;
        Team team = main.getTeam(teamName);
        if (team == null) {
            team = main.registerNewTeam(teamName);
        }
        team.color(color);
        // Prefixe affiche devant le pseudo dans le tab : "GRADE Pseudo"
        team.prefix(formattedRank.append(Component.space()));
        // Retirer le joueur de toute autre equipe de tri avant de l'ajouter a la sienne
        for (Team existing : main.getTeams()) {
            if (existing.hasEntry(player.getName())) {
                existing.removeEntry(player.getName());
            }
        }
        team.addEntry(player.getName());
    }

    private NamedTextColor colorFromComponent(Component component) {
        var color = component.color();
        return color instanceof NamedTextColor named ? named : NamedTextColor.nearestTo(color != null ? color : NamedTextColor.WHITE);
    }

    // ---------------------------------------------------------------
    // SCOREBOARD LATERAL
    // ---------------------------------------------------------------

    public void initScoreboard(Player player) {
        if (!plugin.getConfigManager().scoreboardEnabled()) return;
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = board.registerNewObjective(SIDEBAR_OBJECTIVE, Criteria.DUMMY,
                TextUtil.parse(plugin.getConfigManager().scoreboardTitle()));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        List<String> lines = plugin.getConfigManager().scoreboardLines();
        int score = lines.size();
        for (int i = 0; i < lines.size() && i < INVISIBLE_ENTRIES.length; i++) {
            String entry = INVISIBLE_ENTRIES[i];
            Team team = board.registerNewTeam("line" + i);
            team.addEntry(entry);
            objective.getScore(entry).setScore(score--);
        }
        player.setScoreboard(board);
        refreshScoreboard(player);
    }

    private void refreshAllScoreboards() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            refreshScoreboard(player);
        }
    }

    public void refreshScoreboard(Player player) {
        Scoreboard board = player.getScoreboard();
        if (board == null || board.getObjective(SIDEBAR_OBJECTIVE) == null) return;

        List<String> lines = plugin.getConfigManager().scoreboardLines();
        for (int i = 0; i < lines.size() && i < INVISIBLE_ENTRIES.length; i++) {
            Team team = board.getTeam("line" + i);
            if (team == null) continue;
            // IMPORTANT : nos propres placeholders (%block2core_*%) sont resolus EN PREMIER, avec
            // leurs couleurs. Si PlaceholderAPI est interroge avant, notre propre expansion
            // (enregistree aupres de PAPI) intercepterait ces memes placeholders et renverrait du
            // texte SANS couleur, ce qui les "vidait" silencieusement avant notre remplacement.
            String rendered = applyInternalPlaceholders(player, lines.get(i));
            rendered = ensureServerOnlinePlaceholder(TextUtil.applyPapi(player, rendered));
            team.prefix(TextUtil.parse(rendered));
        }
    }

    private String applyInternalPlaceholders(Player player, String text) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return text;
        Grade grade = data.getGrade();
        StaffRank staffRank = data.getStaffRank();
        String rankDisplay = staffRank != null
                ? plugin.getConfigManager().staffColor(staffRank) + plugin.getConfigManager().staffDisplayName(staffRank)
                : plugin.getConfigManager().gradeColor(grade) + plugin.getConfigManager().gradeDisplayName(grade);

        int claimsUsed = plugin.getClaimManager().countOwnedByPlayer(player.getUniqueId());
        int claimsMax = plugin.getConfigManager().claimLimit(grade);

        String result = text;
        result = result.replace("%block2core_rank_display%", rankDisplay);
        result = result.replace("%block2core_balance%", String.format("%,.0f", data.getBalance()));
        result = result.replace("%block2core_playtime_formatted%", fr.block2block.core.util.TimeUtil.formatHoursMinutes(data.getPlaytimeSeconds()));
        result = result.replace("%block2core_claims_used%", String.valueOf(claimsUsed));
        result = result.replace("%block2core_claims_max%", String.valueOf(claimsMax));
        return result;
    }
}
