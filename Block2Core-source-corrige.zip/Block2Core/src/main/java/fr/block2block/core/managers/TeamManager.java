package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.PlayerTeam;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere les equipes (teams/factions) : creation, invitations, home, chat
 * d'equipe et claims d'equipe (le comptage des claims est gere par
 * ClaimManager, ce manager fournit juste l'appartenance).
 */
public class TeamManager {

    private final Block2Core plugin;
    private final Map<Integer, PlayerTeam> teams = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> memberToTeam = new ConcurrentHashMap<>();
    /** Invitations en attente : joueur invite -> {id de l'equipe, timestamp}. Expirent apres INVITE_TTL_MILLIS. */
    private final Map<UUID, PendingInvite> pendingInvites = new ConcurrentHashMap<>();
    private static final long INVITE_TTL_MILLIS = 5L * 60 * 1000; // 5 minutes

    private record PendingInvite(int teamId, long timestamp) {
    }

    public TeamManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Map<Integer, PlayerTeam> loaded = new HashMap<>();
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                try (var statement = connection.prepareStatement("SELECT * FROM b2c_teams"); var rs = statement.executeQuery()) {
                    while (rs.next()) {
                        int id = rs.getInt("id");
                        PlayerTeam team = new PlayerTeam(id, rs.getString("name"), UUID.fromString(rs.getString("owner_uuid")));
                        if (rs.getBoolean("home_set")) {
                            team.setHome(rs.getString("home_world"), rs.getDouble("home_x"), rs.getDouble("home_y"),
                                    rs.getDouble("home_z"), rs.getFloat("home_yaw"), rs.getFloat("home_pitch"));
                        }
                        loaded.put(id, team);
                    }
                }
                try (var statement = connection.prepareStatement("SELECT * FROM b2c_team_members"); var rs = statement.executeQuery()) {
                    while (rs.next()) {
                        int teamId = rs.getInt("team_id");
                        UUID uuid = UUID.fromString(rs.getString("uuid"));
                        PlayerTeam team = loaded.get(teamId);
                        if (team != null) {
                            team.getMembers().put(uuid, PlayerTeam.Role.valueOf(rs.getString("role")));
                            memberToTeam.put(uuid, teamId);
                        }
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement teams", exception);
            }
            teams.putAll(loaded);
            plugin.getLogger().info("Teams chargees : " + teams.size());
        });
    }

    public PlayerTeam getTeam(int id) {
        return teams.get(id);
    }

    public PlayerTeam getTeamOf(UUID uuid) {
        Integer id = memberToTeam.get(uuid);
        return id != null ? teams.get(id) : null;
    }

    public PlayerTeam getTeamByName(String name) {
        for (PlayerTeam team : teams.values()) {
            if (team.getName().equalsIgnoreCase(name)) return team;
        }
        return null;
    }

    public boolean nameTaken(String name) {
        return getTeamByName(name) != null;
    }

    public void create(Player owner, String name, double cost, Consumer<CreateResult> callback) {
        if (getTeamOf(owner.getUniqueId()) != null) {
            callback.accept(CreateResult.ALREADY_IN_TEAM);
            return;
        }
        if (nameTaken(name)) {
            callback.accept(CreateResult.NAME_TAKEN);
            return;
        }
        if (plugin.getEconomyManager().getBalance(owner.getUniqueId()) < cost) {
            callback.accept(CreateResult.NOT_ENOUGH_MONEY);
            return;
        }
        plugin.getEconomyManager().withdraw(owner.getUniqueId(), cost);

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int generatedId = -1;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_teams (name, owner_uuid, created_at) VALUES (?,?,?)",
                         java.sql.Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, name);
                statement.setString(2, owner.getUniqueId().toString());
                statement.setLong(3, System.currentTimeMillis());
                statement.executeUpdate();
                try (var keys = statement.getGeneratedKeys()) {
                    if (keys.next()) generatedId = keys.getInt(1);
                }
                if (generatedId > 0) {
                    try (var memberStatement = connection.prepareStatement(
                            "INSERT INTO b2c_team_members (team_id, uuid, role) VALUES (?,?,?)")) {
                        memberStatement.setInt(1, generatedId);
                        memberStatement.setString(2, owner.getUniqueId().toString());
                        memberStatement.setString(3, "OWNER");
                        memberStatement.executeUpdate();
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur creation team", exception);
            }
            int finalId = generatedId;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (finalId <= 0) {
                    plugin.getEconomyManager().deposit(owner.getUniqueId(), cost); // remboursement, la creation a echoue
                    callback.accept(CreateResult.ERROR);
                    return;
                }
                PlayerTeam team = new PlayerTeam(finalId, name, owner.getUniqueId());
                teams.put(finalId, team);
                memberToTeam.put(owner.getUniqueId(), finalId);
                PlayerData data = plugin.getPlayerData(owner.getUniqueId());
                if (data != null) data.setTeamId(finalId);
                callback.accept(CreateResult.SUCCESS);
            });
        });
    }

    public void invite(UUID inviterUuid, UUID targetUuid) {
        Integer teamId = memberToTeam.get(inviterUuid);
        if (teamId != null) {
            pendingInvites.put(targetUuid, new PendingInvite(teamId, System.currentTimeMillis()));
        }
    }

    public Integer getPendingInvite(UUID targetUuid) {
        PendingInvite invite = pendingInvites.get(targetUuid);
        if (invite == null) return null;
        if (System.currentTimeMillis() - invite.timestamp() > INVITE_TTL_MILLIS) {
            pendingInvites.remove(targetUuid);
            return null;
        }
        return invite.teamId();
    }

    public void accept(Player player, Consumer<Boolean> callback) {
        PendingInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null || System.currentTimeMillis() - invite.timestamp() > INVITE_TTL_MILLIS
                || !teams.containsKey(invite.teamId())) {
            callback.accept(false);
            return;
        }
        int teamId = invite.teamId();
        PlayerTeam team = teams.get(teamId);
        team.addMember(player.getUniqueId());
        memberToTeam.put(player.getUniqueId(), teamId);
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data != null) data.setTeamId(teamId);

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_team_members (team_id, uuid, role) VALUES (?,?,'MEMBER')")) {
                statement.setInt(1, teamId);
                statement.setString(2, player.getUniqueId().toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur ajout membre team", exception);
            }
        });
        callback.accept(true);
    }

    public void denyInvite(UUID targetUuid) {
        pendingInvites.remove(targetUuid);
    }

    /** Purge les invitations expirees (voir CacheCleanupManager). */
    public void cleanupStaleInvites() {
        long now = System.currentTimeMillis();
        pendingInvites.values().removeIf(invite -> now - invite.timestamp() > INVITE_TTL_MILLIS);
    }

    public void leave(Player player, Runnable onDone) {
        Integer teamId = memberToTeam.remove(player.getUniqueId());
        if (teamId == null) return;
        PlayerTeam team = teams.get(teamId);
        if (team == null) return;
        team.removeMember(player.getUniqueId());
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data != null) data.setTeamId(null);

        boolean deleteTeam = team.getMembers().isEmpty();
        if (team.getOwner().equals(player.getUniqueId()) && !team.getMembers().isEmpty()) {
            UUID newOwner = team.getMembers().keySet().iterator().next();
            team.setOwner(newOwner);
            team.getMembers().put(newOwner, PlayerTeam.Role.OWNER);
        }
        if (deleteTeam) {
            teams.remove(teamId);
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                try (var statement = connection.prepareStatement("DELETE FROM b2c_team_members WHERE team_id = ? AND uuid = ?")) {
                    statement.setInt(1, teamId);
                    statement.setString(2, player.getUniqueId().toString());
                    statement.executeUpdate();
                }
                if (deleteTeam) {
                    try (var statement = connection.prepareStatement("DELETE FROM b2c_teams WHERE id = ?")) {
                        statement.setInt(1, teamId);
                        statement.executeUpdate();
                    }
                    try (var statement = connection.prepareStatement("DELETE FROM b2c_claims WHERE team_id = ?")) {
                        statement.setInt(1, teamId);
                        statement.executeUpdate();
                    }
                    plugin.getClaimManager().unloadClaimsOfTeam(teamId);
                } else {
                    try (var statement = connection.prepareStatement("UPDATE b2c_teams SET owner_uuid = ? WHERE id = ?")) {
                        statement.setString(1, team.getOwner().toString());
                        statement.setInt(2, teamId);
                        statement.executeUpdate();
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur depart de team", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void setHome(PlayerTeam team, Location location) {
        team.setHome(location.getWorld().getName(), location.getX(), location.getY(), location.getZ(),
                location.getYaw(), location.getPitch());
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "UPDATE b2c_teams SET home_world=?, home_x=?, home_y=?, home_z=?, home_yaw=?, home_pitch=?, home_set=1 WHERE id=?")) {
                statement.setString(1, team.getHomeWorld());
                statement.setDouble(2, team.getHomeX());
                statement.setDouble(3, team.getHomeY());
                statement.setDouble(4, team.getHomeZ());
                statement.setFloat(5, team.getHomeYaw());
                statement.setFloat(6, team.getHomePitch());
                statement.setInt(7, team.getId());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde home team", exception);
            }
        });
    }

    public Location resolveHomeLocation(PlayerTeam team) {
        if (!team.hasHome()) return null;
        World world = Bukkit.getWorld(team.getHomeWorld());
        if (world == null) return null;
        return new Location(world, team.getHomeX(), team.getHomeY(), team.getHomeZ(), team.getHomeYaw(), team.getHomePitch());
    }

    public enum CreateResult { SUCCESS, ALREADY_IN_TEAM, NAME_TAKEN, NOT_ENOUGH_MONEY, ERROR }
}
