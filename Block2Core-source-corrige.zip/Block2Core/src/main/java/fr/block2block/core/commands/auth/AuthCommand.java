package fr.block2block.core.commands.auth;

import fr.block2block.core.Block2Core;
import fr.block2block.core.managers.AuthManager;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AuthCommand implements CommandExecutor {

    private final Block2Core plugin;

    public AuthCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase()) {
            case "register" -> register(sender, args);
            case "login" -> login(sender, args);
            case "changepassword" -> changePassword(sender, args);
            default -> false;
        };
    }

    private boolean register(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /register <motdepasse> <confirmation>"));
            return true;
        }
        plugin.getAuthManager().register(player, args[0], args[1], result -> handleResult(player, result, true));
        return true;
    }

    private boolean login(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /login <motdepasse>"));
            return true;
        }
        plugin.getAuthManager().login(player, args[0], result -> handleResult(player, result, false));
        return true;
    }

    private boolean changePassword(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /changepassword <ancien> <nouveau>"));
            return true;
        }
        plugin.getAuthManager().changePassword(player, args[0], args[1], result -> {
            switch (result) {
                case SUCCESS -> player.sendMessage(TextUtil.parse("<green>Mot de passe modifie avec succes."));
                case WRONG_PASSWORD -> player.sendMessage(TextUtil.parse("<red>Ancien mot de passe incorrect."));
                case NOT_REGISTERED -> player.sendMessage(TextUtil.parse("<red>Tu n'es pas inscrit."));
                case PASSWORD_TOO_SHORT -> player.sendMessage(TextUtil.parse("<red>Le nouveau mot de passe est trop court (min " +
                        plugin.getConfigManager().authMinPasswordLength() + " caracteres)."));
                default -> player.sendMessage(TextUtil.parse("<red>Une erreur est survenue."));
            }
        });
        return true;
    }

    private void handleResult(Player player, AuthManager.AuthResult result, boolean isRegister) {
        switch (result) {
            case SUCCESS -> {
                plugin.getAuthManager().finalizeAuthentication(player);
                player.sendMessage(TextUtil.parse(isRegister
                        ? "<green>Inscription reussie ! Bienvenue."
                        : "<green>Connexion reussie ! Bienvenue."));
            }
            case ALREADY_REGISTERED -> player.sendMessage(TextUtil.parse("<red>Tu es deja inscrit. Utilise /login."));
            case NOT_REGISTERED -> player.sendMessage(TextUtil.parse("<red>Tu n'es pas inscrit. Utilise /register."));
            case WRONG_PASSWORD -> player.sendMessage(TextUtil.parse("<red>Mot de passe incorrect."));
            case PASSWORDS_DONT_MATCH -> player.sendMessage(TextUtil.parse("<red>Les mots de passe ne correspondent pas."));
            case PASSWORD_TOO_SHORT -> player.sendMessage(TextUtil.parse("<red>Mot de passe trop court (min " +
                    plugin.getConfigManager().authMinPasswordLength() + " caracteres)."));
            case ERROR -> player.sendMessage(TextUtil.parse("<red>Une erreur est survenue, reessaie."));
        }
    }
}
