package fr.block2block.core.commands.info;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/**
 * Executeur generique reutilise pour /discord, /don, /youtube, /site et /ip
 * (une instance par commande, chacune configuree avec sa cle config.yml).
 * Pour l'IP du serveur, le clic copie la valeur dans le presse-papier plutot
 * que d'essayer d'ouvrir une URL (ce n'en est pas une).
 */
public class InfoCommand implements CommandExecutor {

    private final Block2Core plugin;
    private final String configKey;
    private final String displayName;
    private final boolean copyToClipboard;

    public InfoCommand(Block2Core plugin, String configKey, String displayName) {
        this(plugin, configKey, displayName, false);
    }

    public InfoCommand(Block2Core plugin, String configKey, String displayName, boolean copyToClipboard) {
        this.plugin = plugin;
        this.configKey = configKey;
        this.displayName = displayName;
        this.copyToClipboard = copyToClipboard;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String value = plugin.getConfigManager().infoLink(configKey);
        String clickTag = copyToClipboard ? "copy_to_clipboard" : "open_url";
        String hoverText = copyToClipboard ? "Cliquer pour copier" : "Cliquer pour ouvrir";
        sender.sendMessage(TextUtil.parse("<aqua><bold>" + displayName + " <gray>: " +
                "<hover:show_text:'<gray>" + hoverText + "'><click:" + clickTag + ":'" + value + "'><white><underlined>" + value + "</underlined></white></click></hover>"));
        return true;
    }
}
