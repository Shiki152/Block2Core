package fr.block2block.core.commands.rank;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PlaytimeCommand implements CommandExecutor {

    private final Block2Core plugin;

    public PlaytimeCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0) {
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
                return true;
            }
            PlayerData data = plugin.getPlayerData(target.getUniqueId());
            sender.sendMessage(TextUtil.parse("<gray>Playtime de <white>" + target.getName() + " <gray>: <aqua>" +
                    TimeUtil.formatHoursMinutes(data != null ? data.getPlaytimeSeconds() : 0)));
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Usage : /playtime <joueur>");
            return true;
        }
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        sender.sendMessage(TextUtil.parse("<gray>Ton temps de jeu : <aqua>" +
                TimeUtil.formatHoursMinutes(data != null ? data.getPlaytimeSeconds() : 0)));
        return true;
    }
}
