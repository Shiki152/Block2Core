package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.SellPrices;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Interface pour /worth : liste, page par page, tous les objets vendables via /sell et leur
 * prix unitaire (voir SellPrices). Purement informatif : aucun achat ni vente possible ici,
 * juste une reference des prix pour savoir quoi apporter avant d'aller a /sell.
 */
public class WorthGUI implements Listener {

    private static final int SIZE = 54;
    private static final int ITEMS_PER_PAGE = 45;
    private static final int PREV_SLOT = 45;
    private static final int PAGE_INFO_SLOT = 49;
    private static final int NEXT_SLOT = 53;

    private final Block2Core plugin;

    public WorthGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        openPage(player, 0);
    }

    private void openPage(Player player, int page) {
        List<Material> sellable = SellPrices.getAllSellableSorted();
        int totalPages = Math.max(1, (int) Math.ceil(sellable.size() / (double) ITEMS_PER_PAGE));
        int clampedPage = Math.max(0, Math.min(page, totalPages - 1));

        Inventory inventory = plugin.getServer().createInventory(new WorthHolder(clampedPage), SIZE,
                TextUtil.parse("<gold><bold>Prix de vente <gray>(" + (clampedPage + 1) + "/" + totalPages + ")"));

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < SIZE; i++) {
            inventory.setItem(i, filler);
        }

        int start = clampedPage * ITEMS_PER_PAGE;
        int end = Math.min(sellable.size(), start + ITEMS_PER_PAGE);
        for (int i = start; i < end; i++) {
            Material material = sellable.get(i);
            Double price = SellPrices.priceOf(material);
            inventory.setItem(i - start, new ItemBuilder(material)
                    .name("<white>" + niceName(material))
                    .loreLine("<gray>Prix de vente : <gold>" + String.format("%,.1f", price) + " Block2Coins <gray>/ unite")
                    .build());
        }

        if (clampedPage > 0) {
            inventory.setItem(PREV_SLOT, new ItemBuilder(Material.ARROW).name("<gray>« Page precedente").build());
        }
        if (clampedPage < totalPages - 1) {
            inventory.setItem(NEXT_SLOT, new ItemBuilder(Material.ARROW).name("<gray>Page suivante »").build());
        }
        inventory.setItem(PAGE_INFO_SLOT, new ItemBuilder(Material.BOOK)
                .name("<yellow>" + sellable.size() + " objets vendables")
                .loreLine("<gray>Page " + (clampedPage + 1) + "/" + totalPages)
                .loreLine(" ")
                .loreLine("<gray>Utilise /sell pour vendre.")
                .build());

        player.openInventory(inventory);
    }

    private String niceName(Material material) {
        String raw = material.name().toLowerCase().replace('_', ' ');
        return Character.toUpperCase(raw.charAt(0)) + raw.substring(1);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof WorthHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !(event.getClickedInventory().getHolder() instanceof WorthHolder)) return;

        Player player = (Player) event.getWhoClicked();
        if (event.getSlot() == PREV_SLOT) {
            openPage(player, holder.page() - 1);
        } else if (event.getSlot() == NEXT_SLOT) {
            openPage(player, holder.page() + 1);
        }
    }

    public static class WorthHolder implements InventoryHolder {
        private final int page;

        public WorthHolder(int page) {
            this.page = page;
        }

        public int page() {
            return page;
        }

        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
