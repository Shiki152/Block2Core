package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.UUID;

/**
 * Vue en direct de l'inventaire d'un joueur (/invsee). Contrairement a
 * l'enderchest (qui peut s'ouvrir nativement avec Bukkit), la PlayerInventory
 * ne se prete pas bien a un affichage direct pour un tiers (armure/offhand
 * mal rendus) : on utilise donc un inventaire miroir personnalise, resynchronise
 * vers le vrai inventaire de la cible a chaque clic.
 */
public class InvSeeGUI implements Listener {

    private final Block2Core plugin;

    private static final int[] MAIN_SLOTS = buildRange(9, 44);

    public InvSeeGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    private static int[] buildRange(int from, int to) {
        int[] range = new int[to - from + 1];
        for (int i = 0; i < range.length; i++) range[i] = from + i;
        return range;
    }

    public void open(Player staff, Player target) {
        Inventory inventory = plugin.getServer().createInventory(new InvSeeHolder(target.getUniqueId()), 54,
                TextUtil.parse("<dark_gray>Inventaire de <white>" + target.getName()));

        PlayerInventory targetInv = target.getInventory();
        inventory.setItem(0, orAir(targetInv.getHelmet()));
        inventory.setItem(1, orAir(targetInv.getChestplate()));
        inventory.setItem(2, orAir(targetInv.getLeggings()));
        inventory.setItem(3, orAir(targetInv.getBoots()));
        inventory.setItem(4, orAir(targetInv.getItemInOffHand()));

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 5; i <= 8; i++) inventory.setItem(i, filler);
        for (int i = 45; i <= 53; i++) inventory.setItem(i, filler);

        for (int i = 0; i < MAIN_SLOTS.length && i < 36; i++) {
            inventory.setItem(MAIN_SLOTS[i], targetInv.getContents()[i]);
        }
        staff.openInventory(inventory);
    }

    private ItemStack orAir(ItemStack stack) {
        return stack != null ? stack : new ItemStack(Material.AIR);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof InvSeeHolder holder)) return;

        int rawSlot = event.getRawSlot();
        boolean topSideFillerClick = rawSlot < 54 && ((rawSlot >= 5 && rawSlot <= 8) || rawSlot >= 45);
        if (topSideFillerClick) {
            event.setCancelled(true);
            return;
        }

        // Autorise le clic (deplacement normal), puis resynchronise vers la vraie cible au prochain tick.
        Bukkit.getScheduler().runTask(plugin, () -> syncToTarget(event.getInventory(), holder.targetUuid()));
    }

    private void syncToTarget(Inventory guiInventory, UUID targetUuid) {
        Player target = plugin.getServer().getPlayer(targetUuid);
        if (target == null) return;
        PlayerInventory targetInv = target.getInventory();

        targetInv.setHelmet(nullIfAir(guiInventory.getItem(0)));
        targetInv.setChestplate(nullIfAir(guiInventory.getItem(1)));
        targetInv.setLeggings(nullIfAir(guiInventory.getItem(2)));
        targetInv.setBoots(nullIfAir(guiInventory.getItem(3)));
        targetInv.setItemInOffHand(orAir(guiInventory.getItem(4)));

        for (int i = 0; i < MAIN_SLOTS.length && i < 36; i++) {
            targetInv.setItem(i, guiInventory.getItem(MAIN_SLOTS[i]));
        }
    }

    private ItemStack nullIfAir(ItemStack stack) {
        return (stack == null || stack.getType() == Material.AIR) ? null : stack;
    }

    public record InvSeeHolder(UUID targetUuid) implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
