package fr.block2block.core.util;

import fr.block2block.core.data.Grade;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Permissions Bukkit accordees cumulativement selon le grade JOUEUR (Paysan -> Partenaire),
 * en complement du systeme de limites (claims/homes/kits) deja pilote par config.yml selon
 * le grade. Deux usages :
 * <ul>
 *     <li>servir de point d'integration pour d'autres plugins (permissions.yml, LuckPerms...)
 *     qui voudraient eux aussi reagir a la progression de grade ;</li>
 *     <li>piloter quelques avantages internes a Block2Core (categories de boutique reservees,
 *     acces au vol quotidien) plutot que de les coder en dur sur l'enum Grade.</li>
 * </ul>
 * IMPORTANT : le grade Partenaire n'est JAMAIS obtenu via /rankup (voir RankManager#rankup,
 * qui s'arrete a Master) - il n'est distribue que manuellement par un OP via /rank set. Ces
 * permissions restent malgre tout definies pour Partenaire : un joueur qui le recoit doit
 * cumuler tous les avantages des grades inferieurs.
 */
public final class GradeTiers {

    private static final Map<Grade, List<String>> ADDED_PER_GRADE = new EnumMap<>(Grade.class);

    static {
        ADDED_PER_GRADE.put(Grade.PAYSAN, List.of(
                "block2core.grade.paysan"
        ));
        ADDED_PER_GRADE.put(Grade.AVENTURIER, List.of(
                "block2core.grade.aventurier"
        ));
        ADDED_PER_GRADE.put(Grade.AGUERRIS, List.of(
                "block2core.grade.aguerris",
                // Categorie "Objets rares" de la boutique (voir ShopGUI)
                "block2core.grade.perk.shop.rare"
        ));
        ADDED_PER_GRADE.put(Grade.MASTER, List.of(
                "block2core.grade.master",
                // Vol quotidien gratuit, sans avoir besoin d'acheter du temps en boutique
                // (voir PlayerStateManager, fly.master-daily-seconds dans config.yml)
                "block2core.grade.perk.fly",
                // Objets "grail" de la boutique (Totem d'Immortalite, Elytre)
                "block2core.grade.perk.shop.legendary"
        ));
        ADDED_PER_GRADE.put(Grade.PARTENAIRE, List.of(
                "block2core.grade.partenaire",
                // Grade honorifique : cumule tout
                "block2core.grade.perk.shop.rare",
                "block2core.grade.perk.shop.legendary",
                "block2core.grade.perk.fly"
        ));
    }

    private GradeTiers() {
    }

    /** Toutes les permissions accordees a ce grade et a tous les grades inferieurs (cumulatif). */
    public static List<String> permissionsUpTo(Grade grade) {
        List<String> permissions = new ArrayList<>();
        if (grade == null) return permissions;
        for (Grade g : Grade.values()) {
            permissions.addAll(ADDED_PER_GRADE.getOrDefault(g, List.of()));
            if (g == grade) break;
        }
        return permissions;
    }
}
