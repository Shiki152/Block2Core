package fr.block2block.core.commands.moderation;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /staffmode : bascule un membre du staff entre son inventaire de survie normal et un mode
 * creatif dedie a la moderation/au build. L'inventaire de survie est sauvegarde en base a
 * l'entree en mode staff (voir PlayerStateManager), donc un crash serveur ou une deconnexion
 * pendant la session staff n'entraine aucune perte : l'inventaire est restaure automatiquement
 * a la prochaine connexion authentifiee.
 */
public class StaffModeCommand implements CommandExecutor {

    private final Block2Core plugin;

    public StaffModeCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        var data = plugin.getPlayerData(player.getUniqueId());
        if (data == null || !data.isAuthenticated()) {
            player.sendMessage(TextUtil.parse("<red>Tu dois etre authentifie pour utiliser /staffmode."));
            return true;
        }
        plugin.getPlayerStateManager().toggleStaffMode(player);
        return true;
    }
}
