package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere le journal d'actions staff (/logs) et l'inspecteur de blocs (/co :
 * inspection, recherche et rollback simplifie), toutes deux stockees en base SQLite.
 */
public class LogManager {

    private final Block2Core plugin;
    private final Set<UUID> inspecting = ConcurrentHashMap.newKeySet();

    public LogManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // JOURNAL D'ACTIONS GENERIQUE (/logs)
    // ---------------------------------------------------------------

    public void logAction(UUID targetUuid, UUID staffUuid, String staffName, String action, String data) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_action_logs (uuid, staff_uuid, staff_name, action, data, timestamp) VALUES (?,?,?,?,?,?)")) {
                statement.setString(1, targetUuid != null ? targetUuid.toString() : null);
                statement.setString(2, staffUuid != null ? staffUuid.toString() : null);
                statement.setString(3, staffName);
                statement.setString(4, action);
                statement.setString(5, data);
                statement.setLong(6, System.currentTimeMillis());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur ecriture log d'action", exception);
            }
        });
    }

    public void getLogs(UUID targetUuidOrNull, int page, Consumer<List<LogEntry>> callback) {
        int pageSize = 10;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<LogEntry> entries = new ArrayList<>();
            String sql = "SELECT * FROM b2c_action_logs" + (targetUuidOrNull != null ? " WHERE uuid = ?" : "") +
                    " ORDER BY timestamp DESC LIMIT ? OFFSET ?";
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(sql)) {
                int idx = 1;
                if (targetUuidOrNull != null) statement.setString(idx++, targetUuidOrNull.toString());
                statement.setInt(idx++, pageSize);
                statement.setInt(idx, Math.max(0, (page - 1) * pageSize));
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) {
                        entries.add(new LogEntry(rs.getString("staff_name"), rs.getString("action"),
                                rs.getString("data"), rs.getLong("timestamp")));
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur lecture logs", exception);
            }
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(entries));
        });
    }

    public record LogEntry(String staffName, String action, String data, long timestamp) {
    }

    // ---------------------------------------------------------------
    // INSPECTEUR DE BLOCS (/co)
    // ---------------------------------------------------------------

    public void logBlockChange(Player player, Block block, String action, Material blockType, Material previousType) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_block_logs (uuid, player_name, world, x, y, z, action, block_type, previous_type, timestamp) " +
                                 "VALUES (?,?,?,?,?,?,?,?,?,?)")) {
                statement.setString(1, player.getUniqueId().toString());
                statement.setString(2, player.getName());
                statement.setString(3, block.getWorld().getName());
                statement.setInt(4, block.getX());
                statement.setInt(5, block.getY());
                statement.setInt(6, block.getZ());
                statement.setString(7, action);
                statement.setString(8, blockType.name());
                statement.setString(9, previousType != null ? previousType.name() : null);
                statement.setLong(10, System.currentTimeMillis());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur ecriture block log", exception);
            }
        });
    }

    public boolean isInspecting(UUID uuid) {
        return inspecting.contains(uuid);
    }

    public boolean toggleInspect(UUID uuid) {
        if (!inspecting.remove(uuid)) {
            inspecting.add(uuid);
            return true;
        }
        return false;
    }

    /** Retourne les dernieres modifications enregistrees a cette position exacte. */
    public void inspectBlock(Block block, Consumer<List<BlockLogEntry>> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<BlockLogEntry> entries = new ArrayList<>();
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "SELECT * FROM b2c_block_logs WHERE world=? AND x=? AND y=? AND z=? ORDER BY id DESC LIMIT 5")) {
                statement.setString(1, block.getWorld().getName());
                statement.setInt(2, block.getX());
                statement.setInt(3, block.getY());
                statement.setInt(4, block.getZ());
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) entries.add(mapRow(rs));
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur inspection bloc", exception);
            }
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(entries));
        });
    }

    public void lookup(Location center, int radius, int minutesAgo, String playerFilter, Consumer<List<BlockLogEntry>> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<BlockLogEntry> entries = new ArrayList<>();
            long since = System.currentTimeMillis() - minutesAgo * 60_000L;
            String sql = "SELECT * FROM b2c_block_logs WHERE world=? AND x BETWEEN ? AND ? AND y BETWEEN ? AND ? AND z BETWEEN ? AND ? " +
                    "AND timestamp >= ?" + (playerFilter != null ? " AND player_name = ? COLLATE NOCASE" : "") + " ORDER BY id DESC LIMIT 100";
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(sql)) {
                statement.setString(1, center.getWorld().getName());
                statement.setInt(2, center.getBlockX() - radius);
                statement.setInt(3, center.getBlockX() + radius);
                statement.setInt(4, center.getBlockY() - radius);
                statement.setInt(5, center.getBlockY() + radius);
                statement.setInt(6, center.getBlockZ() - radius);
                statement.setInt(7, center.getBlockZ() + radius);
                statement.setLong(8, since);
                if (playerFilter != null) statement.setString(9, playerFilter);
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) entries.add(mapRow(rs));
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur lookup /co", exception);
            }
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(entries));
        });
    }

    /** Rollback simplifie : restaure les blocs modifies dans le rayon/la periode donnee (non marques rolled_back). */
    public void rollback(Location center, int radius, int minutesAgo, String playerFilter, Consumer<Integer> callback) {
        lookup(center, radius, minutesAgo, playerFilter, entries -> Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            World world = center.getWorld();
            for (BlockLogEntry entry : entries) {
                // BREAK -> on remet le bloc qui a ete casse. PLACE -> on remet l'etat anterieur (AIR le plus souvent).
                Material toRestore = entry.action().equals("BREAK")
                        ? entry.blockType()
                        : (entry.previousType() != null ? entry.previousType() : Material.AIR);
                Bukkit.getScheduler().runTask(plugin, () -> world.getBlockAt(entry.x(), entry.y(), entry.z()).setType(toRestore));
            }
            int restoredCount = entries.size();
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(restoredCount));
        }));
    }

    private BlockLogEntry mapRow(java.sql.ResultSet rs) throws java.sql.SQLException {
        return new BlockLogEntry(rs.getString("player_name"), rs.getString("world"), rs.getInt("x"), rs.getInt("y"), rs.getInt("z"),
                rs.getString("action"), Material.matchMaterial(rs.getString("block_type")),
                rs.getString("previous_type") != null ? Material.matchMaterial(rs.getString("previous_type")) : null,
                rs.getLong("timestamp"));
    }

    public record BlockLogEntry(String playerName, String world, int x, int y, int z, String action,
                                 Material blockType, Material previousType, long timestamp) {
    }
}
