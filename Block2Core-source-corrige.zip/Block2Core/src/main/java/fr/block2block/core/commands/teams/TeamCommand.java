package fr.block2block.core.commands.teams;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.PlayerTeam;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TeamCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public TeamCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /team <create|invite|accept|leave|home|sethome|chat|claim>"));
            return true;
        }
        return switch (args[0].toLowerCase()) {
            case "create" -> create(player, args);
            case "invite" -> invite(player, args);
            case "accept" -> accept(player);
            case "deny" -> deny(player);
            case "leave" -> leave(player);
            case "home" -> home(player);
            case "sethome" -> sethome(player);
            case "chat" -> chat(player, args);
            case "claim" -> claim(player);
            default -> {
                sender.sendMessage(TextUtil.parse("<yellow>Usage : /team <create|invite|accept|leave|home|sethome|chat|claim>"));
                yield true;
            }
        };
    }

    private boolean create(Player player, String[] args) {
        if (args.length < 3) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /team create <nom> <cout>"));
            return true;
        }
        double cost;
        try {
            cost = Double.parseDouble(args[2]);
        } catch (NumberFormatException exception) {
            player.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", Map.of("valeur", args[2])));
            return true;
        }
        plugin.getTeamManager().create(player, args[1], cost, result -> {
            switch (result) {
                case SUCCESS -> {
                    player.sendMessage(TextUtil.parse("<green>Equipe " + args[1] + " creee !"));
                    Bukkit.getServer().sendMessage(plugin.getConfigManager().messageComponent("team-create-broadcast",
                            Map.of("team", args[1], "joueur", player.getName())));
                }
                case ALREADY_IN_TEAM -> player.sendMessage(TextUtil.parse("<red>Tu as deja une equipe."));
                case NAME_TAKEN -> player.sendMessage(TextUtil.parse("<red>Ce nom d'equipe est deja pris."));
                case NOT_ENOUGH_MONEY -> player.sendMessage(TextUtil.parse("<red>Solde insuffisant (" + (long) cost + " Block2Coins requis)."));
                case ERROR -> player.sendMessage(TextUtil.parse("<red>Erreur lors de la creation."));
            }
        });
        return true;
    }

    private boolean invite(Player player, String[] args) {
        PlayerTeam team = plugin.getTeamManager().getTeamOf(player.getUniqueId());
        if (team == null) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas d'equipe."));
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /team invite <joueur>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            player.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        plugin.getTeamManager().invite(player.getUniqueId(), target.getUniqueId());
        player.sendMessage(TextUtil.parse("<green>Invitation envoyee a " + target.getName()));
        target.sendMessage(TextUtil.parse("<aqua>" + player.getName() + " t'invite dans l'equipe " + team.getName() +
                " ! <yellow>/team accept <gray>ou <yellow>/team deny"));
        return true;
    }

    private boolean accept(Player player) {
        plugin.getTeamManager().accept(player, success -> {
            if (success) {
                player.sendMessage(TextUtil.parse("<green>Tu as rejoint l'equipe !"));
            } else {
                player.sendMessage(TextUtil.parse("<red>Aucune invitation en attente."));
            }
        });
        return true;
    }

    private boolean deny(Player player) {
        plugin.getTeamManager().denyInvite(player.getUniqueId());
        player.sendMessage(TextUtil.parse("<gray>Invitation refusee."));
        return true;
    }

    private boolean leave(Player player) {
        if (plugin.getTeamManager().getTeamOf(player.getUniqueId()) == null) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas d'equipe."));
            return true;
        }
        plugin.getTeamManager().leave(player, () -> player.sendMessage(TextUtil.parse("<green>Tu as quitte ton equipe.")));
        return true;
    }

    private boolean home(Player player) {
        PlayerTeam team = plugin.getTeamManager().getTeamOf(player.getUniqueId());
        if (team == null) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas d'equipe."));
            return true;
        }
        Location location = plugin.getTeamManager().resolveHomeLocation(team);
        if (location == null) {
            player.sendMessage(TextUtil.parse("<red>Aucune home d'equipe definie. Utilise /team sethome."));
            return true;
        }
        player.teleport(location);
        player.sendMessage(TextUtil.parse("<green>Teleporte a la home de l'equipe."));
        return true;
    }

    private boolean sethome(Player player) {
        PlayerTeam team = plugin.getTeamManager().getTeamOf(player.getUniqueId());
        if (team == null) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas d'equipe."));
            return true;
        }
        plugin.getTeamManager().setHome(team, player.getLocation());
        player.sendMessage(TextUtil.parse("<green>Home d'equipe definie ici."));
        return true;
    }

    private boolean chat(Player player, String[] args) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return true;
        if (args.length > 1) {
            // /team chat <message> : envoi ponctuel sans activer le mode permanent
            String message = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
            PlayerTeam team = plugin.getTeamManager().getTeamOf(player.getUniqueId());
            if (team == null) {
                player.sendMessage(TextUtil.parse("<red>Tu n'as pas d'equipe."));
                return true;
            }
            for (var uuid : team.getMembers().keySet()) {
                Player member = Bukkit.getPlayer(uuid);
                if (member != null) {
                    member.sendMessage(TextUtil.parse("<aqua><bold>TEAM <gray>» <white>" + player.getName() + " <gray>: <white>" + message));
                }
            }
            return true;
        }
        data.setTeamChatMode(!data.isTeamChatMode());
        player.sendMessage(TextUtil.parse(data.isTeamChatMode()
                ? "<aqua>Mode chat d'equipe active. Tape /team chat pour revenir au chat normal."
                : "<gray>Mode chat d'equipe desactive."));
        return true;
    }

    private boolean claim(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        PlayerTeam team = plugin.getTeamManager().getTeamOf(player.getUniqueId());
        if (team == null || data == null) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas d'equipe."));
            return true;
        }
        int multiplier = plugin.getConfig().getInt("teams.claims-multiplier", 2);
        int limit = data.getGrade().level() * multiplier;
        plugin.getClaimManager().claimForTeam(player, team.getId(), Math.max(2, limit), result -> {
            switch (result) {
                case SUCCESS -> player.sendMessage(TextUtil.parse("<green>Chunk reclame pour l'equipe " + team.getName() + " !"));
                case ALREADY_CLAIMED -> player.sendMessage(TextUtil.parse("<red>Ce chunk est deja reclame."));
                case LIMIT_REACHED -> player.sendMessage(TextUtil.parse("<red>Limite de claims d'equipe atteinte."));
                default -> {
                }
            }
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("create", "invite", "accept", "deny", "leave", "home", "sethome", "chat", "claim").stream()
                    .filter(o -> o.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("invite")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
