package fr.block2block.core.commands.economy;

import fr.block2block.core.Block2Core;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /worth : ouvre l'interface listant tous les objets vendables (/sell) et leur prix, page par
 * page. Purement informatif.
 */
public class WorthCommand implements CommandExecutor {

    private final Block2Core plugin;

    public WorthCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getWorthGUI().open(player);
        return true;
    }
}
