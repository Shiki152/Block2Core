package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.util.InventorySerializer;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gere les etats ephemeres des joueurs en ligne : vanish, god, fly (avec le
 * budget quotidien de 30 min pour le grade Master) et freeze.
 */
public class PlayerStateManager {

    private final Block2Core plugin;
    private BukkitTask flyBudgetTask;

    /** Joueurs actuellement en /staffmode (source de verite pour les joueurs en ligne). */
    private final Set<UUID> inStaffMode = ConcurrentHashMap.newKeySet();

    public PlayerStateManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void start() {
        // Decompte le budget de vol du grade Master, verifie chaque seconde
        flyBudgetTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickFlyBudget, 20L, 20L);
    }

    public void stop() {
        if (flyBudgetTask != null) flyBudgetTask.cancel();
    }

    // ---------------------------------------------------------------
    // VANISH
    // ---------------------------------------------------------------

    public void toggleVanish(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return;
        boolean newState = !data.isVanished();
        data.setVanished(newState);

        for (Player other : Bukkit.getOnlinePlayers()) {
            if (other.equals(player)) continue;
            if (newState && !other.hasPermission("block2core.bypass.vanishsee")) {
                other.hidePlayer(plugin, player);
            } else {
                other.showPlayer(plugin, player);
            }
        }
        player.sendMessage(TextUtil.parse(newState ? "<gray>Vanish <green>active." : "<gray>Vanish <red>desactive."));
    }

    public boolean isVanished(UUID uuid) {
        PlayerData data = plugin.getPlayerData(uuid);
        return data != null && data.isVanished();
    }

    /** A appliquer a un joueur qui vient de se connecter, pour qu'il ne voie pas les joueurs actuellement en vanish. */
    public void applyVanishVisibility(Player joining) {
        if (joining.hasPermission("block2core.bypass.vanishsee")) return;
        for (Player other : Bukkit.getOnlinePlayers()) {
            if (isVanished(other.getUniqueId())) {
                joining.hidePlayer(plugin, other);
            }
        }
    }

    // ---------------------------------------------------------------
    // GOD
    // ---------------------------------------------------------------

    public boolean toggleGod(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return false;
        boolean newState = !data.isGod();
        data.setGod(newState);
        return newState;
    }

    // ---------------------------------------------------------------
    // FREEZE
    // ---------------------------------------------------------------

    public boolean toggleFreeze(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return false;
        boolean newState = !data.isFrozen();
        data.setFrozen(newState);
        return newState;
    }

    // ---------------------------------------------------------------
    // FLY
    // ---------------------------------------------------------------

    public enum FlyDenyReason { NONE, NO_ACCESS, NO_BUDGET }

    public FlyDenyReason canToggleFly(PlayerData data) {
        if (data.isStaff()) return FlyDenyReason.NONE; // Fly illimite pour tout le staff
        Grade grade = data.getGrade();
        if (grade == Grade.PARTENAIRE) return FlyDenyReason.NONE; // Partenaire+ illimite
        if (grade == Grade.MASTER) {
            resetDailyBudgetIfNeeded(data);
            return data.getFlyTimeRemainingSeconds() > 0 ? FlyDenyReason.NONE : FlyDenyReason.NO_BUDGET;
        }
        return FlyDenyReason.NO_ACCESS;
    }

    public void toggleFly(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return;
        boolean newState = !data.isFlying();
        data.setFlying(newState);
        player.setAllowFlight(newState);
        player.setFlying(newState);
    }

    private void resetDailyBudgetIfNeeded(PlayerData data) {
        long today = LocalDate.now(ZoneId.systemDefault()).toEpochDay();
        if (data.getFlyLastResetEpochDay() != today) {
            data.setFlyLastResetEpochDay(today);
            data.setFlyTimeRemainingSeconds(plugin.getConfigManager().masterDailyFlySeconds());
            persistFlyBudget(data.getUuid(), data.getFlyTimeRemainingSeconds(), data.getFlyLastResetEpochDay());
        }
    }

    private void tickFlyBudget() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerData(player.getUniqueId());
            if (data == null || data.isStaff()) continue;
            if (data.getGrade() != Grade.MASTER) continue;
            if (!data.isFlying()) continue;

            resetDailyBudgetIfNeeded(data);
            long remaining = data.getFlyTimeRemainingSeconds() - 1;
            data.setFlyTimeRemainingSeconds(Math.max(0, remaining));

            // Sauvegarde en base toutes les 10s pendant le vol (et immediatement a l'epuisement),
            // sinon le budget n'est jamais persiste et un simple /relog reinitialise 30 minutes fraiches.
            if (remaining <= 0 || remaining % 10 == 0) {
                persistFlyBudget(player.getUniqueId(), data.getFlyTimeRemainingSeconds(), data.getFlyLastResetEpochDay());
            }

            if (remaining <= 0) {
                data.setFlying(false);
                player.setAllowFlight(false);
                player.setFlying(false);
                player.sendMessage(TextUtil.parse("<red>Ton temps de vol quotidien est epuise ! Reviens demain."));
            }
        }
    }

    public void persistFlyBudget(UUID uuid, long remainingSeconds, long lastResetDay) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "UPDATE b2c_players SET fly_remaining_seconds = ?, fly_last_reset_day = ? WHERE uuid = ?")) {
                statement.setInt(1, (int) remainingSeconds);
                statement.setLong(2, lastResetDay);
                statement.setString(3, uuid.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(java.util.logging.Level.WARNING, "Erreur sauvegarde budget de vol", exception);
            }
        });
    }

    // ---------------------------------------------------------------
    // STAFFMODE (bascule survie <-> creatif)
    // ---------------------------------------------------------------

    public boolean isInStaffMode(UUID uuid) {
        return inStaffMode.contains(uuid);
    }

    /** Bascule le joueur entre son inventaire de survie et un mode creatif dedie au staff. */
    public void toggleStaffMode(Player player) {
        if (inStaffMode.contains(player.getUniqueId())) {
            exitStaffMode(player, true);
        } else {
            enterStaffMode(player);
        }
    }

    private void enterStaffMode(Player player) {
        UUID uuid = player.getUniqueId();
        ItemStack[] contents = player.getInventory().getContents();
        ItemStack[] armor = player.getInventory().getArmorContents();
        ItemStack offhand = player.getInventory().getItemInOffHand();
        int expLevel = player.getLevel();
        float expProgress = player.getExp();
        GameMode previousMode = player.getGameMode();

        inStaffMode.add(uuid);
        // Sauvegarde en base AVANT de vider l'inventaire : si le serveur crash entre les deux,
        // l'inventaire de survie reste recuperable (voir restoreStaffModeIfNeeded, appele au login).
        persistStaffModeSnapshot(uuid, contents, armor, offhand, expLevel, expProgress, previousMode);

        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[armor.length]);
        player.getInventory().setItemInOffHand(null);
        player.setLevel(0);
        player.setExp(0);
        player.setGameMode(GameMode.CREATIVE);
        player.sendMessage(TextUtil.parse("<gold><bold>Mode staff active <gray>: inventaire de survie sauvegarde, passage en creatif."));
    }

    private void exitStaffMode(Player player, boolean sendMessage) {
        UUID uuid = player.getUniqueId();
        inStaffMode.remove(uuid);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            StaffModeSnapshot snapshot = loadStaffModeSnapshotBlocking(uuid);
            deleteStaffModeSnapshotBlocking(uuid);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                applySnapshotOrFallback(player, snapshot);
                if (sendMessage) {
                    player.sendMessage(TextUtil.parse("<gold><bold>Mode staff desactive <gray>: ton inventaire de survie a ete restaure."));
                }
            });
        });
    }

    /**
     * A appeler juste apres l'authentification d'un joueur (voir AuthManager#finalizeAuthentication) :
     * si une sauvegarde /staffmode existe encore pour lui en base, cela signifie qu'il s'est
     * deconnecte (crash ou /quit) sans avoir desactive le mode staff. Restaure automatiquement
     * son inventaire de survie plutot que de le laisser en creatif avec un inventaire vide.
     */
    public void restoreStaffModeIfNeeded(Player player) {
        UUID uuid = player.getUniqueId();
        inStaffMode.remove(uuid);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            StaffModeSnapshot snapshot = loadStaffModeSnapshotBlocking(uuid);
            if (snapshot == null) return;
            deleteStaffModeSnapshotBlocking(uuid);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                applySnapshotOrFallback(player, snapshot);
                player.sendMessage(TextUtil.parse(
                        "<yellow>Tu etais en mode staff lors de ta derniere deconnexion : ton inventaire de survie a ete restaure automatiquement."));
            });
        });
    }

    private void applySnapshotOrFallback(Player player, StaffModeSnapshot snapshot) {
        if (snapshot != null) {
            player.getInventory().setContents(snapshot.contents());
            player.getInventory().setArmorContents(snapshot.armor());
            player.getInventory().setItemInOffHand(snapshot.offhand());
            player.setLevel(snapshot.expLevel());
            player.setExp(snapshot.expProgress());
            player.setGameMode(snapshot.previousGameMode());
        } else {
            // Aucune sauvegarde (ne devrait arriver que si la ligne a deja ete consommee) :
            // on ne laisse jamais un joueur en creatif sans filet, on le repasse en survie.
            player.setGameMode(GameMode.SURVIVAL);
        }
    }

    private void persistStaffModeSnapshot(UUID uuid, ItemStack[] contents, ItemStack[] armor, ItemStack offhand,
                                           int expLevel, float expProgress, GameMode previousMode) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_staffmode (uuid, inventory, armor, offhand, exp_level, exp_progress, prev_gamemode, saved_at) " +
                                 "VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET inventory=excluded.inventory, " +
                                 "armor=excluded.armor, offhand=excluded.offhand, exp_level=excluded.exp_level, " +
                                 "exp_progress=excluded.exp_progress, prev_gamemode=excluded.prev_gamemode, saved_at=excluded.saved_at")) {
                statement.setString(1, uuid.toString());
                statement.setString(2, InventorySerializer.toBase64(contents));
                statement.setString(3, InventorySerializer.toBase64(armor));
                statement.setString(4, InventorySerializer.toBase64(new ItemStack[]{offhand}));
                statement.setInt(5, expLevel);
                statement.setFloat(6, expProgress);
                statement.setString(7, previousMode.name());
                statement.setLong(8, System.currentTimeMillis());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde snapshot staffmode", exception);
            }
        });
    }

    /** A appeler uniquement depuis un thread asynchrone (voir les deux appelants ci-dessus). */
    private StaffModeSnapshot loadStaffModeSnapshotBlocking(UUID uuid) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("SELECT * FROM b2c_staffmode WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (var rs = statement.executeQuery()) {
                if (!rs.next()) return null;
                ItemStack[] contents = InventorySerializer.fromBase64(rs.getString("inventory"));
                ItemStack[] armor = InventorySerializer.fromBase64(rs.getString("armor"));
                ItemStack[] offhandArray = InventorySerializer.fromBase64(rs.getString("offhand"));
                ItemStack offhand = offhandArray.length > 0 ? offhandArray[0] : null;
                GameMode previousMode;
                try {
                    previousMode = GameMode.valueOf(rs.getString("prev_gamemode"));
                } catch (Exception exception) {
                    previousMode = GameMode.SURVIVAL;
                }
                return new StaffModeSnapshot(contents, armor, offhand, rs.getInt("exp_level"), rs.getFloat("exp_progress"), previousMode);
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur lecture snapshot staffmode", exception);
            return null;
        }
    }

    private void deleteStaffModeSnapshotBlocking(UUID uuid) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("DELETE FROM b2c_staffmode WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            statement.executeUpdate();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur suppression snapshot staffmode", exception);
        }
    }

    private record StaffModeSnapshot(ItemStack[] contents, ItemStack[] armor, ItemStack offhand,
                                      int expLevel, float expProgress, GameMode previousGameMode) {
    }
}
