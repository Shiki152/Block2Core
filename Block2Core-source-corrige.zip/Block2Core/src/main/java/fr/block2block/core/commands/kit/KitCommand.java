package fr.block2block.core.commands.kit;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

public class KitCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public KitCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return true;

        if (args.length > 0 && args[0].equalsIgnoreCase("list")) {
            player.sendMessage(TextUtil.parse("<aqua><bold>--- KITS DISPONIBLES ---"));
            for (Grade grade : Grade.values()) {
                if (!plugin.getKitManager().isAllowed(data, grade)) continue;
                var kit = plugin.getKitManager().getKit(grade);
                player.sendMessage(TextUtil.parse("<gray>- <white>" + plugin.getConfigManager().gradeDisplayName(grade) +
                        " <gray>(cooldown " + TimeUtil.formatShort(kit.cooldownSeconds()) + ")"));
            }
            return true;
        }

        Grade targetGrade = data.getGrade();
        if (args.length > 0) {
            Grade parsed = Grade.fromKey(args[0]);
            if (parsed == null) {
                player.sendMessage(TextUtil.parse("<red>Kit inconnu : " + args[0]));
                return true;
            }
            targetGrade = parsed;
        }

        final Grade finalTargetGrade = targetGrade;
        plugin.getKitManager().claim(player, targetGrade, result -> {
            if (result.remainingCooldownSeconds() < 0) {
                player.sendMessage(TextUtil.parse("<red>Tu n'as pas acces a ce kit (grade insuffisant)."));
            } else if (result.remainingCooldownSeconds() > 0) {
                player.sendMessage(TextUtil.parse("<red>Kit deja reclame ! Disponible dans " + TimeUtil.formatShort(result.remainingCooldownSeconds())));
            } else if (result.success()) {
                player.sendMessage(TextUtil.parse("<green>Kit " + plugin.getConfigManager().gradeDisplayName(finalTargetGrade) + " recupere !"));
            }
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("paysan", "aventurier", "aguerris", "master", "partenaire", "list").stream()
                    .filter(o -> o.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
