package fr.block2block.core.data;

import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Definition d'un kit (charge depuis config.yml pour chaque grade).
 */
public record Kit(String gradeKey, long cooldownSeconds, double money, List<ItemStack> items) {
}
