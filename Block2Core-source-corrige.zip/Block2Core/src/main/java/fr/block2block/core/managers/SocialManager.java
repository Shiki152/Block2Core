package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Regroupe plusieurs etats sociaux/ephemeres : derniere position (/back),
 * liste d'ignores persistante, demandes de teleportation (/tpa), cible
 * de reponse (/reply) et cooldown de /rtp.
 * <p>
 * Toutes ces caches en memoire sont periodiquement purgees par
 * {@link CacheCleanupManager} pour eviter une croissance illimitee au fil
 * des mois (un serveur avec des milliers de joueurs distincts au fil du
 * temps verrait sinon ces Map grossir indefiniment).
 */
public class SocialManager {

    private static final long BACK_RETENTION_MILLIS = 7L * 24 * 3600 * 1000; // 7 jours
    private static final long REPLY_RETENTION_MILLIS = 3600 * 1000; // 1 heure
    private static final long TPA_RETENTION_MILLIS = 60_000L; // 60s (coherent avec l'expiration existante)

    private final Block2Core plugin;

    private final Map<UUID, TimestampedLocation> backLocations = new ConcurrentHashMap<>();
    private final Map<UUID, Set<UUID>> ignoreCache = new ConcurrentHashMap<>();
    private final Map<UUID, TpaRequest> tpaRequests = new ConcurrentHashMap<>(); // target -> requete
    private final Map<UUID, TimestampedUuid> lastMessageSender = new ConcurrentHashMap<>(); // destinataire -> dernier expediteur
    private final Map<UUID, Long> rtpCooldowns = new ConcurrentHashMap<>(); // uuid -> timestamp dernier /rtp

    public SocialManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // BACK
    // ---------------------------------------------------------------

    public void saveBackLocation(Player player) {
        backLocations.put(player.getUniqueId(), new TimestampedLocation(player.getLocation().clone(), System.currentTimeMillis()));
    }

    public Location getBackLocation(UUID uuid) {
        TimestampedLocation entry = backLocations.get(uuid);
        return entry != null ? entry.location() : null;
    }

    private record TimestampedLocation(Location location, long timestamp) {
    }

    // ---------------------------------------------------------------
    // IGNORE (persistant)
    // ---------------------------------------------------------------

    public void loadIgnores(UUID uuid, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Set<UUID> ignored = new HashSet<>();
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT ignored_uuid FROM b2c_ignores WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) ignored.add(UUID.fromString(rs.getString("ignored_uuid")));
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement ignores", exception);
            }
            ignoreCache.put(uuid, ignored);
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void unloadIgnores(UUID uuid) {
        ignoreCache.remove(uuid);
    }

    public boolean isIgnoring(UUID uuid, UUID target) {
        return ignoreCache.getOrDefault(uuid, Set.of()).contains(target);
    }

    /** Bascule l'etat d'ignore, retourne le nouvel etat (true = maintenant ignore). */
    public boolean toggleIgnore(UUID uuid, UUID target) {
        Set<UUID> set = ignoreCache.computeIfAbsent(uuid, k -> ConcurrentHashMap.newKeySet());
        boolean nowIgnoring = !set.contains(target);
        if (nowIgnoring) {
            set.add(target);
            persistIgnore(uuid, target, true);
        } else {
            set.remove(target);
            persistIgnore(uuid, target, false);
        }
        return nowIgnoring;
    }

    private void persistIgnore(UUID uuid, UUID target, boolean add) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                if (add) {
                    try (var statement = connection.prepareStatement("INSERT OR IGNORE INTO b2c_ignores (uuid, ignored_uuid) VALUES (?, ?)")) {
                        statement.setString(1, uuid.toString());
                        statement.setString(2, target.toString());
                        statement.executeUpdate();
                    }
                } else {
                    try (var statement = connection.prepareStatement("DELETE FROM b2c_ignores WHERE uuid = ? AND ignored_uuid = ?")) {
                        statement.setString(1, uuid.toString());
                        statement.setString(2, target.toString());
                        statement.executeUpdate();
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde ignore", exception);
            }
        });
    }

    // ---------------------------------------------------------------
    // TPA
    // ---------------------------------------------------------------

    public void createTpaRequest(UUID requester, UUID target) {
        tpaRequests.put(target, new TpaRequest(requester, System.currentTimeMillis()));
    }

    public TpaRequest getTpaRequest(UUID target) {
        TpaRequest request = tpaRequests.get(target);
        if (request != null && System.currentTimeMillis() - request.timestamp() > TPA_RETENTION_MILLIS) {
            tpaRequests.remove(target);
            return null;
        }
        return request;
    }

    public void clearTpaRequest(UUID target) {
        tpaRequests.remove(target);
    }

    public record TpaRequest(UUID requester, long timestamp) {
    }

    // ---------------------------------------------------------------
    // MSG / REPLY
    // ---------------------------------------------------------------

    public void registerMessage(UUID from, UUID to) {
        lastMessageSender.put(to, new TimestampedUuid(from, System.currentTimeMillis()));
    }

    public UUID getLastSender(UUID recipient) {
        TimestampedUuid entry = lastMessageSender.get(recipient);
        return entry != null ? entry.uuid() : null;
    }

    private record TimestampedUuid(UUID uuid, long timestamp) {
    }

    // ---------------------------------------------------------------
    // RTP (cooldown)
    // ---------------------------------------------------------------

    public long getRtpLastUse(UUID uuid) {
        return rtpCooldowns.getOrDefault(uuid, 0L);
    }

    public void setRtpLastUse(UUID uuid) {
        rtpCooldowns.put(uuid, System.currentTimeMillis());
    }

    // ---------------------------------------------------------------
    // NETTOYAGE PERIODIQUE (voir CacheCleanupManager)
    // ---------------------------------------------------------------

    /** Purge les entrees perimees de toutes les caches en memoire de ce manager. */
    public void cleanupStaleEntries() {
        long now = System.currentTimeMillis();
        backLocations.values().removeIf(entry -> now - entry.timestamp() > BACK_RETENTION_MILLIS);
        lastMessageSender.values().removeIf(entry -> now - entry.timestamp() > REPLY_RETENTION_MILLIS);
        tpaRequests.values().removeIf(request -> now - request.timestamp() > TPA_RETENTION_MILLIS);
        long rtpCooldownMillis = plugin.getConfigManager().rtpCooldownMinutes() * 60_000L;
        rtpCooldowns.entrySet().removeIf(e -> now - e.getValue() > rtpCooldownMillis);
    }
}
