package fr.block2block.core.commands.claims;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.ClaimChunk;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.managers.ClaimManager;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Gere /claim, /unclaim, /trust et /claims list.
 */
public class ClaimCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public ClaimCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase()) {
            case "claim" -> claim(sender);
            case "unclaim" -> unclaim(sender);
            case "trust" -> trust(sender, args);
            case "claims" -> claimsList(sender, args);
            default -> false;
        };
    }

    private boolean claim(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return true;
        int limit = plugin.getConfigManager().claimLimit(data.getGrade());

        plugin.getClaimManager().claimForPlayer(player, limit, result -> {
            switch (result) {
                case SUCCESS -> player.sendMessage(TextUtil.parse("<green>Chunk reclame ! (" +
                        (plugin.getClaimManager().countOwnedByPlayer(player.getUniqueId())) + "/" + limit + ")"));
                case ALREADY_CLAIMED -> player.sendMessage(TextUtil.parse("<red>Ce chunk est deja reclame."));
                case LIMIT_REACHED -> player.sendMessage(TextUtil.parse("<red>Tu as atteint ta limite de claims (" + limit + ")."));
                default -> {
                }
            }
        });
        return true;
    }

    private boolean unclaim(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        boolean isAdmin = player.hasPermission("block2core.command.unesco");
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        Integer teamId = data != null ? data.getTeamId() : null;
        plugin.getClaimManager().unclaim(player, teamId, isAdmin, result -> {
            switch (result) {
                case SUCCESS -> player.sendMessage(TextUtil.parse("<green>Chunk libere."));
                case NOT_CLAIMED -> player.sendMessage(TextUtil.parse("<red>Ce chunk n'est pas reclame."));
                case NO_PERMISSION -> player.sendMessage(TextUtil.parse("<red>Tu ne peux pas liberer ce chunk."));
                default -> {
                }
            }
        });
        return true;
    }

    private boolean trust(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /trust <joueur>"));
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        plugin.getClaimManager().trust(player.getUniqueId(), target.getUniqueId());
        player.sendMessage(TextUtil.parse("<green>" + args[0] + " peut maintenant construire dans tes claims."));
        return true;
    }

    private boolean claimsList(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        List<ClaimChunk> claims = plugin.getClaimManager().listOwnedByPlayer(player.getUniqueId());
        player.sendMessage(TextUtil.parse("<aqua><bold>--- TES CLAIMS (" + claims.size() + ") ---"));
        for (ClaimChunk claim : claims) {
            player.sendMessage(TextUtil.parse("<gray>- <white>" + claim.world() + " <gray>chunk (" + claim.chunkX() + ", " + claim.chunkZ() + ")"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("trust") && args.length == 1) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (command.getName().equalsIgnoreCase("claims") && args.length == 1) {
            return List.of("list").stream().filter(o -> o.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
