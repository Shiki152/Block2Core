package fr.block2block.core.listeners;

import fr.block2block.core.Block2Core;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.Locale;

/**
 * Detecte les commandes tapees par un joueur en cours de tutoriel (/tuto) et
 * fait progresser les etapes. Priorite MONITOR + ignoreCancelled : ne
 * traite que les commandes reellement executees (pas bloquees par l'auth).
 */
public class TutorialListener implements Listener {

    private final Block2Core plugin;

    public TutorialListener(Block2Core plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        plugin.getTutorialManager().onCommandTyped(event.getPlayer(), event.getMessage().toLowerCase(Locale.ROOT));
    }
}
