package fr.block2block.core.data;

public record Warp(String name, String world, double x, double y, double z, float yaw, float pitch, String creator) {
}
