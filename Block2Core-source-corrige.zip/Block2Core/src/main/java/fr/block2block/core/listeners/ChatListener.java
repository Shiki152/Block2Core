package fr.block2block.core.listeners;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.PlayerTeam;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.Iterator;

/**
 * Gere le format de chat impose par le cahier des charges :
 *   GRADE_BOLD_COLOR TITRE_BOLD_COLOR pseudo : message   (aucun [ ] ni ( ))
 * ainsi que mutechat, slowchat, ignore et le mode chat d'equipe.
 * <p>
 * Le grade staff (s'il existe) prevaut sur le grade joueur dans le slot de
 * grade : un choix de conception necessaire car le format n'a qu'un seul
 * emplacement de grade (voir le README pour le detail de cette decision).
 */
public class ChatListener implements Listener {

    private final Block2Core plugin;

    public ChatListener(Block2Core plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return;

        if (!data.isAuthenticated()) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>Connecte-toi d'abord avec /login ou /register."));
            return;
        }

        if (plugin.getChatModerationManager().isChatMuted() && !player.hasPermission("block2core.bypass.mutechat")) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>Le chat est actuellement desactive par le staff."));
            return;
        }

        if (data.isMuted() && !player.hasPermission("block2core.bypass.mutechat")) {
            event.setCancelled(true);
            String remaining = data.getMutedUntilMillis() == -1 ? "Permanent" : TimeUtil.formatEpochRemaining(data.getMutedUntilMillis());
            player.sendMessage(TextUtil.parse(plugin.getConfigManager().sanctionScreen("mute", java.util.Map.of(
                    "raison", data.getMutedReason() != null ? data.getMutedReason() : "Aucune raison",
                    "duree", remaining))));
            return;
        }

        if (!player.hasPermission("block2core.bypass.slowchat")) {
            long wait = plugin.getChatModerationManager().checkAndUpdateSlowChat(player.getUniqueId());
            if (wait > 0) {
                event.setCancelled(true);
                player.sendMessage(TextUtil.parse("<red>Attends encore " + wait + "s avant de reparler."));
                return;
            }
        }

        String plainMessage = PlainTextComponentSerializer.plainText().serialize(event.message());

        if (data.isTeamChatMode()) {
            event.setCancelled(true);
            sendTeamChat(player, data, plainMessage);
            return;
        }

        // Filtrer les destinataires qui ignorent cet expediteur
        Iterator<net.kyori.adventure.audience.Audience> iterator = event.viewers().iterator();
        while (iterator.hasNext()) {
            var viewer = iterator.next();
            if (viewer instanceof Player viewerPlayer
                    && plugin.getSocialManager().isIgnoring(viewerPlayer.getUniqueId(), player.getUniqueId())) {
                iterator.remove();
            }
        }

        event.renderer((source, sourceDisplayName, message, viewer) -> buildFormattedMessage(data, player.getName(), message));
    }

    private Component buildFormattedMessage(PlayerData data, String pseudo, Component message) {
        Component gradeComponent = plugin.getRankManager().activeRankFormatted(data);

        Component result = gradeComponent;
        if (data.getTitle() != null && !data.getTitle().isBlank()) {
            result = result.append(Component.space()).append(plugin.getQuestManager().formatTitle(data.getTitle()));
        }
        result = result.append(Component.space())
                .append(TextUtil.parse("<white>" + pseudo))
                .append(TextUtil.parse(" <white>: "))
                .append(message.color(net.kyori.adventure.text.format.NamedTextColor.WHITE));
        return result;
    }

    private void sendTeamChat(Player player, PlayerData data, String message) {
        if (data.getTeamId() == null) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas d'equipe. Chat d'equipe desactive."));
            data.setTeamChatMode(false);
            return;
        }
        PlayerTeam team = plugin.getTeamManager().getTeam(data.getTeamId());
        if (team == null) return;

        Component formatted = TextUtil.parse("<aqua><bold>TEAM <gray>» <white>" + player.getName() + " <gray>: <white>" + message);
        for (var memberUuid : team.getMembers().keySet()) {
            Player member = plugin.getServer().getPlayer(memberUuid);
            if (member != null) {
                member.sendMessage(formatted);
            }
        }
    }
}
