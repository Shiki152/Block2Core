package fr.block2block.core.commands.moderation;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Punishment;
import fr.block2block.core.managers.LogManager;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Dispatcher pour les outils staff "avances" : vanish, invsee, enderchest,
 * tp, tphere, tpall, tppos, back, freeze, jail, unjail, mutechat,
 * unmutechat, slowchat, history, logs, co.
 */
public class StaffAdvancedCommand implements CommandExecutor, TabCompleter {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM HH:mm");

    private final Block2Core plugin;

    public StaffAdvancedCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase()) {
            case "vanish" -> vanish(sender);
            case "invsee" -> invsee(sender, args);
            case "enderchest" -> enderchest(sender, args);
            case "tp" -> tp(sender, args);
            case "tphere" -> tphere(sender, args);
            case "tpall" -> tpall(sender);
            case "tppos" -> tppos(sender, args);
            case "back" -> back(sender);
            case "freeze" -> freeze(sender, args);
            case "jail" -> jail(sender, args);
            case "unjail" -> unjail(sender, args);
            case "mutechat" -> mutechat(sender, true);
            case "unmutechat" -> mutechat(sender, false);
            case "slowchat" -> slowchat(sender, args);
            case "history" -> history(sender, args);
            case "logs" -> logs(sender, args);
            case "co" -> co(sender, args);
            default -> false;
        };
    }

    private boolean vanish(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getPlayerStateManager().toggleVanish(player);
        return true;
    }

    private boolean invsee(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /invsee <joueur>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        plugin.getInvSeeGUI().open(player, target);
        return true;
    }

    private boolean enderchest(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /enderchest <joueur>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        player.openInventory(target.getEnderChest());
        return true;
    }

    private boolean tp(CommandSender sender, String[] args) {
        if (args.length == 1) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Usage : /tp <joueur1> <joueur2>");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
                return true;
            }
            plugin.getSocialManager().saveBackLocation(player);
            player.teleport(target);
            sender.sendMessage(TextUtil.parse("<green>Teleporte vers " + target.getName()));
            return true;
        }
        if (args.length >= 2) {
            Player from = Bukkit.getPlayerExact(args[0]);
            Player to = Bukkit.getPlayerExact(args[1]);
            if (from == null || to == null) {
                sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
                return true;
            }
            plugin.getSocialManager().saveBackLocation(from);
            from.teleport(to);
            sender.sendMessage(TextUtil.parse("<green>" + from.getName() + " teleporte vers " + to.getName()));
            return true;
        }
        sender.sendMessage(TextUtil.parse("<yellow>Usage : /tp <joueur> [joueur2]"));
        return true;
    }

    private boolean tphere(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tphere <joueur>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        plugin.getSocialManager().saveBackLocation(target);
        target.teleport(player);
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " teleporte a toi."));
        return true;
    }

    private boolean tpall(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.getUniqueId().equals(player.getUniqueId())) {
                plugin.getSocialManager().saveBackLocation(online);
                online.teleport(player);
            }
        }
        sender.sendMessage(TextUtil.parse("<green>Tous les joueurs ont ete teleportes a toi."));
        return true;
    }

    private boolean tppos(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tppos <x> <y> <z> [monde]"));
            return true;
        }
        try {
            double x = Double.parseDouble(args[0]);
            double y = Double.parseDouble(args[1]);
            double z = Double.parseDouble(args[2]);
            World world = args.length > 3 ? Bukkit.getWorld(args[3]) : player.getWorld();
            if (world == null) {
                sender.sendMessage(TextUtil.parse("<red>Monde introuvable."));
                return true;
            }
            plugin.getSocialManager().saveBackLocation(player);
            player.teleport(new Location(world, x, y, z));
            sender.sendMessage(TextUtil.parse("<green>Teleporte."));
        } catch (NumberFormatException exception) {
            sender.sendMessage(TextUtil.parse("<red>Coordonnees invalides."));
        }
        return true;
    }

    private boolean back(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        Location location = plugin.getSocialManager().getBackLocation(player.getUniqueId());
        if (location == null) {
            player.sendMessage(TextUtil.parse("<red>Aucune position precedente enregistree."));
            return true;
        }
        player.teleport(location);
        player.sendMessage(TextUtil.parse("<green>Retour a la position precedente."));
        return true;
    }

    private boolean freeze(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /freeze <joueur>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        boolean newState = plugin.getPlayerStateManager().toggleFreeze(target);
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " " + (newState ? "gele." : "libere.")));
        target.sendMessage(TextUtil.parse(newState ? "<red><bold>Tu as ete gele par le staff." : "<green>Tu n'es plus gele."));
        return true;
    }

    private boolean jail(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /jail <joueur> [duree] [nom_prison]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        String jailName = args.length > 2 ? args[2] : "default";
        if (!plugin.getJailManager().jailExists(jailName)) {
            sender.sendMessage(TextUtil.parse("<red>Prison inconnue : " + jailName));
            return true;
        }
        long seconds = 0;
        if (args.length > 1) {
            try {
                seconds = TimeUtil.parseSeconds(args[1]);
            } catch (IllegalArgumentException exception) {
                sender.sendMessage(TextUtil.parse("<red>Duree invalide."));
                return true;
            }
        }
        plugin.getJailManager().jail(target, jailName, seconds, sender.getName());
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " emprisonne."));
        return true;
    }

    private boolean unjail(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /unjail <joueur>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        plugin.getJailManager().unjail(target.getUniqueId());
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " libere de prison."));
        return true;
    }

    private boolean mutechat(CommandSender sender, boolean muted) {
        plugin.getChatModerationManager().setChatMuted(muted);
        Bukkit.getServer().sendMessage(TextUtil.parse(muted
                ? "<red><bold>Le chat a ete coupe par " + sender.getName()
                : "<green><bold>Le chat a ete reactive par " + sender.getName()));
        return true;
    }

    private boolean slowchat(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /slowchat <secondes|off>"));
            return true;
        }
        if (args[0].equalsIgnoreCase("off")) {
            plugin.getChatModerationManager().setSlowChatDelaySeconds(0);
            Bukkit.getServer().sendMessage(TextUtil.parse("<green>Slowchat desactive."));
            return true;
        }
        try {
            long seconds = Long.parseLong(args[0]);
            plugin.getChatModerationManager().setSlowChatDelaySeconds(seconds);
            Bukkit.getServer().sendMessage(TextUtil.parse("<yellow>Slowchat active : " + seconds + "s entre chaque message."));
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", java.util.Map.of("valeur", args[0])));
        }
        return true;
    }

    private boolean history(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /history <joueur>"));
            return true;
        }
        plugin.getPunishmentManager().getHistory(args[0], list -> {
            sender.sendMessage(TextUtil.parse("<aqua><bold>--- HISTORIQUE DE " + args[0] + " ---"));
            if (list.isEmpty()) {
                sender.sendMessage(TextUtil.parse("<gray>Aucune sanction."));
                return;
            }
            for (Punishment p : list) {
                sender.sendMessage(TextUtil.parse("<gray>[" + p.type() + "] <white>" + p.reason() +
                        " <gray>(" + p.staffName() + ", " + DATE_FORMAT.format(new Date(p.startMillis())) + ")"));
            }
        });
        return true;
    }

    private boolean logs(CommandSender sender, String[] args) {
        java.util.UUID target = null;
        int page = 1;
        if (args.length > 0) {
            try {
                page = Integer.parseInt(args[0]);
            } catch (NumberFormatException exception) {
                Player online = Bukkit.getPlayer(args[0]);
                target = online != null ? online.getUniqueId() : Bukkit.getOfflinePlayer(args[0]).getUniqueId();
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
        int finalPage = page;
        plugin.getLogManager().getLogs(target, page, entries -> {
            sender.sendMessage(TextUtil.parse("<aqua><bold>--- LOGS (page " + finalPage + ") ---"));
            if (entries.isEmpty()) {
                sender.sendMessage(TextUtil.parse("<gray>Aucun log."));
                return;
            }
            for (LogManager.LogEntry entry : entries) {
                sender.sendMessage(TextUtil.parse("<gray>[" + DATE_FORMAT.format(new Date(entry.timestamp())) + "] <white>" +
                        entry.staffName() + " <gray>- " + entry.action() + " <gray>: <white>" + entry.data()));
            }
        });
        return true;
    }

    private boolean co(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /co <i|inspect|lookup|rollback> [rayon] [minutes] [joueur]"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "i", "inspect" -> {
                boolean now = plugin.getLogManager().toggleInspect(player.getUniqueId());
                player.sendMessage(TextUtil.parse(now ? "<green>Mode inspection active. Clique un bloc pour voir son historique."
                        : "<red>Mode inspection desactive."));
            }
            case "lookup" -> {
                int radius = args.length > 1 ? parseIntOrDefault(args[1], 10) : 10;
                int minutes = args.length > 2 ? parseIntOrDefault(args[2], 60) : 60;
                String playerFilter = args.length > 3 ? args[3] : null;
                plugin.getLogManager().lookup(player.getLocation(), radius, minutes, playerFilter, entries -> {
                    player.sendMessage(TextUtil.parse("<aqua><bold>--- /co lookup (" + entries.size() + " resultats) ---"));
                    for (var entry : entries.stream().limit(15).toList()) {
                        player.sendMessage(TextUtil.parse("<gray>" + entry.playerName() + " <white>" + entry.action() +
                                " <gray>" + entry.blockType() + " <dark_gray>(" + entry.x() + "," + entry.y() + "," + entry.z() + ")"));
                    }
                });
            }
            case "rollback" -> {
                int radius = args.length > 1 ? parseIntOrDefault(args[1], 10) : 10;
                int minutes = args.length > 2 ? parseIntOrDefault(args[2], 60) : 60;
                String playerFilter = args.length > 3 ? args[3] : null;
                plugin.getLogManager().rollback(player.getLocation(), radius, minutes, playerFilter, count ->
                        player.sendMessage(TextUtil.parse("<green>" + count + " modifications annulees.")));
            }
            default -> player.sendMessage(TextUtil.parse("<yellow>Usage : /co <i|inspect|lookup|rollback> [rayon] [minutes] [joueur]"));
        }
        return true;
    }

    private int parseIntOrDefault(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException exception) {
            return fallback;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmdName = command.getName().toLowerCase();
        if (args.length == 1 && List.of("invsee", "enderchest", "tp", "tphere", "freeze", "jail", "unjail", "history", "logs").contains(cmdName)) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[0]);
        }
        if (cmdName.equals("co") && args.length == 1) {
            return filter(List.of("i", "inspect", "lookup", "rollback"), args[0]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
