package fr.block2block.core.data;

import java.util.Locale;

/**
 * Grades joueurs, dans l'ordre de progression.
 * Les valeurs (couleur, cout de rankup, playtime requis...) sont chargees
 * depuis config.yml par le ConfigManager / RankManager : cet enum ne
 * porte que l'identite et l'ordre des grades.
 */
public enum Grade {
    PAYSAN,
    AVENTURIER,
    AGUERRIS,
    MASTER,
    PARTENAIRE;

    /** Cle utilisee dans config.yml (ex: "paysan"). */
    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public int level() {
        // 1-indexe : Paysan = 1, Partenaire = 5 (utilise pour la formule des claims)
        return ordinal() + 1;
    }

    public Grade next() {
        Grade[] values = values();
        int next = ordinal() + 1;
        return next < values.length ? values[next] : null;
    }

    public boolean isMax() {
        return this == PARTENAIRE;
    }

    public static Grade fromKey(String key) {
        if (key == null) return null;
        for (Grade grade : values()) {
            if (grade.key().equalsIgnoreCase(key)) {
                return grade;
            }
        }
        return null;
    }
}
