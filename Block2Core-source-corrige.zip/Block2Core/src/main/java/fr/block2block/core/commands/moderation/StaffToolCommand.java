package fr.block2block.core.commands.moderation;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.managers.PlayerStateManager;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Dispatcher pour les outils staff "simples" : gm, fly, god, heal, feed,
 * repair, clear, clearlag, kill, sudo, broadcast, staffchat, stafflist.
 */
public class StaffToolCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public StaffToolCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase()) {
            case "gm" -> gamemode(sender, args);
            case "fly" -> fly(sender, args);
            case "god" -> god(sender, args);
            case "heal" -> heal(sender, args);
            case "feed" -> feed(sender, args);
            case "repair" -> repair(sender, args);
            case "clear" -> clear(sender, args);
            case "clearlag" -> clearlag(sender);
            case "kill" -> kill(sender, args);
            case "sudo" -> sudo(sender, args);
            case "broadcast" -> broadcast(sender, args);
            case "staffchat" -> staffchat(sender, args);
            case "stafflist" -> stafflist(sender);
            default -> false;
        };
    }

    private Player resolveTarget(CommandSender sender, String[] args, int index) {
        if (args.length > index) return Bukkit.getPlayerExact(args[index]);
        return sender instanceof Player p ? p : null;
    }

    private boolean gamemode(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /gm <0-3|survival|creative|adventure|spectator> [joueur]"));
            return true;
        }
        Player target = resolveTarget(sender, args, 1);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        GameMode mode = switch (args[0].toLowerCase()) {
            case "0", "survival", "s" -> GameMode.SURVIVAL;
            case "1", "creative", "c" -> GameMode.CREATIVE;
            case "2", "adventure", "a" -> GameMode.ADVENTURE;
            case "3", "spectator", "sp" -> GameMode.SPECTATOR;
            default -> null;
        };
        if (mode == null) {
            sender.sendMessage(TextUtil.parse("<red>Mode de jeu invalide."));
            return true;
        }
        target.setGameMode(mode);
        sender.sendMessage(TextUtil.parse("<green>Mode de jeu de " + target.getName() + " : " + mode.name()));
        return true;
    }

    private boolean fly(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 0);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        PlayerData data = plugin.getPlayerData(target.getUniqueId());
        if (data == null) return true;

        boolean self = sender instanceof Player p && p.getUniqueId().equals(target.getUniqueId());
        if (self) {
            PlayerStateManager.FlyDenyReason reason = plugin.getPlayerStateManager().canToggleFly(target, data);
            if (reason == PlayerStateManager.FlyDenyReason.NO_ACCESS) {
                sender.sendMessage(TextUtil.parse("<red>Ton grade ne te donne pas acces au vol."));
                return true;
            }
            if (reason == PlayerStateManager.FlyDenyReason.NO_BUDGET) {
                sender.sendMessage(TextUtil.parse("<red>Tu as epuise ton temps de vol quotidien (Master : 30min/jour)."));
                return true;
            }
        }
        plugin.getPlayerStateManager().toggleFly(target);
        sender.sendMessage(TextUtil.parse("<green>Vol " + (data.isFlying() ? "active" : "desactive") + " pour " + target.getName()));
        return true;
    }

    private boolean god(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 0);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        boolean newState = plugin.getPlayerStateManager().toggleGod(target);
        target.sendMessage(TextUtil.parse("<green>God mode " + (newState ? "active" : "desactive") + "."));
        return true;
    }

    private boolean heal(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 0);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        var maxHealthAttribute = target.getAttribute(Attribute.MAX_HEALTH);
        target.setHealth(maxHealthAttribute != null ? maxHealthAttribute.getValue() : 20);
        target.setFireTicks(0);
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " a ete soigne."));
        return true;
    }

    private boolean feed(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 0);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        target.setFoodLevel(20);
        target.setSaturation(20);
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " a ete rassasie."));
        return true;
    }

    private boolean repair(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        boolean all = args.length > 0 && args[0].equalsIgnoreCase("all");
        if (all) {
            for (var item : player.getInventory().getArmorContents()) repairItem(item);
            for (var item : player.getInventory().getContents()) repairItem(item);
            player.sendMessage(TextUtil.parse("<green>Tout ton equipement a ete repare."));
        } else {
            repairItem(player.getInventory().getItemInMainHand());
            player.sendMessage(TextUtil.parse("<green>Item en main repare."));
        }
        return true;
    }

    private void repairItem(org.bukkit.inventory.ItemStack item) {
        if (item == null) return;
        if (item.getItemMeta() instanceof org.bukkit.inventory.meta.Damageable damageable) {
            damageable.setDamage(0);
            item.setItemMeta((org.bukkit.inventory.meta.ItemMeta) damageable);
        }
    }

    private boolean clear(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 0);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        target.getInventory().clear();
        target.getInventory().setArmorContents(null);
        sender.sendMessage(TextUtil.parse("<green>Inventaire de " + target.getName() + " vide."));
        return true;
    }

    private boolean clearlag(CommandSender sender) {
        int removed = 0;
        for (var world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity instanceof org.bukkit.entity.Item || entity instanceof org.bukkit.entity.ExperienceOrb) {
                    entity.remove();
                    removed++;
                }
            }
        }
        sender.sendMessage(TextUtil.parse("<green>" + removed + " entites supprimees (clearlag)."));
        return true;
    }

    private boolean kill(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 0);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        target.setHealth(0);
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " a ete tue."));
        return true;
    }

    private boolean sudo(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /sudo <joueur> <commande>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        String cmd = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        Bukkit.dispatchCommand(target, cmd);
        sender.sendMessage(TextUtil.parse("<green>Commande executee par " + target.getName() + " : " + cmd));
        return true;
    }

    private boolean broadcast(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /broadcast <message>"));
            return true;
        }
        String message = String.join(" ", args);
        Bukkit.getServer().sendMessage(TextUtil.parse("<gold><bold>ANNONCE <gray>» <white>" + message));
        return true;
    }

    private boolean staffchat(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /staffchat <message>"));
            return true;
        }
        String message = String.join(" ", args);
        var formatted = TextUtil.parse("<dark_red><bold>STAFF <gray>» <white>" + sender.getName() + " <gray>: <white>" + message);
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.hasPermission("block2core.command.staffchat")) {
                online.sendMessage(formatted);
            }
        }
        Bukkit.getConsoleSender().sendMessage(formatted);
        return true;
    }

    private boolean stafflist(CommandSender sender) {
        sender.sendMessage(TextUtil.parse("<red><bold>--- STAFF CONNECTE ---"));
        boolean any = false;
        for (Player online : Bukkit.getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerData(online.getUniqueId());
            if (data != null && data.getStaffRank() != null) {
                sender.sendMessage(plugin.getConfigManager().staffFormatted(data.getStaffRank()).append(TextUtil.parse(" <white>" + online.getName())));
                any = true;
            }
        }
        if (!any) sender.sendMessage(TextUtil.parse("<gray>Aucun staff connecte."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmdName = command.getName().toLowerCase();
        if (cmdName.equals("gm") && args.length == 1) {
            return filter(List.of("survival", "creative", "adventure", "spectator"), args[0]);
        }
        if (args.length == 1 && List.of("fly", "god", "heal", "feed", "clear", "kill", "sudo", "gm").contains(cmdName)) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[0]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
