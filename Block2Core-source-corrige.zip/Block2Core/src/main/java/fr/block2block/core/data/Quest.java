package fr.block2block.core.data;

/**
 * Definition d'une quete. Les 90 quetes du serveur (30 par QuestDifficulty) sont fournies
 * par defaut et fixes : il n'existe plus de commande pour en creer/modifier depuis la
 * version ou l'admin ne peut plus en ajouter (voir QuestManager).
 *
 * @param target      nom du Material (BLOCK_BREAK/BLOCK_PLACE) ou de l'EntityType (MOB_KILL), null pour "n'importe lequel"
 * @param rewardTitle titre/tag debloque (peut etre null si aucun)
 * @param titleColor  couleur MiniMessage (ex "<gold>") du tag ci-dessus ; null = couleur par defaut (titles.color)
 */
public record Quest(int id, String name, String description, QuestDifficulty difficulty, QuestType type,
                     String target, int targetAmount, double rewardCoins, String rewardTitle, String titleColor) {
}
