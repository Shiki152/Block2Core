package fr.block2block.core.data;

/**
 * Definition d'une quete creee par le staff (/quest admin create).
 *
 * @param target     nom du Material (BLOCK_BREAK/BLOCK_PLACE) ou de l'EntityType (MOB_KILL), null pour CUSTOM
 * @param rewardTitle titre de quete debloque (peut etre null si aucun)
 */
public record Quest(int id, String name, String description, QuestType type, String target,
                     int targetAmount, double rewardCoins, String rewardTitle) {
}
