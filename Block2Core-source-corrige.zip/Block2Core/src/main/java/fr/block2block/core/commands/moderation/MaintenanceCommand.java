package fr.block2block.core.commands.moderation;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /maintenance [on|off] : active/desactive le mode maintenance (seuls le
 * staff, les OP et les joueurs whitelistes peuvent se connecter).
 * /maintenance whitelist add|remove|list <joueur> : gere les exceptions.
 */
public class MaintenanceCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public MaintenanceCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        var config = plugin.getConfigManager();

        if (args.length > 0 && args[0].equalsIgnoreCase("whitelist")) {
            return handleWhitelist(sender, args);
        }

        boolean newState;
        if (args.length > 0) {
            if (args[0].equalsIgnoreCase("on")) newState = true;
            else if (args[0].equalsIgnoreCase("off")) newState = false;
            else {
                sender.sendMessage(TextUtil.parse("<yellow>Usage : /maintenance [on|off] ou /maintenance whitelist add|remove|list <joueur>"));
                return true;
            }
        } else {
            newState = !config.maintenanceEnabled();
        }

        config.setMaintenanceEnabled(newState);
        sender.sendMessage(TextUtil.parse(newState
                ? "<green>Mode maintenance <bold>ACTIVE<reset><green>. Seuls le staff/OP/whitelist peuvent rejoindre."
                : "<green>Mode maintenance <bold>DESACTIVE<reset><green>. Le serveur est de nouveau ouvert a tous."));
        return true;
    }

    private boolean handleWhitelist(CommandSender sender, String[] args) {
        var config = plugin.getConfigManager();
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /maintenance whitelist add|remove|list <joueur>"));
            return true;
        }
        List<String> whitelist = new ArrayList<>(config.maintenanceWhitelist());

        switch (args[1].toLowerCase()) {
            case "add" -> {
                if (args.length < 3) {
                    sender.sendMessage(TextUtil.parse("<yellow>Usage : /maintenance whitelist add <joueur>"));
                    return true;
                }
                if (whitelist.stream().noneMatch(n -> n.equalsIgnoreCase(args[2]))) {
                    whitelist.add(args[2]);
                    config.setMaintenanceWhitelist(whitelist);
                }
                sender.sendMessage(TextUtil.parse("<green>" + args[2] + " ajoute a la whitelist maintenance."));
            }
            case "remove" -> {
                if (args.length < 3) {
                    sender.sendMessage(TextUtil.parse("<yellow>Usage : /maintenance whitelist remove <joueur>"));
                    return true;
                }
                whitelist.removeIf(n -> n.equalsIgnoreCase(args[2]));
                config.setMaintenanceWhitelist(whitelist);
                sender.sendMessage(TextUtil.parse("<green>" + args[2] + " retire de la whitelist maintenance."));
            }
            case "list" -> {
                sender.sendMessage(TextUtil.parse("<aqua><bold>--- WHITELIST MAINTENANCE ---"));
                if (whitelist.isEmpty()) {
                    sender.sendMessage(TextUtil.parse("<gray>Vide (seuls staff/OP peuvent rejoindre)."));
                } else {
                    whitelist.forEach(n -> sender.sendMessage(TextUtil.parse("<gray>- <white>" + n)));
                }
            }
            default -> sender.sendMessage(TextUtil.parse("<yellow>Usage : /maintenance whitelist add|remove|list <joueur>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("on", "off", "whitelist"), args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("whitelist")) {
            return filter(List.of("add", "remove", "list"), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("whitelist") && args[1].equalsIgnoreCase("add")) {
            return Bukkit.getOnlinePlayers().stream().map(p -> p.getName())
                    .filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
