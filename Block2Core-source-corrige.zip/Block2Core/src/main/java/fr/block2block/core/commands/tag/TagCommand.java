package fr.block2block.core.commands.tag;

import fr.block2block.core.Block2Core;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /tag : ouvre l'interface de selection du tag (titre de quete) affiche devant le pseudo
 * dans le chat, parmi ceux que le joueur a deja debloques en reclamant des quetes.
 * Remplace l'ancien /quest settitle (texte).
 */
public class TagCommand implements CommandExecutor {

    private final Block2Core plugin;

    public TagCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getTagGUI().open(player);
        return true;
    }
}
