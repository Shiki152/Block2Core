package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.SellPrices;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Interface graphique pour /sell : le joueur depose les objets qu'il veut vendre dans la zone
 * dediee (fond vert), le total se met a jour en direct sur le bouton "Vendre". Fermer
 * l'inventaire (Echap, ouvrir autre chose, deconnexion...) vend automatiquement tout ce qui
 * s'y trouve, exactement comme cliquer sur le bouton "Vendre" - ce sont deux facons
 * equivalentes de valider la vente.
 * <p>
 * Un objet sans prix de vente (voir SellPrices) ne peut jamais rester dans la zone de depot :
 * il est automatiquement renvoye dans l'inventaire du joueur (ou lache au sol si celui-ci est
 * plein) des qu'il y est detecte.
 */
public class SellGUI implements Listener {

    private static final int SIZE = 54;
    private static final int INFO_SLOT = 4;
    private static final int SELL_BUTTON_SLOT = 49;
    private static final Set<Integer> SELL_SLOTS = buildSellSlots();

    private final Block2Core plugin;

    public SellGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    private static Set<Integer> buildSellSlots() {
        Set<Integer> slots = new HashSet<>();
        for (int i = 9; i <= 35; i++) {
            slots.add(i);
        }
        return slots;
    }

    public void open(Player player) {
        Inventory inventory = plugin.getServer().createInventory(new SellGUIHolder(), SIZE,
                TextUtil.parse("<green><bold>Vendre des objets"));

        ItemStack filler = new ItemBuilder(Material.GREEN_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < SIZE; i++) {
            inventory.setItem(i, filler);
        }
        for (int slot : SELL_SLOTS) {
            inventory.setItem(slot, null);
        }

        inventory.setItem(INFO_SLOT, new ItemBuilder(Material.HOPPER)
                .name("<yellow><bold>Comment ca marche ?")
                .loreLine("<gray>Depose ici les objets que tu veux vendre.")
                .loreLine("<gray>Ferme l'inventaire ou clique sur")
                .loreLine("<gray>\"Vendre\" pour recevoir l'argent.")
                .loreLine(" ")
                .loreLine("<dark_gray>Seuls les objets ayant un prix")
                .loreLine("<dark_gray>de vente peuvent etre deposes.")
                .build());

        updateSellButton(inventory);
        player.openInventory(inventory);
    }

    private double computeTotal(Inventory inventory) {
        double total = 0;
        for (int slot : SELL_SLOTS) {
            ItemStack item = inventory.getItem(slot);
            if (item == null || item.getType() == Material.AIR) continue;
            Double price = SellPrices.priceOf(item.getType());
            if (price == null) continue;
            total += price * item.getAmount();
        }
        return total;
    }

    private void updateSellButton(Inventory inventory) {
        double total = computeTotal(inventory);
        inventory.setItem(SELL_BUTTON_SLOT, new ItemBuilder(total > 0 ? Material.EMERALD_BLOCK : Material.GRAY_DYE)
                .glow(total > 0)
                .name(total > 0 ? "<green><bold>VENDRE !" : "<gray>Rien a vendre")
                .loreLine(" ")
                .loreLine("<gray>Valeur actuelle : <gold>" + String.format("%,.0f", total) + " Block2Coins")
                .loreLine(" ")
                .loreLine(total > 0 ? "<yellow>Clique pour valider la vente" : "<dark_gray>Depose des objets vendables")
                .build());
    }

    /** Renvoie (ou lache au sol si l'inventaire est plein) tout objet non vendable trouve dans la zone de depot. */
    private void bounceBackInvalidItems(Player player, Inventory inventory) {
        for (int slot : SELL_SLOTS) {
            ItemStack item = inventory.getItem(slot);
            if (item == null || item.getType() == Material.AIR) continue;
            if (SellPrices.isSellable(item.getType())) continue;

            inventory.setItem(slot, null);
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
            leftover.values().forEach(extra -> player.getWorld().dropItemNaturally(player.getLocation(), extra));
            player.sendMessage(TextUtil.parse("<red>" + niceName(item.getType()) + " ne peut pas etre vendu, objet rendu."));
        }
    }

    /** Vend tout ce qui se trouve dans la zone de depot et vide ces emplacements. Appelee par le bouton ET par la fermeture. */
    private void sellContents(Player player, Inventory inventory) {
        double total = 0;
        int itemsSold = 0;
        for (int slot : SELL_SLOTS) {
            ItemStack item = inventory.getItem(slot);
            if (item == null || item.getType() == Material.AIR) continue;

            Double price = SellPrices.priceOf(item.getType());
            if (price == null) {
                // Ne devrait normalement plus arriver (deja filtre par bounceBackInvalidItems),
                // mais par securite on ne perd jamais un objet : on le rend plutot.
                inventory.setItem(slot, null);
                Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
                leftover.values().forEach(extra -> player.getWorld().dropItemNaturally(player.getLocation(), extra));
                continue;
            }
            total += price * item.getAmount();
            itemsSold += item.getAmount();
            inventory.setItem(slot, null);
        }

        if (itemsSold == 0) return;

        plugin.getEconomyManager().deposit(player.getUniqueId(), total);
        if (player.isOnline()) {
            player.sendMessage(TextUtil.parse("<green>Vendu : <white>" + itemsSold + " objet(s) <green>pour <gold>" +
                    String.format("%,.0f", total) + " Block2Coins"));
        }
    }

    private String niceName(Material material) {
        String raw = material.name().toLowerCase().replace('_', ' ');
        return Character.toUpperCase(raw.charAt(0)) + raw.substring(1);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof SellGUIHolder)) return;
        Player player = (Player) event.getWhoClicked();

        boolean clickedTop = event.getClickedInventory() != null
                && event.getClickedInventory().getHolder() instanceof SellGUIHolder;
        if (!clickedTop) {
            // Clic dans l'inventaire du joueur (bas) : laisse faire, y compris le shift-clic qui
            // ira naturellement dans le premier emplacement de depot libre (les emplacements
            // decoratifs sont deja occupes par les vitres, donc jamais cibles par un shift-clic).
            return;
        }

        int slot = event.getSlot();
        if (slot == SELL_BUTTON_SLOT) {
            event.setCancelled(true);
            sellContents(player, event.getInventory());
            player.closeInventory();
            return;
        }
        if (!SELL_SLOTS.contains(slot)) {
            event.setCancelled(true);
            return;
        }
        // Clic normal dans la zone de depot : autorise tel quel (clic simple, double-clic,
        // echange barre d'acces rapide...), puis corrige au tick suivant plutot que d'essayer
        // de distinguer chaque type de clic Bukkit un par un.
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            bounceBackInvalidItems(player, event.getInventory());
            updateSellButton(event.getInventory());
        });
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getInventory().getHolder() instanceof SellGUIHolder)) return;
        Player player = (Player) event.getWhoClicked();

        for (int rawSlot : event.getRawSlots()) {
            if (rawSlot < SIZE && !SELL_SLOTS.contains(rawSlot)) {
                event.setCancelled(true);
                return;
            }
        }
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            bounceBackInvalidItems(player, event.getInventory());
            updateSellButton(event.getInventory());
        });
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof SellGUIHolder)) return;
        if (!(event.getPlayer() instanceof Player player)) return;
        sellContents(player, event.getInventory());
    }

    public static class SellGUIHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
