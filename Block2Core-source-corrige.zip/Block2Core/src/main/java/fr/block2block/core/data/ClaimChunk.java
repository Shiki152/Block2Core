package fr.block2block.core.data;

import java.util.UUID;

/**
 * Un chunk reclame. Soit possede par un joueur (owner != null), soit par une
 * team (teamId != null), soit protege de maniere permanente par le staff
 * (unesco = true, owner et teamId nuls).
 */
public record ClaimChunk(long id, String world, int chunkX, int chunkZ, UUID owner, Integer teamId, boolean unesco) {

    public static String keyOf(String world, int chunkX, int chunkZ) {
        return world + ";" + chunkX + ";" + chunkZ;
    }

    public String key() {
        return keyOf(world, chunkX, chunkZ);
    }
}
