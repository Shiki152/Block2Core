package fr.block2block.core.listeners;

import fr.block2block.core.Block2Core;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

/**
 * Enregistre chaque cassage/pose de bloc reussi en base pour l'inspecteur /co.
 * ignoreCancelled = true : seuls les changements reellement appliques sont
 * journalises (pas les tentatives bloquees par une protection de claim).
 */
public class BlockLogListener implements Listener {

    private final Block2Core plugin;

    public BlockLogListener(Block2Core plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        plugin.getLogManager().logBlockChange(event.getPlayer(), event.getBlock(), "BREAK", event.getBlock().getType(), null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        Material previous = event.getBlockReplacedState().getType();
        plugin.getLogManager().logBlockChange(event.getPlayer(), event.getBlock(), "PLACE", event.getBlock().getType(), previous);
    }
}
