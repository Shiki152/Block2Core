package fr.block2block.core.data;

import java.util.UUID;

/**
 * Signalement d'un joueur par un autre.
 */
public record Report(long id, UUID reporterUuid, String reporterName, UUID reportedUuid, String reportedName,
                      String reason, String status, String comment, String staffName, long createdAt, long closedAt) {

    public boolean isOpen() {
        return "OPEN".equalsIgnoreCase(status);
    }
}
