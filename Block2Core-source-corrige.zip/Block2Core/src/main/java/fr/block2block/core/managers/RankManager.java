package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.StaffRank;
import fr.block2block.core.util.GradeTiers;
import fr.block2block.core.util.PermissionTiers;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere les grades joueurs et staff : rankup, attribution manuelle, classement.
 */
public class RankManager {

    private final Block2Core plugin;
    private final Map<UUID, PermissionAttachment> staffAttachments = new HashMap<>();
    private final Map<UUID, PermissionAttachment> gradeAttachments = new HashMap<>();

    public RankManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // RANKUP
    // ---------------------------------------------------------------

    public void rankup(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return;

        Grade current = data.getGrade();
        Grade next = current.next();

        // Le grade Partenaire est honorifique : il n'est JAMAIS obtenu via la progression
        // automatique /rankup, uniquement distribue manuellement par un OP via /rank set.
        // Master est donc le veritable "plafond" du systeme de rankup en libre-service.
        if (next == null || next == Grade.PARTENAIRE) {
            player.sendMessage(plugin.getConfigManager().messageComponent(
                    next == Grade.PARTENAIRE ? "rankup-maxed-partenaire" : "rankup-maxed", Map.of()));
            return;
        }

        double cost = plugin.getConfigManager().rankupCost(next);
        long requiredPlaytime = plugin.getConfigManager().rankupPlaytimeSeconds(next);
        long currentPlaytime = data.getPlaytimeSeconds();
        double balance = plugin.getEconomyManager().getBalance(player.getUniqueId());

        boolean hasMoney = balance >= cost;
        boolean hasPlaytime = currentPlaytime >= requiredPlaytime;

        if (!hasMoney) {
            player.sendMessage(plugin.getConfigManager().messageComponent("rankup-missing-money",
                    Map.of("montant", String.valueOf((long) Math.ceil(cost - balance)))));
        }
        if (!hasPlaytime) {
            player.sendMessage(plugin.getConfigManager().messageComponent("rankup-missing-playtime",
                    Map.of("temps", TimeUtil.formatShort(requiredPlaytime - currentPlaytime))));
        }
        if (!hasMoney || !hasPlaytime) {
            return;
        }

        plugin.getEconomyManager().withdraw(player.getUniqueId(), cost);
        setGrade(player.getUniqueId(), next, () -> broadcastRankup(player, current, next));
    }

    private void broadcastRankup(Player player, Grade oldGrade, Grade newGrade) {
        String oldName = plugin.getConfigManager().gradeDisplayName(oldGrade);
        String newName = plugin.getConfigManager().gradeDisplayName(newGrade);

        Map<String, String> placeholders = Map.of(
                "ancien_grade", oldName,
                "nouveau_grade", newName,
                "pseudo", player.getName()
        );
        Component broadcast = TextUtil.parse(plugin.getConfigManager().message("rankup-broadcast"), placeholders);
        Bukkit.getServer().sendMessage(broadcast);

        Component titleText = TextUtil.parse(plugin.getConfigManager().message("rankup-title"), placeholders);
        Component subtitleText = TextUtil.parse(plugin.getConfigManager().message("rankup-subtitle"), placeholders);
        Title title = Title.title(titleText, subtitleText,
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(500)));

        String soundName = plugin.getConfigManager().message("rankup-sound");
        org.bukkit.Sound bukkitSound;
        try {
            bukkitSound = org.bukkit.Sound.valueOf(soundName.isBlank() ? "ENTITY_PLAYER_LEVELUP" : soundName);
        } catch (IllegalArgumentException exception) {
            bukkitSound = org.bukkit.Sound.ENTITY_PLAYER_LEVELUP;
        }

        for (Player online : Bukkit.getOnlinePlayers()) {
            online.showTitle(title);
            online.playSound(online.getLocation(), bukkitSound, 1f, 1f);
        }
    }

    // ---------------------------------------------------------------
    // GESTION GRADE JOUEUR
    // ---------------------------------------------------------------

    public void setGrade(UUID uuid, Grade grade, Runnable onDone) {
        PlayerData data = plugin.getPlayerData(uuid);
        if (data != null) {
            data.setGrade(grade);
        }
        // Meme prudence que pour les permissions staff : si le joueur est en ligne mais pas
        // encore authentifie (mode offline, /login pas encore valide), on n'applique pas
        // tout de suite les permissions de grade - elles le seront automatiquement a la
        // connexion reussie (voir AuthManager#finalizeAuthentication).
        Player online = Bukkit.getPlayer(uuid);
        if (online != null && (data == null || data.isAuthenticated())) {
            applyGradePermissions(online, grade);
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("UPDATE b2c_players SET grade = ? WHERE uuid = ?")) {
                statement.setString(1, grade.key());
                statement.setString(2, uuid.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Impossible de sauvegarder le grade", exception);
            }
            if (onDone != null) {
                Bukkit.getScheduler().runTask(plugin, onDone);
            }
        });
    }

    public void getGradeInfo(String targetName, Consumer<PlayerRankInfo> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            PlayerRankInfo info = null;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "SELECT uuid, grade, staff_rank, playtime_seconds, balance FROM b2c_players WHERE username = ? COLLATE NOCASE")) {
                statement.setString(1, targetName);
                try (var rs = statement.executeQuery()) {
                    if (rs.next()) {
                        info = new PlayerRankInfo(
                                UUID.fromString(rs.getString("uuid")),
                                targetName,
                                Grade.fromKey(rs.getString("grade")),
                                StaffRank.fromKey(rs.getString("staff_rank")),
                                rs.getLong("playtime_seconds"),
                                rs.getDouble("balance")
                        );
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur lors de la lecture du grade", exception);
            }
            PlayerRankInfo finalInfo = info;
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(finalInfo));
        });
    }

    public void getTop(int limit, Consumer<List<PlayerRankInfo>> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<PlayerRankInfo> list = new ArrayList<>();
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "SELECT uuid, username, grade, staff_rank, playtime_seconds, balance FROM b2c_players");
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    list.add(new PlayerRankInfo(
                            UUID.fromString(rs.getString("uuid")),
                            rs.getString("username"),
                            Grade.fromKey(rs.getString("grade")),
                            StaffRank.fromKey(rs.getString("staff_rank")),
                            rs.getLong("playtime_seconds"),
                            rs.getDouble("balance")
                    ));
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur lors du calcul du /rank top", exception);
            }
            list.sort((a, b) -> {
                int gradeCompare = Integer.compare(
                        b.grade() != null ? b.grade().ordinal() : -1,
                        a.grade() != null ? a.grade().ordinal() : -1);
                if (gradeCompare != 0) return gradeCompare;
                return Long.compare(b.playtimeSeconds(), a.playtimeSeconds());
            });
            List<PlayerRankInfo> top = list.subList(0, Math.min(limit, list.size()));
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(new ArrayList<>(top)));
        });
    }

    // ---------------------------------------------------------------
    // GESTION GRADE STAFF
    // ---------------------------------------------------------------

    public void setStaffRank(Player target, StaffRank rank, Runnable onDone) {
        PlayerData data = plugin.getPlayerData(target.getUniqueId());
        if (data != null) {
            data.setStaffRank(rank);
        }
        // Securite : si la cible n'est pas encore authentifiee (mode offline, /login pas
        // encore valide), on n'applique pas tout de suite les permissions - un compte non
        // authentifie ne doit jamais recevoir de permissions staff, meme via /staff set sur
        // un pseudo qui n'a pas encore prouve son identite. Elles s'appliqueront d'elles-memes
        // a la connexion reussie (voir AuthManager#finalizeAuthentication).
        if (data == null || data.isAuthenticated()) {
            applyStaffPermissions(target, rank);
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("UPDATE b2c_players SET staff_rank = ? WHERE uuid = ?")) {
                statement.setString(1, rank != null ? rank.key() : null);
                statement.setString(2, target.getUniqueId().toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Impossible de sauvegarder le grade staff", exception);
            }
            if (onDone != null) {
                Bukkit.getScheduler().runTask(plugin, onDone);
            }
        });
    }

    /** Applique les permissions correspondant au grade staff (voir PermissionTiers). */
    public void applyStaffPermissions(Player player, StaffRank rank) {
        PermissionAttachment existing = staffAttachments.remove(player.getUniqueId());
        if (existing != null) {
            player.removeAttachment(existing);
        }
        if (rank == null) {
            return;
        }
        PermissionAttachment attachment = player.addAttachment(plugin);
        for (String node : PermissionTiers.permissionsFor(rank)) {
            attachment.setPermission(node, true);
        }
        staffAttachments.put(player.getUniqueId(), attachment);
    }

    public void clearAttachment(UUID uuid) {
        staffAttachments.remove(uuid);
    }

    /** Applique les permissions correspondant au grade JOUEUR (voir GradeTiers), cumulatives. */
    public void applyGradePermissions(Player player, Grade grade) {
        PermissionAttachment existing = gradeAttachments.remove(player.getUniqueId());
        if (existing != null) {
            player.removeAttachment(existing);
        }
        if (grade == null) {
            return;
        }
        PermissionAttachment attachment = player.addAttachment(plugin);
        for (String node : GradeTiers.permissionsUpTo(grade)) {
            attachment.setPermission(node, true);
        }
        gradeAttachments.put(player.getUniqueId(), attachment);
    }

    public void clearGradeAttachment(UUID uuid) {
        gradeAttachments.remove(uuid);
    }

    /** Formatte le grade "actif" pour l'affichage chat/tab : le grade staff prevaut si present. */
    public Component activeRankFormatted(PlayerData data) {
        if (data.getStaffRank() != null) {
            return plugin.getConfigManager().staffFormatted(data.getStaffRank());
        }
        return plugin.getConfigManager().gradeFormatted(data.getGrade());
    }

    public record PlayerRankInfo(UUID uuid, String name, Grade grade, StaffRank staffRank, long playtimeSeconds, double balance) {
    }
}
