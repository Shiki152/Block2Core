package fr.block2block.core.commands.economy;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.security.SecureRandom;

/**
 * /coinflip <mise> : tente de doubler sa mise en Block2Coins (50/50 contre le serveur).
 */
public class CoinflipCommand implements CommandExecutor {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final Block2Core plugin;

    public CoinflipCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /coinflip <mise>"));
            return true;
        }
        double amount;
        try {
            amount = Double.parseDouble(args[0]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", java.util.Map.of("valeur", args[0])));
            return true;
        }
        if (amount <= 0) {
            player.sendMessage(TextUtil.parse("<red>La mise doit etre positive."));
            return true;
        }
        if (!plugin.getEconomyManager().withdraw(player.getUniqueId(), amount)) {
            player.sendMessage(TextUtil.parse("<red>Solde insuffisant pour miser " + (long) amount + " Block2Coins."));
            return true;
        }

        boolean win = RANDOM.nextBoolean();
        if (win) {
            plugin.getEconomyManager().deposit(player.getUniqueId(), amount * 2);
            player.sendMessage(TextUtil.parse("<green><bold>GAGNE ! <white>Tu remportes <gold>" + (long) (amount * 2) + " Block2Coins"));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        } else {
            player.sendMessage(TextUtil.parse("<red><bold>PERDU... <white>Tu perds <gold>" + (long) amount + " Block2Coins"));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
        }
        return true;
    }
}
