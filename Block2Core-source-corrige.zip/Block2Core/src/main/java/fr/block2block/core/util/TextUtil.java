package fr.block2block.core.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * Utilitaires de texte : conversion MiniMessage / legacy (codes §) et
 * remplacement de placeholders internes + PlaceholderAPI si present.
 * <p>
 * Le plugin accepte les deux formats dans sa configuration : une chaine
 * commencant par un code legacy (§ ou &amp;) est traitee comme du legacy,
 * sinon elle est parsee en MiniMessage. Cela permet de coller exactement
 * aux exemples fournis (qui utilisent des codes §) tout en autorisant
 * du MiniMessage moderne partout ailleurs.
 */
public final class TextUtil {

    private static final MiniMessage MINI = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY_AMP = LegacyComponentSerializer.legacyAmpersand();
    private static final LegacyComponentSerializer LEGACY_SECTION = LegacyComponentSerializer.legacySection();

    private TextUtil() {
    }

    /**
     * Parse une chaine en Component, en detectant automatiquement si c'est
     * du MiniMessage ou du legacy (§ / &amp;).
     */
    public static Component parse(String raw) {
        if (raw == null) {
            return Component.empty();
        }
        String withAmp = raw.replace('&', '§');
        if (withAmp.indexOf('§') >= 0) {
            // Contient des codes couleur legacy : on les convertit,
            // mais on laisse quand meme passer d'eventuelles balises MiniMessage
            // presentes dans le reste de la chaine.
            Component legacyParsed = LEGACY_SECTION.deserialize(withAmp);
            return legacyParsed;
        }
        return MINI.deserialize(raw);
    }

    /**
     * Parse en tolerant les deux formats et remplace des placeholders
     * simples de la forme %cle% avant le parsing.
     */
    public static Component parse(String raw, java.util.Map<String, String> placeholders) {
        return parse(applyPlaceholders(raw, placeholders));
    }

    public static String applyPlaceholders(String raw, java.util.Map<String, String> placeholders) {
        if (raw == null) {
            return "";
        }
        String result = raw;
        for (var entry : placeholders.entrySet()) {
            result = result.replace("%" + entry.getKey() + "%", entry.getValue() == null ? "" : entry.getValue());
        }
        return result;
    }

    /**
     * Applique PlaceholderAPI si le plugin est present sur le serveur, sinon
     * retourne la chaine telle quelle.
     */
    public static String applyPapi(Player player, String raw) {
        if (raw == null) {
            return "";
        }
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            try {
                return me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(player, raw);
            } catch (Throwable ignored) {
                // PlaceholderAPI absent au compile-time sur certains setups : on ignore silencieusement
            }
        }
        return raw;
    }

    public static String stripToPlain(Component component) {
        return PlainTextComponentSerializer.plainText().serialize(component);
    }

    public static Component legacy(String raw) {
        return LEGACY_SECTION.deserialize(raw);
    }

    public static String toLegacyString(Component component) {
        return LEGACY_SECTION.serialize(component);
    }

    /** Concatene plusieurs Component avec un separateur espace. */
    public static Component join(Component... parts) {
        Component result = Component.empty();
        for (int i = 0; i < parts.length; i++) {
            if (parts[i] == null) continue;
            result = result.append(parts[i]);
            if (i < parts.length - 1) {
                result = result.append(Component.space());
            }
        }
        return result;
    }
}
