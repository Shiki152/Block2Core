package fr.block2block.core.commands.moderation;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Punishment;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Dispatcher pour toutes les commandes de sanctions : ban, tempban, unban,
 * mute, tempmute, unmute, kick, warn, warnings, delwarn, clearwarns,
 * ipban, unipban, blacklist, unblacklist.
 */
public class PunishmentCommand implements CommandExecutor, TabCompleter {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    private final Block2Core plugin;

    public PunishmentCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase();
        return switch (name) {
            case "ban" -> ban(sender, args);
            case "tempban" -> tempban(sender, args);
            case "unban" -> unban(sender, args);
            case "mute" -> mute(sender, args);
            case "tempmute" -> tempmute(sender, args);
            case "unmute" -> unmute(sender, args);
            case "kick" -> kick(sender, args);
            case "warn" -> warn(sender, args);
            case "warnings" -> warnings(sender, args);
            case "delwarn" -> delwarn(sender, args);
            case "clearwarns" -> clearwarns(sender, args);
            case "ipban" -> ipban(sender, args);
            case "unipban" -> unipban(sender, args);
            case "blacklist" -> blacklist(sender, args);
            case "unblacklist" -> unblacklist(sender, args);
            default -> false;
        };
    }

    private String reasonFrom(String[] args, int startIndex) {
        if (args.length <= startIndex) return "Aucune raison";
        return String.join(" ", Arrays.copyOfRange(args, startIndex, args.length));
    }

    private UUID senderUuid(CommandSender sender) {
        return sender instanceof Player p ? p.getUniqueId() : null;
    }

    private boolean ban(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /ban <joueur> [raison]"));
            return true;
        }
        String reason = reasonFrom(args, 1);
        plugin.getPunishmentManager().ban(args[0], senderUuid(sender), sender.getName(), reason, () -> {
            sender.sendMessage(TextUtil.parse("<green>" + args[0] + " a ete banni."));
            Bukkit.getServer().sendMessage(TextUtil.parse("<red>" + args[0] + " a ete banni par " + sender.getName() + " : " + reason));
            plugin.getLogManager().logAction(Bukkit.getOfflinePlayer(args[0]).getUniqueId(), senderUuid(sender), sender.getName(), "BAN", reason);
        });
        return true;
    }

    private boolean tempban(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tempban <joueur> <duree> [raison]"));
            return true;
        }
        long seconds;
        try {
            seconds = TimeUtil.parseSeconds(args[1]);
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(TextUtil.parse("<red>Duree invalide (ex: 10m, 2h, 1d)."));
            return true;
        }
        String reason = reasonFrom(args, 2);
        plugin.getPunishmentManager().tempban(args[0], senderUuid(sender), sender.getName(), reason, seconds, () -> {
            sender.sendMessage(TextUtil.parse("<green>" + args[0] + " a ete banni pour " + TimeUtil.formatShort(seconds) + "."));
            Bukkit.getServer().sendMessage(TextUtil.parse("<red>" + args[0] + " a ete banni temporairement par " + sender.getName() + " : " + reason));
            plugin.getLogManager().logAction(Bukkit.getOfflinePlayer(args[0]).getUniqueId(), senderUuid(sender), sender.getName(), "TEMPBAN", reason);
        });
        return true;
    }

    private boolean unban(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /unban <joueur>"));
            return true;
        }
        plugin.getPunishmentManager().unban(args[0], () -> sender.sendMessage(TextUtil.parse("<green>" + args[0] + " a ete debanni.")));
        return true;
    }

    private boolean mute(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /mute <joueur> [raison]"));
            return true;
        }
        String reason = reasonFrom(args, 1);
        plugin.getPunishmentManager().mute(args[0], senderUuid(sender), sender.getName(), reason, () -> {
            sender.sendMessage(TextUtil.parse("<green>" + args[0] + " a ete mute."));
            plugin.getLogManager().logAction(Bukkit.getOfflinePlayer(args[0]).getUniqueId(), senderUuid(sender), sender.getName(), "MUTE", reason);
        });
        return true;
    }

    private boolean tempmute(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tempmute <joueur> <duree> [raison]"));
            return true;
        }
        long seconds;
        try {
            seconds = TimeUtil.parseSeconds(args[1]);
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(TextUtil.parse("<red>Duree invalide (ex: 10m, 2h, 1d)."));
            return true;
        }
        String reason = reasonFrom(args, 2);
        plugin.getPunishmentManager().tempmute(args[0], senderUuid(sender), sender.getName(), reason, seconds, () ->
                sender.sendMessage(TextUtil.parse("<green>" + args[0] + " a ete mute pour " + TimeUtil.formatShort(seconds) + ".")));
        return true;
    }

    private boolean unmute(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /unmute <joueur>"));
            return true;
        }
        plugin.getPunishmentManager().unmute(args[0], () -> sender.sendMessage(TextUtil.parse("<green>" + args[0] + " a ete demute.")));
        return true;
    }

    private boolean kick(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /kick <joueur> [raison]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        String reason = reasonFrom(args, 1);
        plugin.getPunishmentManager().kick(target, sender.getName(), reason);
        sender.sendMessage(TextUtil.parse("<green>" + target.getName() + " a ete expulse."));
        return true;
    }

    private boolean warn(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /warn <joueur> <raison>"));
            return true;
        }
        String reason = reasonFrom(args, 1);
        plugin.getPunishmentManager().warn(args[0], senderUuid(sender), sender.getName(), reason, () -> {
            sender.sendMessage(TextUtil.parse("<green>Avertissement donne a " + args[0] + "."));
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target != null) target.sendMessage(TextUtil.parse("<yellow>Tu as recu un avertissement : <white>" + reason));
        });
        return true;
    }

    private boolean warnings(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /warnings <joueur>"));
            return true;
        }
        plugin.getPunishmentManager().getWarnings(args[0], list -> {
            if (list.isEmpty()) {
                sender.sendMessage(TextUtil.parse("<green>" + args[0] + " n'a aucun avertissement."));
                return;
            }
            sender.sendMessage(TextUtil.parse("<yellow><bold>--- AVERTISSEMENTS DE " + args[0] + " ---"));
            for (Punishment p : list) {
                sender.sendMessage(TextUtil.parse("<gray>#" + p.id() + " <white>" + p.reason() +
                        " <gray>(par " + p.staffName() + ", " + DATE_FORMAT.format(new Date(p.startMillis())) + ")"));
            }
        });
        return true;
    }

    private boolean delwarn(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /delwarn <joueur> <id>"));
            return true;
        }
        long id;
        try {
            id = Long.parseLong(args[1]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", java.util.Map.of("valeur", args[1])));
            return true;
        }
        plugin.getPunishmentManager().delWarn(id, () -> sender.sendMessage(TextUtil.parse("<green>Avertissement #" + id + " supprime.")));
        return true;
    }

    private boolean clearwarns(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /clearwarns <joueur>"));
            return true;
        }
        plugin.getPunishmentManager().clearWarns(args[0], () -> sender.sendMessage(TextUtil.parse("<green>Avertissements de " + args[0] + " effaces.")));
        return true;
    }

    private boolean ipban(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /ipban <joueur> [raison]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        String reason = reasonFrom(args, 1);
        plugin.getPunishmentManager().ipban(target, senderUuid(sender), sender.getName(), reason,
                () -> sender.sendMessage(TextUtil.parse("<green>IP de " + target.getName() + " bannie.")));
        return true;
    }

    private boolean unipban(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /unipban <joueur|ip>"));
            return true;
        }
        plugin.getPunishmentManager().unipban(args[0], () -> sender.sendMessage(TextUtil.parse("<green>IP debannie.")));
        return true;
    }

    private boolean blacklist(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /blacklist <joueur> [raison]"));
            return true;
        }
        String reason = reasonFrom(args, 1);
        plugin.getPunishmentManager().blacklist(args[0], senderUuid(sender), sender.getName(), reason,
                () -> sender.sendMessage(TextUtil.parse("<green>" + args[0] + " a ete blackliste.")));
        return true;
    }

    private boolean unblacklist(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /unblacklist <joueur>"));
            return true;
        }
        plugin.getPunishmentManager().unblacklist(args[0], () -> sender.sendMessage(TextUtil.parse("<green>" + args[0] + " retire de la blacklist.")));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && (command.getName().equalsIgnoreCase("tempban") || command.getName().equalsIgnoreCase("tempmute"))) {
            return List.of("10m", "1h", "1d", "7d").stream().filter(o -> o.startsWith(args[1])).collect(Collectors.toList());
        }
        return List.of();
    }
}
