package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Home;
import fr.block2block.core.data.Warp;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gere les homes (par joueur, chargees a la connexion) et les warps
 * (globaux, charges au demarrage).
 */
public class LocationManager {

    private final Block2Core plugin;
    private final Map<UUID, Map<String, Home>> homesCache = new ConcurrentHashMap<>();
    private final Map<String, Warp> warpsCache = new ConcurrentHashMap<>();

    public LocationManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // WARPS
    // ---------------------------------------------------------------

    public void loadWarps() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_warps");
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    Warp warp = new Warp(rs.getString("name"), rs.getString("world"), rs.getDouble("x"),
                            rs.getDouble("y"), rs.getDouble("z"), rs.getFloat("yaw"), rs.getFloat("pitch"), rs.getString("creator"));
                    warpsCache.put(warp.name().toLowerCase(), warp);
                }
                plugin.getLogger().info("Warps charges : " + warpsCache.size());
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement warps", exception);
            }
        });
    }

    public Warp getWarp(String name) {
        return warpsCache.get(name.toLowerCase());
    }

    public Map<String, Warp> getWarps() {
        return warpsCache;
    }

    public void setWarp(String name, Location location, String creator, Runnable onDone) {
        Warp warp = new Warp(name, location.getWorld().getName(), location.getX(), location.getY(), location.getZ(),
                location.getYaw(), location.getPitch(), creator);
        warpsCache.put(name.toLowerCase(), warp);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_warps (name, world, x, y, z, yaw, pitch, creator) VALUES (?,?,?,?,?,?,?,?) " +
                                 "ON CONFLICT(name) DO UPDATE SET world=excluded.world, x=excluded.x, y=excluded.y, z=excluded.z, " +
                                 "yaw=excluded.yaw, pitch=excluded.pitch, creator=excluded.creator")) {
                statement.setString(1, warp.name());
                statement.setString(2, warp.world());
                statement.setDouble(3, warp.x());
                statement.setDouble(4, warp.y());
                statement.setDouble(5, warp.z());
                statement.setFloat(6, warp.yaw());
                statement.setFloat(7, warp.pitch());
                statement.setString(8, warp.creator());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde warp", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void deleteWarp(String name, Runnable onDone) {
        warpsCache.remove(name.toLowerCase());
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("DELETE FROM b2c_warps WHERE name = ?")) {
                statement.setString(1, name);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur suppression warp", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public static Location toLocation(Warp warp) {
        World world = Bukkit.getWorld(warp.world());
        if (world == null) return null;
        return new Location(world, warp.x(), warp.y(), warp.z(), warp.yaw(), warp.pitch());
    }

    public static Location toLocation(Home home) {
        World world = Bukkit.getWorld(home.world());
        if (world == null) return null;
        return new Location(world, home.x(), home.y(), home.z(), home.yaw(), home.pitch());
    }

    // ---------------------------------------------------------------
    // HOMES
    // ---------------------------------------------------------------

    public void loadHomes(UUID uuid, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Map<String, Home> homes = new HashMap<>();
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_homes WHERE owner_uuid = ?")) {
                statement.setString(1, uuid.toString());
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) {
                        Home home = new Home(uuid, rs.getString("name"), rs.getString("world"), rs.getDouble("x"),
                                rs.getDouble("y"), rs.getDouble("z"), rs.getFloat("yaw"), rs.getFloat("pitch"));
                        homes.put(home.name().toLowerCase(), home);
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement homes", exception);
            }
            homesCache.put(uuid, homes);
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void unloadHomes(UUID uuid) {
        homesCache.remove(uuid);
    }

    public Map<String, Home> getHomes(UUID uuid) {
        return homesCache.getOrDefault(uuid, Map.of());
    }

    public Home getHome(UUID uuid, String name) {
        return getHomes(uuid).get(name.toLowerCase());
    }

    public void setHome(Player player, String name, Runnable onDone) {
        Location location = player.getLocation();
        Home home = new Home(player.getUniqueId(), name, location.getWorld().getName(), location.getX(),
                location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        homesCache.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>()).put(name.toLowerCase(), home);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_homes (owner_uuid, name, world, x, y, z, yaw, pitch) VALUES (?,?,?,?,?,?,?,?) " +
                                 "ON CONFLICT(owner_uuid, name) DO UPDATE SET world=excluded.world, x=excluded.x, y=excluded.y, " +
                                 "z=excluded.z, yaw=excluded.yaw, pitch=excluded.pitch")) {
                statement.setString(1, home.owner().toString());
                statement.setString(2, home.name());
                statement.setString(3, home.world());
                statement.setDouble(4, home.x());
                statement.setDouble(5, home.y());
                statement.setDouble(6, home.z());
                statement.setFloat(7, home.yaw());
                statement.setFloat(8, home.pitch());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde home", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void deleteHome(UUID uuid, String name, Runnable onDone) {
        Map<String, Home> homes = homesCache.get(uuid);
        if (homes != null) homes.remove(name.toLowerCase());
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("DELETE FROM b2c_homes WHERE owner_uuid = ? AND name = ?")) {
                statement.setString(1, uuid.toString());
                statement.setString(2, name);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur suppression home", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }
}
