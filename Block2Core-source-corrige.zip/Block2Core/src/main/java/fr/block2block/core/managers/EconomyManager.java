package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Gere la monnaie Block2Coins. Implemente l'interface Economy de Vault afin
 * que ce plugin agisse comme fournisseur d'economie pour tout le serveur
 * (aucun autre plugin d'economie n'est necessaire).
 * <p>
 * Les ecritures utilisent des requetes SQL atomiques (balance = balance +/- ?)
 * pour rester coherentes meme en cas d'acces concurrents, tandis que le
 * cache en memoire (PlayerData) permet un affichage instantane (scoreboard,
 * placeholders) pour les joueurs connectes.
 */
public class EconomyManager implements Economy {

    private final Block2Core plugin;

    public EconomyManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // API INTERNE (utilisee par le reste du plugin)
    // ---------------------------------------------------------------

    /** Solde instantane si le joueur est en ligne (cache), sinon lecture DB synchrone rapide (a n'utiliser que hors thread principal). */
    public double getBalance(UUID uuid) {
        PlayerData data = plugin.getPlayerData(uuid);
        if (data != null) {
            return data.getBalance();
        }
        return getBalanceBlocking(uuid);
    }

    private double getBalanceBlocking(UUID uuid) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("SELECT balance FROM b2c_players WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (var rs = statement.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("balance");
                }
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur lecture balance", exception);
        }
        return 0.0;
    }

    public boolean withdraw(UUID uuid, double amount) {
        if (amount <= 0) return true;
        PlayerData data = plugin.getPlayerData(uuid);
        if (data != null && data.getBalance() < amount) {
            return false;
        }
        boolean[] success = {false};
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "UPDATE b2c_players SET balance = balance - ? WHERE uuid = ? AND balance >= ?")) {
            statement.setDouble(1, amount);
            statement.setString(2, uuid.toString());
            statement.setDouble(3, amount);
            success[0] = statement.executeUpdate() > 0;
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur withdraw", exception);
        }
        if (success[0] && data != null) {
            data.setBalance(data.getBalance() - amount);
        }
        return success[0];
    }

    public void deposit(UUID uuid, double amount) {
        if (amount <= 0) return;
        PlayerData data = plugin.getPlayerData(uuid);
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("UPDATE b2c_players SET balance = balance + ? WHERE uuid = ?")) {
            statement.setDouble(1, amount);
            statement.setString(2, uuid.toString());
            statement.executeUpdate();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur deposit", exception);
        }
        if (data != null) {
            data.setBalance(data.getBalance() + amount);
        }
    }

    public void setBalance(UUID uuid, double amount) {
        PlayerData data = plugin.getPlayerData(uuid);
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("UPDATE b2c_players SET balance = ? WHERE uuid = ?")) {
            statement.setDouble(1, amount);
            statement.setString(2, uuid.toString());
            statement.executeUpdate();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur setBalance", exception);
        }
        if (data != null) {
            data.setBalance(amount);
        }
    }

    /** Doit etre appele hors du thread principal (utilise pour /b2c top). */
    public List<TopEntry> getTopBlocking(int limit) {
        List<TopEntry> list = new ArrayList<>();
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "SELECT username, balance FROM b2c_players ORDER BY balance DESC LIMIT ?")) {
            statement.setInt(1, limit);
            try (var rs = statement.executeQuery()) {
                while (rs.next()) {
                    list.add(new TopEntry(rs.getString("username"), rs.getDouble("balance")));
                }
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur /b2c top", exception);
        }
        return list;
    }

    public record TopEntry(String name, double balance) {
    }

    // ---------------------------------------------------------------
    // IMPLEMENTATION VAULT ECONOMY - GENERAL
    // ---------------------------------------------------------------

    @Override
    public boolean isEnabled() {
        return plugin.isEnabled();
    }

    @Override
    public String getName() {
        return "Block2Core";
    }

    @Override
    public boolean hasBankSupport() {
        return false;
    }

    @Override
    public int fractionalDigits() {
        return 0;
    }

    @Override
    public String format(double amount) {
        return String.format("%,.0f Block2Coins", amount);
    }

    @Override
    public String currencyNamePlural() {
        return "Block2Coins";
    }

    @Override
    public String currencyNameSingular() {
        return "Block2Coin";
    }

    // ---------------------------------------------------------------
    // IMPLEMENTATION VAULT ECONOMY - COMPTES (String)
    // ---------------------------------------------------------------

    @Override
    public boolean hasAccount(String playerName) {
        return hasAccount(Bukkit.getOfflinePlayer(playerName));
    }

    @Override
    public boolean hasAccount(String playerName, String worldName) {
        return hasAccount(playerName);
    }

    @Override
    public double getBalance(String playerName) {
        return getBalance(Bukkit.getOfflinePlayer(playerName));
    }

    @Override
    public double getBalance(String playerName, String world) {
        return getBalance(playerName);
    }

    @Override
    public boolean has(String playerName, double amount) {
        return getBalance(playerName) >= amount;
    }

    @Override
    public boolean has(String playerName, String worldName, double amount) {
        return has(playerName, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        return withdrawPlayer(Bukkit.getOfflinePlayer(playerName), amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return withdrawPlayer(playerName, amount);
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, double amount) {
        return depositPlayer(Bukkit.getOfflinePlayer(playerName), amount);
    }

    @Override
    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return depositPlayer(playerName, amount);
    }

    @Override
    public boolean createPlayerAccount(String playerName) {
        return createPlayerAccount(Bukkit.getOfflinePlayer(playerName));
    }

    @Override
    public boolean createPlayerAccount(String playerName, String worldName) {
        return createPlayerAccount(playerName);
    }

    // ---------------------------------------------------------------
    // IMPLEMENTATION VAULT ECONOMY - COMPTES (OfflinePlayer)
    // ---------------------------------------------------------------

    @Override
    public boolean hasAccount(OfflinePlayer player) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("SELECT 1 FROM b2c_players WHERE uuid = ?")) {
            statement.setString(1, player.getUniqueId().toString());
            try (var rs = statement.executeQuery()) {
                return rs.next();
            }
        } catch (Exception exception) {
            return false;
        }
    }

    @Override
    public boolean hasAccount(OfflinePlayer player, String worldName) {
        return hasAccount(player);
    }

    @Override
    public double getBalance(OfflinePlayer player) {
        return getBalance(player.getUniqueId());
    }

    @Override
    public double getBalance(OfflinePlayer player, String world) {
        return getBalance(player);
    }

    @Override
    public boolean has(OfflinePlayer player, double amount) {
        return getBalance(player) >= amount;
    }

    @Override
    public boolean has(OfflinePlayer player, String worldName, double amount) {
        return has(player, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        if (amount < 0) {
            return new EconomyResponse(0, getBalance(player), EconomyResponse.ResponseType.FAILURE, "Montant negatif");
        }
        boolean success = withdraw(player.getUniqueId(), amount);
        double newBalance = getBalance(player);
        if (success) {
            return new EconomyResponse(amount, newBalance, EconomyResponse.ResponseType.SUCCESS, null);
        }
        return new EconomyResponse(0, newBalance, EconomyResponse.ResponseType.FAILURE, "Solde insuffisant");
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        return withdrawPlayer(player, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        if (amount < 0) {
            return new EconomyResponse(0, getBalance(player), EconomyResponse.ResponseType.FAILURE, "Montant negatif");
        }
        deposit(player.getUniqueId(), amount);
        return new EconomyResponse(amount, getBalance(player), EconomyResponse.ResponseType.SUCCESS, null);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        return depositPlayer(player, amount);
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "INSERT OR IGNORE INTO b2c_players (uuid, username, first_join, last_login) VALUES (?, ?, ?, ?)")) {
            statement.setString(1, player.getUniqueId().toString());
            statement.setString(2, player.getName() != null ? player.getName() : "unknown");
            long now = System.currentTimeMillis();
            statement.setLong(3, now);
            statement.setLong(4, now);
            statement.executeUpdate();
            return true;
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur createPlayerAccount", exception);
            return false;
        }
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
        return createPlayerAccount(player);
    }

    // ---------------------------------------------------------------
    // IMPLEMENTATION VAULT ECONOMY - BANQUES (non supportees)
    // ---------------------------------------------------------------

    @Override
    public EconomyResponse createBank(String name, String player) {
        return notImplemented();
    }

    @Override
    public EconomyResponse createBank(String name, OfflinePlayer player) {
        return notImplemented();
    }

    @Override
    public EconomyResponse deleteBank(String name) {
        return notImplemented();
    }

    @Override
    public EconomyResponse bankBalance(String name) {
        return notImplemented();
    }

    @Override
    public EconomyResponse bankHas(String name, double amount) {
        return notImplemented();
    }

    @Override
    public EconomyResponse bankWithdraw(String name, double amount) {
        return notImplemented();
    }

    @Override
    public EconomyResponse bankDeposit(String name, double amount) {
        return notImplemented();
    }

    @Override
    public EconomyResponse isBankOwner(String name, String playerName) {
        return notImplemented();
    }

    @Override
    public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return notImplemented();
    }

    @Override
    public EconomyResponse isBankMember(String name, String playerName) {
        return notImplemented();
    }

    @Override
    public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return notImplemented();
    }

    @Override
    public List<String> getBanks() {
        return new ArrayList<>();
    }

    private EconomyResponse notImplemented() {
        return new EconomyResponse(0, 0, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "Les banques ne sont pas supportees par Block2Core");
    }
}
