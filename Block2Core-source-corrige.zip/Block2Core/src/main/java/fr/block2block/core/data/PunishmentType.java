package fr.block2block.core.data;

public enum PunishmentType {
    BAN,
    TEMPBAN,
    MUTE,
    TEMPMUTE,
    KICK,
    WARN,
    IPBAN,
    BLACKLIST,
    JAIL
}
