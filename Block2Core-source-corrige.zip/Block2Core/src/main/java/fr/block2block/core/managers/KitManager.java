package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.Kit;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.util.TimeUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere la reclamation des kits par grade et leur cooldown (stocke en base SQLite).
 * Un joueur peut reclamer n'importe quel kit dont le niveau de grade requis
 * est inferieur ou egal a son grade actuel (chaque kit garde son propre
 * cooldown independant).
 */
public class KitManager {

    private final Block2Core plugin;

    public KitManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public Kit getKit(Grade grade) {
        String key = grade.key();
        return new Kit(key,
                plugin.getConfigManager().kitCooldownSeconds(key),
                plugin.getConfigManager().kitMoney(key),
                plugin.getConfigManager().kitItems(key));
    }

    /** Le staff (n'importe quel grade) a acces a tous les kits, independamment de son grade joueur nominal. */
    public boolean isAllowed(PlayerData data, Grade kitGrade) {
        if (data.isStaff()) return true;
        return data.getGrade().ordinal() >= kitGrade.ordinal();
    }

    /** Verifie le cooldown restant (en secondes, 0 si disponible) et effectue la reclamation si possible. */
    public void claim(Player player, Grade kitGrade, Consumer<ClaimResult> callback) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) {
            callback.accept(new ClaimResult(false, 0, null));
            return;
        }
        if (!isAllowed(data, kitGrade)) {
            callback.accept(new ClaimResult(false, -1, null));
            return;
        }

        Kit kit = getKit(kitGrade);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            long remaining = getRemainingCooldownBlocking(player.getUniqueId(), kitGrade.key(), kit.cooldownSeconds());
            if (remaining > 0) {
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(new ClaimResult(false, remaining, null)));
                return;
            }
            setCooldownBlocking(player.getUniqueId(), kitGrade.key());
            Bukkit.getScheduler().runTask(plugin, () -> {
                giveKit(player, kit);
                callback.accept(new ClaimResult(true, 0, kit));
            });
        });
    }

    private void giveKit(Player player, Kit kit) {
        for (ItemStack item : kit.items()) {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item.clone());
            for (ItemStack extra : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), extra);
            }
        }
        if (kit.money() > 0) {
            plugin.getEconomyManager().deposit(player.getUniqueId(), kit.money());
        }
    }

    private long getRemainingCooldownBlocking(java.util.UUID uuid, String kitKey, long cooldownSeconds) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "SELECT last_used_millis FROM b2c_kit_cooldowns WHERE uuid = ? AND kit_key = ?")) {
            statement.setString(1, uuid.toString());
            statement.setString(2, kitKey);
            try (var rs = statement.executeQuery()) {
                if (rs.next()) {
                    long last = rs.getLong("last_used_millis");
                    long elapsed = (System.currentTimeMillis() - last) / 1000L;
                    return Math.max(0, cooldownSeconds - elapsed);
                }
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur lecture cooldown kit", exception);
        }
        return 0;
    }

    private void setCooldownBlocking(java.util.UUID uuid, String kitKey) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "INSERT INTO b2c_kit_cooldowns (uuid, kit_key, last_used_millis) VALUES (?, ?, ?) " +
                             "ON CONFLICT(uuid, kit_key) DO UPDATE SET last_used_millis = excluded.last_used_millis")) {
            long now = System.currentTimeMillis();
            statement.setString(1, uuid.toString());
            statement.setString(2, kitKey);
            statement.setLong(3, now);
            statement.executeUpdate();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur ecriture cooldown kit", exception);
        }
    }

    public record ClaimResult(boolean success, long remainingCooldownSeconds, Kit kit) {
    }
}
