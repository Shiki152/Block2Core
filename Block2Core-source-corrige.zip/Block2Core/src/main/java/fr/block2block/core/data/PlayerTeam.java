package fr.block2block.core.data;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Equipe (faction) de joueurs. Le role peut etre OWNER ou MEMBER.
 */
public class PlayerTeam {

    public enum Role { OWNER, MEMBER }

    private final int id;
    private String name;
    private UUID owner;
    private final Map<UUID, Role> members = new HashMap<>();

    private String homeWorld;
    private double homeX, homeY, homeZ;
    private float homeYaw, homePitch;
    private boolean homeSet = false;

    public PlayerTeam(int id, String name, UUID owner) {
        this.id = id;
        this.name = name;
        this.owner = owner;
        this.members.put(owner, Role.OWNER);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getOwner() {
        return owner;
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    public Map<UUID, Role> getMembers() {
        return members;
    }

    public boolean isMember(UUID uuid) {
        return members.containsKey(uuid);
    }

    public void addMember(UUID uuid) {
        members.putIfAbsent(uuid, Role.MEMBER);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    public boolean hasHome() {
        return homeSet;
    }

    public void setHome(String world, double x, double y, double z, float yaw, float pitch) {
        this.homeWorld = world;
        this.homeX = x;
        this.homeY = y;
        this.homeZ = z;
        this.homeYaw = yaw;
        this.homePitch = pitch;
        this.homeSet = true;
    }

    public String getHomeWorld() {
        return homeWorld;
    }

    public double getHomeX() {
        return homeX;
    }

    public double getHomeY() {
        return homeY;
    }

    public double getHomeZ() {
        return homeZ;
    }

    public float getHomeYaw() {
        return homeYaw;
    }

    public float getHomePitch() {
        return homePitch;
    }
}
