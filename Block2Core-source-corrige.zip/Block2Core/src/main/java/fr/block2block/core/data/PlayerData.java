package fr.block2block.core.data;

import java.util.UUID;

/**
 * Cache en memoire des donnees d'un joueur pendant sa session.
 * Persiste en base SQLite via les managers concernes (RankManager, PlaytimeManager...).
 */
public class PlayerData {

    private final UUID uuid;
    private String name;

    private Grade grade = Grade.PAYSAN;
    private StaffRank staffRank = null;
    private String title = null; // titre de quete equipe (peut etre null)

    private long playtimeSeconds = 0L;
    private long sessionStartMillis = System.currentTimeMillis();
    private double balance = 0.0;

    private long flyTimeRemainingSeconds = 0L; // budget quotidien Master
    private long flyLastResetEpochDay = -1L;

    private boolean flying = false;
    private boolean vanished = false;
    private boolean god = false;
    private boolean frozen = false;
    private long mutedUntilMillis = 0L; // 0 = non mute, -1 = mute permanent, >0 = timestamp de fin
    private String mutedReason = null;

    private boolean authenticated = false;
    private boolean hasPasswordSet = false;
    private long authJoinedAtMillis = System.currentTimeMillis();

    private Integer teamId = null;

    private boolean tutorialCompleted = false;
    private int tutorialStep = -1; // -1 = pas en cours

    private boolean teamChatMode = false;

    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    public StaffRank getStaffRank() {
        return staffRank;
    }

    public void setStaffRank(StaffRank staffRank) {
        this.staffRank = staffRank;
    }

    public boolean isStaff() {
        return staffRank != null;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getPlaytimeSeconds() {
        return playtimeSeconds;
    }

    public void setPlaytimeSeconds(long playtimeSeconds) {
        this.playtimeSeconds = playtimeSeconds;
    }

    public void addPlaytimeSeconds(long seconds) {
        this.playtimeSeconds += seconds;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public long getSessionStartMillis() {
        return sessionStartMillis;
    }

    public void setSessionStartMillis(long sessionStartMillis) {
        this.sessionStartMillis = sessionStartMillis;
    }

    public long getFlyTimeRemainingSeconds() {
        return flyTimeRemainingSeconds;
    }

    public void setFlyTimeRemainingSeconds(long flyTimeRemainingSeconds) {
        this.flyTimeRemainingSeconds = Math.max(0, flyTimeRemainingSeconds);
    }

    public long getFlyLastResetEpochDay() {
        return flyLastResetEpochDay;
    }

    public void setFlyLastResetEpochDay(long flyLastResetEpochDay) {
        this.flyLastResetEpochDay = flyLastResetEpochDay;
    }

    public boolean isFlying() {
        return flying;
    }

    public void setFlying(boolean flying) {
        this.flying = flying;
    }

    public boolean isVanished() {
        return vanished;
    }

    public void setVanished(boolean vanished) {
        this.vanished = vanished;
    }

    public boolean isGod() {
        return god;
    }

    public void setGod(boolean god) {
        this.god = god;
    }

    public boolean isFrozen() {
        return frozen;
    }

    public void setFrozen(boolean frozen) {
        this.frozen = frozen;
    }

    public long getMutedUntilMillis() {
        return mutedUntilMillis;
    }

    public void setMutedUntilMillis(long mutedUntilMillis) {
        this.mutedUntilMillis = mutedUntilMillis;
    }

    public String getMutedReason() {
        return mutedReason;
    }

    public void setMutedReason(String mutedReason) {
        this.mutedReason = mutedReason;
    }

    public boolean isMuted() {
        if (mutedUntilMillis == 0L) return false;
        if (mutedUntilMillis == -1L) return true;
        return System.currentTimeMillis() < mutedUntilMillis;
    }

    public boolean isAuthenticated() {
        return authenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        this.authenticated = authenticated;
    }

    public boolean isHasPasswordSet() {
        return hasPasswordSet;
    }

    public void setHasPasswordSet(boolean hasPasswordSet) {
        this.hasPasswordSet = hasPasswordSet;
    }

    public long getAuthJoinedAtMillis() {
        return authJoinedAtMillis;
    }

    public void setAuthJoinedAtMillis(long authJoinedAtMillis) {
        this.authJoinedAtMillis = authJoinedAtMillis;
    }

    public Integer getTeamId() {
        return teamId;
    }

    public void setTeamId(Integer teamId) {
        this.teamId = teamId;
    }

    public boolean isTutorialCompleted() {
        return tutorialCompleted;
    }

    public void setTutorialCompleted(boolean tutorialCompleted) {
        this.tutorialCompleted = tutorialCompleted;
    }

    public int getTutorialStep() {
        return tutorialStep;
    }

    public void setTutorialStep(int tutorialStep) {
        this.tutorialStep = tutorialStep;
    }

    public boolean isTeamChatMode() {
        return teamChatMode;
    }

    public void setTeamChatMode(boolean teamChatMode) {
        this.teamChatMode = teamChatMode;
    }
}
