package fr.block2block.core.listeners;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.Locale;

/**
 * Verrouillage complet pre-connexion : tant qu'un joueur n'est pas authentifie (ou
 * auto-authentifie via Bedrock), on bloque son mouvement, toute commande hors /login et
 * /register, les degats subis/infliges, la casse/pose de blocs, les interactions (blocs,
 * entites), les clics d'inventaire, le drop d'objets et le changement d'objet en main. Le
 * joueur est aussi expulse si le delai de session (auth.session-timeout-seconds) est depasse.
 * Objectif : empecher toute action en jeu (et donc tout impact sur le monde ou l'economie)
 * avant qu'une identite ne soit prouvee, puisque le serveur tourne en mode offline.
 */
public class AuthListener implements Listener {

    private static final List<String> ALLOWED_COMMANDS = List.of("/login", "/register");

    private final Block2Core plugin;
    private BukkitTask timeoutTask;

    public AuthListener(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void start() {
        timeoutTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkTimeouts, 20L * 5, 20L * 5);
    }

    public void stop() {
        if (timeoutTask != null) timeoutTask.cancel();
    }

    private void checkTimeouts() {
        int timeoutSeconds = plugin.getConfigManager().authSessionTimeoutSeconds();
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerData(player.getUniqueId());
            if (data == null || data.isAuthenticated()) continue;
            long elapsed = (System.currentTimeMillis() - data.getAuthJoinedAtMillis()) / 1000L;
            if (elapsed >= timeoutSeconds) {
                player.kick(TextUtil.parse("<red>Temps de connexion ecoule. Reconnecte-toi et identifie-toi plus vite."));
            }
        }
    }

    private boolean isLocked(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        return data != null && !data.isAuthenticated();
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        PlayerData data = plugin.getPlayerData(event.getPlayer().getUniqueId());
        if (data == null || data.isAuthenticated()) return;
        if (event.getFrom().distanceSquared(event.getTo()) == 0) return;

        double maxDistance = plugin.getConfigManager().authMaxMoveDistance();
        if (event.getFrom().distance(event.getTo()) > maxDistance) {
            event.setTo(event.getFrom());
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        PlayerData data = plugin.getPlayerData(event.getPlayer().getUniqueId());
        if (data == null || data.isAuthenticated()) return;

        String lower = event.getMessage().toLowerCase(Locale.ROOT);
        boolean allowed = ALLOWED_COMMANDS.stream().anyMatch(lower::startsWith);
        if (!allowed) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(TextUtil.parse(data.isHasPasswordSet()
                    ? "<red>Tu dois d'abord te connecter avec <yellow>/login <motdepasse>"
                    : "<red>Tu dois d'abord t'inscrire avec <yellow>/register <motdepasse> <motdepasse>"));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (isLocked(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (isLocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (isLocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (isLocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (isLocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && isLocked(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (isLocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onHotbarSwitch(PlayerItemHeldEvent event) {
        if (isLocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        if (isLocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }
}
