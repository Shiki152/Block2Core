package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.StaffRank;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere l'inscription et la connexion des joueurs (/register /login /changepassword),
 * necessaire car le serveur tourne en mode offline pour accepter a la fois les
 * comptes premium (Java) et les comptes non-premium ("crack") : dans ce mode,
 * Mojang ne peut pas garantir l'identite d'un pseudo, d'ou ce systeme de mot
 * de passe maison (hash SHA-256 + sel aleatoire par compte).
 */
public class AuthManager {

    private final Block2Core plugin;
    private static final SecureRandom RANDOM = new SecureRandom();

    /** Compteur de tentatives de /login echouees par joueur (anti-bruteforce, remis a zero a la connexion ou a la deconnexion). */
    private final Map<UUID, Integer> failedLoginAttempts = new ConcurrentHashMap<>();

    public AuthManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void resetLoginAttempts(UUID uuid) {
        failedLoginAttempts.remove(uuid);
    }

    public boolean isRegisteredBlocking(UUID uuid) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("SELECT 1 FROM b2c_auth WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (var rs = statement.executeQuery()) {
                return rs.next();
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur verification inscription", exception);
            return false;
        }
    }

    public void register(Player player, String password, String confirmPassword, Consumer<AuthResult> callback) {
        int minLength = plugin.getConfigManager().authMinPasswordLength();
        if (!password.equals(confirmPassword)) {
            callback.accept(AuthResult.PASSWORDS_DONT_MATCH);
            return;
        }
        if (password.length() < minLength) {
            callback.accept(AuthResult.PASSWORD_TOO_SHORT);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            if (isRegisteredBlocking(player.getUniqueId())) {
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.ALREADY_REGISTERED));
                return;
            }
            String salt = generateSalt();
            String hash = hash(password, salt);
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_auth (uuid, username, password_hash, password_salt, registered_at, last_ip) VALUES (?,?,?,?,?,?)")) {
                statement.setString(1, player.getUniqueId().toString());
                statement.setString(2, player.getName());
                statement.setString(3, hash);
                statement.setString(4, salt);
                statement.setLong(5, System.currentTimeMillis());
                statement.setString(6, player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : null);
                statement.executeUpdate();
                var data = plugin.getPlayerData(player.getUniqueId());
                if (data != null) {
                    data.setAuthenticated(true);
                    data.setHasPasswordSet(true);
                }
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.SUCCESS));
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur inscription", exception);
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.ERROR));
            }
        });
    }

    public void login(Player player, String password, Consumer<AuthResult> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT password_hash, password_salt FROM b2c_auth WHERE uuid = ?")) {
                statement.setString(1, player.getUniqueId().toString());
                try (var rs = statement.executeQuery()) {
                    if (!rs.next()) {
                        Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.NOT_REGISTERED));
                        return;
                    }
                    String storedHash = rs.getString("password_hash");
                    String salt = rs.getString("password_salt");
                    if (!hash(password, salt).equals(storedHash)) {
                        Bukkit.getScheduler().runTask(plugin, () -> registerFailedAttempt(player, callback));
                        return;
                    }
                }
                try (var updateIp = connection.prepareStatement("UPDATE b2c_auth SET last_ip = ? WHERE uuid = ?")) {
                    updateIp.setString(1, player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : null);
                    updateIp.setString(2, player.getUniqueId().toString());
                    updateIp.executeUpdate();
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur connexion", exception);
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.ERROR));
                return;
            }
            var data = plugin.getPlayerData(player.getUniqueId());
            if (data != null) data.setAuthenticated(true);
            resetLoginAttempts(player.getUniqueId());
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.SUCCESS));
        });
    }

    /**
     * Comptabilise une tentative de /login echouee et expulse le joueur au-dela du seuil
     * configure (auth.max-login-attempts, 5 par defaut). Protection anti-bruteforce basique :
     * en mode offline, un mot de passe faible pourrait sinon etre teste indefiniment.
     */
    private void registerFailedAttempt(Player player, Consumer<AuthResult> callback) {
        int maxAttempts = plugin.getConfigManager().authMaxLoginAttempts();
        int attempts = failedLoginAttempts.merge(player.getUniqueId(), 1, Integer::sum);
        if (attempts >= maxAttempts) {
            failedLoginAttempts.remove(player.getUniqueId());
            player.kick(TextUtil.parse("<red><bold>Trop de tentatives de connexion echouees.<newline><gray>Reconnecte-toi et verifie ton mot de passe."));
            return;
        }
        callback.accept(AuthResult.WRONG_PASSWORD);
    }

    /**
     * A appeler (sur le thread principal) juste apres qu'un joueur vient de s'authentifier
     * avec succes, quel que soit le chemin (/register, /login, ou auto-authentification
     * Bedrock) : accorde les permissions staff si applicable et restaure une eventuelle
     * session /staffmode interrompue par un crash/relog.
     */
    public void finalizeAuthentication(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return;
        data.setAuthenticated(true);
        resetLoginAttempts(player.getUniqueId());
        plugin.getRankManager().applyStaffPermissions(player, data.getStaffRank());
        plugin.getPlayerStateManager().restoreStaffModeIfNeeded(player);
    }

    /**
     * Alerte le staff connecte lorsqu'un compte possedant un grade staff se connecte sans
     * etre encore authentifie : en mode offline, n'importe qui peut se connecter sous ce
     * pseudo tant qu'il ne prouve pas son identite avec /login, ce qui merite une vigilance
     * particuliere (compte potentiellement usurpe).
     */
    public void alertStaffOfUnauthenticatedStaffAccount(Player player, StaffRank rank) {
        var alert = TextUtil.parse("<dark_red><bold>⚠ SECURITE <gray>» <white>" + player.getName() +
                " <gray>s'est connecte sur un compte <white>" + rank.key().toUpperCase() +
                " <gray>mais n'est <white>pas encore authentifie<gray>. Surveille sa connexion jusqu'a /login.");
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.equals(player) && online.hasPermission("block2core.staff")) {
                online.sendMessage(alert);
            }
        }
    }

    public void changePassword(Player player, String oldPassword, String newPassword, Consumer<AuthResult> callback) {
        int minLength = plugin.getConfigManager().authMinPasswordLength();
        if (newPassword.length() < minLength) {
            callback.accept(AuthResult.PASSWORD_TOO_SHORT);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                String storedHash, salt;
                try (var statement = connection.prepareStatement("SELECT password_hash, password_salt FROM b2c_auth WHERE uuid = ?")) {
                    statement.setString(1, player.getUniqueId().toString());
                    try (var rs = statement.executeQuery()) {
                        if (!rs.next()) {
                            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.NOT_REGISTERED));
                            return;
                        }
                        storedHash = rs.getString("password_hash");
                        salt = rs.getString("password_salt");
                    }
                }
                if (!hash(oldPassword, salt).equals(storedHash)) {
                    Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.WRONG_PASSWORD));
                    return;
                }
                String newSalt = generateSalt();
                String newHash = hash(newPassword, newSalt);
                try (var statement = connection.prepareStatement("UPDATE b2c_auth SET password_hash = ?, password_salt = ? WHERE uuid = ?")) {
                    statement.setString(1, newHash);
                    statement.setString(2, newSalt);
                    statement.setString(3, player.getUniqueId().toString());
                    statement.executeUpdate();
                }
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.SUCCESS));
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur changement mot de passe", exception);
                Bukkit.getScheduler().runTask(plugin, () -> callback.accept(AuthResult.ERROR));
            }
        });
    }

    private static String generateSalt() {
        byte[] bytes = new byte[16];
        RANDOM.nextBytes(bytes);
        return HexFormat.of().formatHex(bytes);
    }

    private static String hash(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(salt.getBytes());
            byte[] hashed = digest.digest(password.getBytes());
            return HexFormat.of().formatHex(hashed);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException(exception);
        }
    }

    public enum AuthResult {
        SUCCESS, ALREADY_REGISTERED, NOT_REGISTERED, WRONG_PASSWORD,
        PASSWORDS_DONT_MATCH, PASSWORD_TOO_SHORT, ERROR
    }
}
