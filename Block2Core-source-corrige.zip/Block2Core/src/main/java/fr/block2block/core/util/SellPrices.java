package fr.block2block.core.util;

import org.bukkit.Material;

import java.util.Map;

/**
 * Table de prix de vente (/sell), sur le modele d'un worth.yml de gros plugin d'economie
 * (type EssentialsX / ShopGUIPlus) : un prix unitaire par materiau, applique a peu pres la
 * meme logique de prix pour tous les objets d'une meme categorie (minerai brut < lingot,
 * ressource commune < ressource rare, etc). Calibree pour rester coherente avec l'echelle du
 * serveur (voir ShopGUI pour les prix d'achat, RankManager pour les couts de rankup) : vendre
 * puis racheter le meme objet en boutique fait toujours perdre de l'argent, pas de boucle
 * d'arbitrage gratuite.
 */
public final class SellPrices {

    private static final Map<Material, Double> PRICES = Map.ofEntries(
            // --- Minerais bruts / lingots ---
            Map.entry(Material.COAL, 2.0),
            Map.entry(Material.CHARCOAL, 1.5),
            Map.entry(Material.RAW_IRON, 3.0),
            Map.entry(Material.IRON_ORE, 3.0),
            Map.entry(Material.DEEPSLATE_IRON_ORE, 3.0),
            Map.entry(Material.IRON_INGOT, 6.0),
            Map.entry(Material.RAW_GOLD, 4.0),
            Map.entry(Material.GOLD_ORE, 4.0),
            Map.entry(Material.DEEPSLATE_GOLD_ORE, 4.0),
            Map.entry(Material.GOLD_INGOT, 10.0),
            Map.entry(Material.GOLD_NUGGET, 1.0),
            Map.entry(Material.RAW_COPPER, 2.0),
            Map.entry(Material.COPPER_ORE, 2.0),
            Map.entry(Material.DEEPSLATE_COPPER_ORE, 2.0),
            Map.entry(Material.COPPER_INGOT, 4.0),
            Map.entry(Material.DIAMOND, 150.0),
            Map.entry(Material.EMERALD, 40.0),
            Map.entry(Material.LAPIS_LAZULI, 2.0),
            Map.entry(Material.REDSTONE, 2.0),
            Map.entry(Material.NETHERITE_SCRAP, 1200.0),
            Map.entry(Material.NETHERITE_INGOT, 3500.0),
            Map.entry(Material.ANCIENT_DEBRIS, 2000.0),
            Map.entry(Material.QUARTZ, 3.0),
            Map.entry(Material.AMETHYST_SHARD, 4.0),
            Map.entry(Material.GLOWSTONE_DUST, 2.0),

            // --- Farming / nourriture ---
            Map.entry(Material.WHEAT, 1.0),
            Map.entry(Material.WHEAT_SEEDS, 0.5),
            Map.entry(Material.CARROT, 1.0),
            Map.entry(Material.POTATO, 1.0),
            Map.entry(Material.BEETROOT, 1.0),
            Map.entry(Material.BEETROOT_SEEDS, 0.5),
            Map.entry(Material.MELON_SLICE, 0.5),
            Map.entry(Material.PUMPKIN, 3.0),
            Map.entry(Material.SUGAR_CANE, 1.0),
            Map.entry(Material.SUGAR, 1.0),
            Map.entry(Material.COCOA_BEANS, 1.5),
            Map.entry(Material.NETHER_WART, 2.0),
            Map.entry(Material.APPLE, 3.0),
            Map.entry(Material.BREAD, 2.0),
            Map.entry(Material.EGG, 1.0),
            Map.entry(Material.KELP, 0.3),
            Map.entry(Material.CACTUS, 1.0),
            Map.entry(Material.BEEF, 2.0),
            Map.entry(Material.COOKED_BEEF, 3.0),
            Map.entry(Material.PORKCHOP, 2.0),
            Map.entry(Material.COOKED_PORKCHOP, 3.0),
            Map.entry(Material.CHICKEN, 2.0),
            Map.entry(Material.COOKED_CHICKEN, 3.0),
            Map.entry(Material.MUTTON, 2.0),
            Map.entry(Material.COOKED_MUTTON, 3.0),
            Map.entry(Material.RABBIT, 2.0),
            Map.entry(Material.COOKED_RABBIT, 3.0),
            Map.entry(Material.COD, 2.0),
            Map.entry(Material.COOKED_COD, 3.0),
            Map.entry(Material.SALMON, 2.0),
            Map.entry(Material.COOKED_SALMON, 3.0),

            // --- Butins de mobs ---
            Map.entry(Material.ROTTEN_FLESH, 0.3),
            Map.entry(Material.BONE, 1.0),
            Map.entry(Material.BONE_MEAL, 1.0),
            Map.entry(Material.STRING, 1.5),
            Map.entry(Material.SPIDER_EYE, 1.5),
            Map.entry(Material.GUNPOWDER, 3.0),
            Map.entry(Material.ENDER_PEARL, 80.0),
            Map.entry(Material.BLAZE_ROD, 35.0),
            Map.entry(Material.BLAZE_POWDER, 20.0),
            Map.entry(Material.SLIME_BALL, 3.0),
            Map.entry(Material.MAGMA_CREAM, 5.0),
            Map.entry(Material.GHAST_TEAR, 50.0),
            Map.entry(Material.PHANTOM_MEMBRANE, 12.0),
            Map.entry(Material.RABBIT_HIDE, 1.0),
            Map.entry(Material.RABBIT_FOOT, 8.0),
            Map.entry(Material.FEATHER, 1.0),
            Map.entry(Material.LEATHER, 3.0),
            Map.entry(Material.INK_SAC, 1.0),
            Map.entry(Material.GLOW_INK_SAC, 3.0),
            Map.entry(Material.SHULKER_SHELL, 250.0),
            Map.entry(Material.PRISMARINE_SHARD, 3.0),
            Map.entry(Material.PRISMARINE_CRYSTALS, 4.0),
            Map.entry(Material.NAUTILUS_SHELL, 60.0),

            // --- Bois (bûches et planches, tous types) ---
            Map.entry(Material.OAK_LOG, 2.0), Map.entry(Material.OAK_PLANKS, 0.5),
            Map.entry(Material.SPRUCE_LOG, 2.0), Map.entry(Material.SPRUCE_PLANKS, 0.5),
            Map.entry(Material.BIRCH_LOG, 2.0), Map.entry(Material.BIRCH_PLANKS, 0.5),
            Map.entry(Material.JUNGLE_LOG, 2.0), Map.entry(Material.JUNGLE_PLANKS, 0.5),
            Map.entry(Material.ACACIA_LOG, 2.0), Map.entry(Material.ACACIA_PLANKS, 0.5),
            Map.entry(Material.DARK_OAK_LOG, 2.0), Map.entry(Material.DARK_OAK_PLANKS, 0.5),
            Map.entry(Material.MANGROVE_LOG, 2.0), Map.entry(Material.MANGROVE_PLANKS, 0.5),
            Map.entry(Material.CHERRY_LOG, 2.0), Map.entry(Material.CHERRY_PLANKS, 0.5),

            // --- Blocs / divers ---
            Map.entry(Material.COBBLESTONE, 0.3),
            Map.entry(Material.STONE, 0.3),
            Map.entry(Material.DIRT, 0.1),
            Map.entry(Material.SAND, 0.2),
            Map.entry(Material.GRAVEL, 0.2),
            Map.entry(Material.GLASS, 0.4),
            Map.entry(Material.CLAY_BALL, 1.0),
            Map.entry(Material.OBSIDIAN, 12.0),
            Map.entry(Material.ICE, 1.0),
            Map.entry(Material.SNOWBALL, 0.1),
            Map.entry(Material.FLINT, 1.0)
    );

    private SellPrices() {
    }

    /** Prix unitaire de vente, ou null si l'objet ne peut pas etre vendu. */
    public static Double priceOf(Material material) {
        return PRICES.get(material);
    }

    public static boolean isSellable(Material material) {
        return PRICES.containsKey(material);
    }
}
