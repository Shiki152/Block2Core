package fr.block2block.core.util;

import org.bukkit.Material;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Table de prix de vente (/sell, /worth), sur le modele d'un worth.yml de gros plugin
 * d'economie. Construite en 3 couches, dans cet ordre (chaque couche peut ecraser la
 * precedente pour un meme materiau) :
 * <ol>
 *     <li>categories generiques (planches/feuilles/tetes de poterie/disques de musique,
 *     toutes variantes) ;</li>
 *     <li>objets "extra" non couverts par la liste ci-dessous (anciennes valeurs par
 *     defaut, minerais bruts, variantes cuites, etc.) ;</li>
 *     <li>la liste de prix fournie explicitement (autorite finale) : minage, farming,
 *     butins de mobs, blocs, objets rares...</li>
 * </ol>
 */
public final class SellPrices {

    private static final Map<Material, Double> PRICES = new HashMap<>();

    static {
        // --- 1. Categories generiques (toutes variantes) ---
        for (Material material : Material.values()) {
            String name = material.name();
            if (name.endsWith("_PLANKS")) {
                PRICES.put(material, 1.5);
            } else if (name.endsWith("_LEAVES")) {
                PRICES.put(material, 0.5);
            } else if (name.endsWith("_POTTERY_SHERD")) {
                PRICES.put(material, 25.0);
            } else if (name.startsWith("MUSIC_DISC")) {
                PRICES.put(material, 60.0);
            }
        }

        // --- 2. Extras non couverts par la liste fournie (anciennes valeurs par defaut) ---
        PRICES.put(Material.CHARCOAL, 1.5);
        PRICES.put(Material.IRON_ORE, 3.0);
        PRICES.put(Material.DEEPSLATE_IRON_ORE, 3.0);
        PRICES.put(Material.GOLD_ORE, 4.0);
        PRICES.put(Material.DEEPSLATE_GOLD_ORE, 4.0);
        PRICES.put(Material.COPPER_ORE, 2.0);
        PRICES.put(Material.DEEPSLATE_COPPER_ORE, 2.0);
        PRICES.put(Material.ANCIENT_DEBRIS, 2000.0);
        PRICES.put(Material.WHEAT_SEEDS, 0.5);
        PRICES.put(Material.BEETROOT_SEEDS, 0.5);
        PRICES.put(Material.SUGAR, 1.0);
        PRICES.put(Material.APPLE, 3.0);
        PRICES.put(Material.BREAD, 2.0);
        PRICES.put(Material.EGG, 1.0);
        PRICES.put(Material.COOKED_BEEF, 3.0);
        PRICES.put(Material.COOKED_PORKCHOP, 3.0);
        PRICES.put(Material.COOKED_CHICKEN, 3.0);
        PRICES.put(Material.COOKED_MUTTON, 3.0);
        PRICES.put(Material.COOKED_RABBIT, 3.0);
        PRICES.put(Material.COOKED_COD, 3.0);
        PRICES.put(Material.COOKED_SALMON, 3.0);
        PRICES.put(Material.SLIME_BALL, 3.0);
        PRICES.put(Material.RABBIT_HIDE, 1.0);
        PRICES.put(Material.FLINT, 1.0);

        // --- 3. Liste de prix fournie (autorite finale : ecrase les couches precedentes) ---
        PRICES.put(Material.CACTUS, 2.5);
        PRICES.put(Material.SUGAR_CANE, 2.2);
        PRICES.put(Material.BAMBOO, 1.8);
        PRICES.put(Material.KELP, 1.5);
        PRICES.put(Material.WHEAT, 3.0);
        PRICES.put(Material.POTATO, 2.8);
        PRICES.put(Material.CARROT, 3.2);
        PRICES.put(Material.BEETROOT, 2.0);
        PRICES.put(Material.PUMPKIN, 4.0);
        PRICES.put(Material.MELON_SLICE, 1.2);
        PRICES.put(Material.MELON, 10.0);
        PRICES.put(Material.NETHER_WART, 6.0);
        PRICES.put(Material.RED_MUSHROOM, 2.5);
        PRICES.put(Material.BROWN_MUSHROOM, 2.5);
        PRICES.put(Material.COCOA_BEANS, 3.5);
        PRICES.put(Material.SWEET_BERRIES, 2.0);
        PRICES.put(Material.OAK_LOG, 5.0);
        PRICES.put(Material.SPRUCE_LOG, 5.0);
        PRICES.put(Material.BIRCH_LOG, 5.0);
        PRICES.put(Material.JUNGLE_LOG, 5.0);
        PRICES.put(Material.ACACIA_LOG, 5.5);
        PRICES.put(Material.DARK_OAK_LOG, 5.5);
        PRICES.put(Material.CHERRY_LOG, 6.0);
        PRICES.put(Material.MANGROVE_LOG, 6.0);
        PRICES.put(Material.COBBLESTONE, 0.8);
        PRICES.put(Material.STONE, 1.2);
        PRICES.put(Material.DEEPSLATE, 1.0);
        PRICES.put(Material.GRANITE, 0.8);
        PRICES.put(Material.ANDESITE, 0.8);
        PRICES.put(Material.DIORITE, 0.8);
        PRICES.put(Material.SAND, 2.0);
        PRICES.put(Material.GRAVEL, 1.5);
        PRICES.put(Material.DIRT, 0.5);
        PRICES.put(Material.COAL, 4.0);
        PRICES.put(Material.COAL_BLOCK, 36.0);
        PRICES.put(Material.RAW_IRON, 8.0);
        PRICES.put(Material.IRON_INGOT, 12.0);
        PRICES.put(Material.IRON_BLOCK, 108.0);
        PRICES.put(Material.RAW_GOLD, 15.0);
        PRICES.put(Material.GOLD_INGOT, 22.0);
        PRICES.put(Material.GOLD_BLOCK, 198.0);
        PRICES.put(Material.LAPIS_LAZULI, 7.0);
        PRICES.put(Material.LAPIS_BLOCK, 63.0);
        PRICES.put(Material.REDSTONE, 5.0);
        PRICES.put(Material.REDSTONE_BLOCK, 45.0);
        PRICES.put(Material.DIAMOND, 45.0);
        PRICES.put(Material.DIAMOND_BLOCK, 405.0);
        PRICES.put(Material.EMERALD, 60.0);
        PRICES.put(Material.EMERALD_BLOCK, 540.0);
        PRICES.put(Material.AMETHYST_SHARD, 6.0);
        PRICES.put(Material.RAW_COPPER, 5.0);
        PRICES.put(Material.COPPER_INGOT, 8.0);
        PRICES.put(Material.NETHERRACK, 0.5);
        PRICES.put(Material.SOUL_SAND, 2.5);
        PRICES.put(Material.SOUL_SOIL, 2.5);
        PRICES.put(Material.QUARTZ, 8.0);
        PRICES.put(Material.QUARTZ_BLOCK, 32.0);
        PRICES.put(Material.GOLD_NUGGET, 2.5);
        PRICES.put(Material.NETHERITE_SCRAP, 150.0);
        PRICES.put(Material.NETHERITE_INGOT, 250.0);
        PRICES.put(Material.MAGMA_CREAM, 6.0);
        PRICES.put(Material.BLAZE_ROD, 18.0);
        PRICES.put(Material.BLAZE_POWDER, 9.0);
        PRICES.put(Material.GHAST_TEAR, 35.0);
        PRICES.put(Material.NETHER_WART_BLOCK, 54.0);
        PRICES.put(Material.NETHER_BRICK, 3.0);
        PRICES.put(Material.BASALT, 1.5);
        PRICES.put(Material.BLACKSTONE, 1.5);
        PRICES.put(Material.GLOWSTONE_DUST, 4.0);
        PRICES.put(Material.GLOWSTONE, 16.0);
        PRICES.put(Material.STRING, 3.0);
        PRICES.put(Material.BONE, 3.5);
        PRICES.put(Material.BONE_MEAL, 1.2);
        PRICES.put(Material.BONE_BLOCK, 10.8);
        PRICES.put(Material.GUNPOWDER, 6.0);
        PRICES.put(Material.ROTTEN_FLESH, 1.0);
        PRICES.put(Material.SPIDER_EYE, 5.0);
        PRICES.put(Material.FERMENTED_SPIDER_EYE, 12.0);
        PRICES.put(Material.ENDER_PEARL, 20.0);
        PRICES.put(Material.LEATHER, 5.0);
        PRICES.put(Material.FEATHER, 2.5);
        PRICES.put(Material.WHITE_WOOL, 3.0);
        PRICES.put(Material.CHICKEN, 4.0);
        PRICES.put(Material.PORKCHOP, 4.5);
        PRICES.put(Material.BEEF, 5.0);
        PRICES.put(Material.MUTTON, 5.0);
        PRICES.put(Material.RABBIT, 6.0);
        PRICES.put(Material.RABBIT_FOOT, 8.0);
        PRICES.put(Material.INK_SAC, 4.0);
        PRICES.put(Material.GLOW_INK_SAC, 8.0);
        PRICES.put(Material.PHANTOM_MEMBRANE, 15.0);
        PRICES.put(Material.TURTLE_SCUTE, 40.0);
        PRICES.put(Material.COD, 4.0);
        PRICES.put(Material.SALMON, 5.0);
        PRICES.put(Material.TROPICAL_FISH, 7.0);
        PRICES.put(Material.PUFFERFISH, 18.0);
        PRICES.put(Material.DRIED_KELP, 3.0);
        PRICES.put(Material.NAUTILUS_SHELL, 45.0);
        PRICES.put(Material.HEART_OF_THE_SEA, 300.0);
        PRICES.put(Material.SPONGE, 35.0);
        PRICES.put(Material.PRISMARINE_SHARD, 6.0);
        PRICES.put(Material.PRISMARINE_CRYSTALS, 10.0);
        PRICES.put(Material.CONDUIT, 500.0);
        PRICES.put(Material.CLAY_BALL, 2.0);
        PRICES.put(Material.CLAY, 8.0);
        PRICES.put(Material.BRICK, 3.0);
        PRICES.put(Material.GLASS, 2.5);
        PRICES.put(Material.OBSIDIAN, 12.0);
        PRICES.put(Material.CRYING_OBSIDIAN, 18.0);
        PRICES.put(Material.COBWEB, 8.0);
        PRICES.put(Material.ENDER_CHEST, 150.0);
        PRICES.put(Material.RESPAWN_ANCHOR, 120.0);
        PRICES.put(Material.TNT, 25.0);
        PRICES.put(Material.LADDER, 1.0);
        PRICES.put(Material.RAIL, 4.0);
        PRICES.put(Material.SHULKER_SHELL, 120.0);
        PRICES.put(Material.SHULKER_BOX, 300.0);
        PRICES.put(Material.TOTEM_OF_UNDYING, 1200.0);
        PRICES.put(Material.WITHER_SKELETON_SKULL, 350.0);
        PRICES.put(Material.NETHER_STAR, 2500.0);
        PRICES.put(Material.BEACON, 3000.0);
        PRICES.put(Material.DRAGON_EGG, 10000.0);
        PRICES.put(Material.TRIDENT, 800.0);
        PRICES.put(Material.SADDLE, 50.0);
        PRICES.put(Material.NAME_TAG, 40.0);
        PRICES.put(Material.ENCHANTED_GOLDEN_APPLE, 800.0);
        PRICES.put(Material.GOLDEN_APPLE, 70.0);
        PRICES.put(Material.GOLDEN_CARROT, 25.0);
        PRICES.put(Material.VINE, 1.0);
        PRICES.put(Material.WEEPING_VINES, 2.0);
        PRICES.put(Material.TWISTING_VINES, 2.0);
        PRICES.put(Material.LILY_PAD, 5.0);
        PRICES.put(Material.MOSS_BLOCK, 1.5);
        PRICES.put(Material.AZALEA, 4.0);
        PRICES.put(Material.SMALL_DRIPLEAF, 3.0);
        PRICES.put(Material.BIG_DRIPLEAF, 6.0);
        PRICES.put(Material.HONEYCOMB, 6.0);
        PRICES.put(Material.HONEY_BLOCK, 32.0);
        PRICES.put(Material.HONEY_BOTTLE, 12.0);
        PRICES.put(Material.CALCITE, 2.0);
        PRICES.put(Material.POINTED_DRIPSTONE, 2.5);
        PRICES.put(Material.SNOWBALL, 1.0);
        PRICES.put(Material.SNOW_BLOCK, 4.0);
        PRICES.put(Material.ICE, 3.0);
        PRICES.put(Material.PACKED_ICE, 8.0);
        PRICES.put(Material.MYCELIUM, 5.0);
        PRICES.put(Material.PODZOL, 5.0);
        PRICES.put(Material.CRIMSON_NYLIUM, 6.0);
        PRICES.put(Material.WARPED_NYLIUM, 6.0);
        PRICES.put(Material.SHROOMLIGHT, 12.0);
        PRICES.put(Material.SEA_LANTERN, 20.0);
        PRICES.put(Material.GLOW_LICHEN, 2.0);
        PRICES.put(Material.SCULK, 15.0);
        PRICES.put(Material.SCULK_CATALYST, 200.0);
        PRICES.put(Material.WITHER_ROSE, 45.0);
        PRICES.put(Material.CHORUS_FRUIT, 6.0);
        PRICES.put(Material.CHORUS_FLOWER, 12.0);
    }

    private SellPrices() {
    }

    /** Prix unitaire de vente, ou null si l'objet ne peut pas etre vendu. */
    public static Double priceOf(Material material) {
        return PRICES.get(material);
    }

    public static boolean isSellable(Material material) {
        return PRICES.containsKey(material);
    }

    /** Tous les materiaux vendables, tries par ordre alphabetique (utilise par /worth). */
    public static List<Material> getAllSellableSorted() {
        return Collections.unmodifiableList(
                PRICES.keySet().stream()
                        .sorted((a, b) -> a.name().compareToIgnoreCase(b.name()))
                        .collect(Collectors.toList()));
    }
}
