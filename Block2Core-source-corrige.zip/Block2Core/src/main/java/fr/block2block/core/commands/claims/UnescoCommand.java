package fr.block2block.core.commands.claims;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /unesco claim : protege le chunk courant de maniere permanente (staff),
 * immunise contre /unclaim par un joueur normal.
 */
public class UnescoCommand implements CommandExecutor {

    private final Block2Core plugin;

    public UnescoCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1 || !args[0].equalsIgnoreCase("claim")) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /unesco claim"));
            return true;
        }
        plugin.getClaimManager().claimUnesco(player, result -> {
            switch (result) {
                case SUCCESS -> player.sendMessage(TextUtil.parse("<green><bold>Chunk protege en UNESCO !"));
                case ALREADY_CLAIMED -> player.sendMessage(TextUtil.parse("<red>Ce chunk est deja reclame."));
                default -> {
                }
            }
        });
        return true;
    }
}
