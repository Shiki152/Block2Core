package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gere les outils de moderation globaux du chat : /mutechat (coupe tout le
 * chat sauf le staff) et /slowchat (delai minimum entre deux messages).
 * Etat volontairement en memoire (outils d'usage ponctuel/urgence).
 */
public class ChatModerationManager {

    private boolean chatMuted = false;
    private long slowChatDelaySeconds = 0;
    private final Map<UUID, Long> lastMessageMillis = new ConcurrentHashMap<>();

    public boolean isChatMuted() {
        return chatMuted;
    }

    public void setChatMuted(boolean chatMuted) {
        this.chatMuted = chatMuted;
    }

    public long getSlowChatDelaySeconds() {
        return slowChatDelaySeconds;
    }

    public void setSlowChatDelaySeconds(long slowChatDelaySeconds) {
        this.slowChatDelaySeconds = Math.max(0, slowChatDelaySeconds);
    }

    public boolean isSlowChatEnabled() {
        return slowChatDelaySeconds > 0;
    }

    /** Renvoie le nombre de secondes restantes avant de pouvoir reparler (0 si autorise), et met a jour le compteur si autorise. */
    public long checkAndUpdateSlowChat(UUID uuid) {
        if (!isSlowChatEnabled()) return 0;
        long now = System.currentTimeMillis();
        Long last = lastMessageMillis.get(uuid);
        if (last != null) {
            long elapsedSeconds = (now - last) / 1000L;
            if (elapsedSeconds < slowChatDelaySeconds) {
                return slowChatDelaySeconds - elapsedSeconds;
            }
        }
        lastMessageMillis.put(uuid, now);
        return 0;
    }

    /** Purge les entrees de plus d'une heure (largement suffisant, slowchat se compte en secondes). */
    public void cleanupStaleEntries() {
        long cutoff = System.currentTimeMillis() - 3600_000L;
        lastMessageMillis.values().removeIf(timestamp -> timestamp < cutoff);
    }
}
