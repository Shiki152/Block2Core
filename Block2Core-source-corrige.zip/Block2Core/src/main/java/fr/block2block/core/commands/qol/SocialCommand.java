package fr.block2block.core.commands.qol;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class SocialCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public SocialCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase()) {
            case "msg" -> msg(sender, args);
            case "reply" -> reply(sender, args);
            case "ignore" -> ignore(sender, args);
            default -> false;
        };
    }

    private boolean msg(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /msg <joueur> <message>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            player.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        if (plugin.getSocialManager().isIgnoring(target.getUniqueId(), player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("<red>Ce joueur t'ignore."));
            return true;
        }
        String message = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        player.sendMessage(TextUtil.parse("<gray>[Toi -> " + target.getName() + "] <white>" + message));
        target.sendMessage(TextUtil.parse("<gray>[" + player.getName() + " -> Toi] <white>" + message));
        plugin.getSocialManager().registerMessage(player.getUniqueId(), target.getUniqueId());
        return true;
    }

    private boolean reply(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        UUID lastSender = plugin.getSocialManager().getLastSender(player.getUniqueId());
        if (lastSender == null) {
            player.sendMessage(TextUtil.parse("<red>Aucun message a qui repondre."));
            return true;
        }
        Player target = Bukkit.getPlayer(lastSender);
        if (target == null) {
            player.sendMessage(TextUtil.parse("<red>Ce joueur n'est plus connecte."));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /reply <message>"));
            return true;
        }
        String message = String.join(" ", args);
        player.sendMessage(TextUtil.parse("<gray>[Toi -> " + target.getName() + "] <white>" + message));
        target.sendMessage(TextUtil.parse("<gray>[" + player.getName() + " -> Toi] <white>" + message));
        plugin.getSocialManager().registerMessage(player.getUniqueId(), target.getUniqueId());
        return true;
    }

    private boolean ignore(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /ignore <joueur>"));
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("<red>Tu ne peux pas t'ignorer toi-meme."));
            return true;
        }
        boolean nowIgnoring = plugin.getSocialManager().toggleIgnore(player.getUniqueId(), target.getUniqueId());
        player.sendMessage(TextUtil.parse(nowIgnoring
                ? "<green>Tu ignores desormais " + args[0]
                : "<green>Tu n'ignores plus " + args[0]));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
