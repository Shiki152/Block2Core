package fr.block2block.core.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Petit builder fluide pour creer des ItemStack utilises dans les GUIs
 * (menu d'aide, boutique, kits...).
 */
public final class ItemBuilder {

    private final ItemStack stack;
    private final ItemMeta meta;

    public ItemBuilder(Material material) {
        this(material, 1);
    }

    public ItemBuilder(Material material, int amount) {
        this.stack = new ItemStack(material, Math.max(1, amount));
        this.meta = stack.getItemMeta();
    }

    public static ItemBuilder of(Material material) {
        return new ItemBuilder(material);
    }

    public ItemBuilder name(Component name) {
        if (meta != null) {
            meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        }
        return this;
    }

    public ItemBuilder name(String miniOrLegacy) {
        return name(TextUtil.parse(miniOrLegacy));
    }

    public ItemBuilder lore(List<Component> lines) {
        if (meta != null) {
            List<Component> italicFree = new ArrayList<>();
            for (Component c : lines) {
                italicFree.add(c.decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(italicFree);
        }
        return this;
    }

    public ItemBuilder loreStrings(List<String> lines) {
        List<Component> comps = new ArrayList<>();
        for (String s : lines) {
            comps.add(TextUtil.parse(s));
        }
        return lore(comps);
    }

    public ItemBuilder loreLine(String line) {
        List<Component> current = meta != null && meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        current.add(TextUtil.parse(line).decoration(TextDecoration.ITALIC, false));
        return lore(current);
    }

    public ItemBuilder amount(int amount) {
        stack.setAmount(Math.max(1, amount));
        return this;
    }

    public ItemBuilder flags(ItemFlag... flags) {
        if (meta != null) {
            meta.addItemFlags(flags);
        }
        return this;
    }

    public ItemBuilder glow(boolean glow) {
        if (glow && meta != null) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        return this;
    }

    /** Definit une tete de joueur via son pseudo (skull). Ignore si le materiau n'est pas PLAYER_HEAD. */
    public ItemBuilder skullOwner(String playerName) {
        if (meta instanceof SkullMeta skullMeta) {
            skullMeta.setOwningPlayer(org.bukkit.Bukkit.getOfflinePlayer(playerName));
        }
        return this;
    }

    public ItemStack build() {
        if (meta != null) {
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
