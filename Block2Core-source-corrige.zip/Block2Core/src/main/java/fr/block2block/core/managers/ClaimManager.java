package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.ClaimChunk;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere les claims de chunks : proprietaires joueur, proprietaires team,
 * claims UNESCO (protection permanente admin) et la liste de confiance
 * (/trust). Le cache en memoire permet des vérifications de protection
 * instantanees (BlockBreakEvent etc.) sans jamais interroger la base depuis
 * le thread principal.
 */
public class ClaimManager {

    private final Block2Core plugin;
    private final Map<String, ClaimChunk> claimsByChunk = new ConcurrentHashMap<>();
    private final Map<UUID, Set<UUID>> trustedBy = new ConcurrentHashMap<>(); // owner -> set(trusted)

    public ClaimManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        loadAll(null);
    }

    public void loadAll(Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                try (var statement = connection.prepareStatement("SELECT * FROM b2c_claims"); var rs = statement.executeQuery()) {
                    while (rs.next()) {
                        UUID owner = rs.getString("owner_uuid") != null ? UUID.fromString(rs.getString("owner_uuid")) : null;
                        Integer teamId = rs.getObject("team_id") != null ? rs.getInt("team_id") : null;
                        ClaimChunk claim = new ClaimChunk(rs.getLong("id"), rs.getString("world"),
                                rs.getInt("chunk_x"), rs.getInt("chunk_z"), owner, teamId, rs.getBoolean("unesco"));
                        claimsByChunk.put(claim.key(), claim);
                    }
                }
                try (var statement = connection.prepareStatement("SELECT owner_uuid, trusted_uuid FROM b2c_trust"); var rs = statement.executeQuery()) {
                    while (rs.next()) {
                        UUID owner = UUID.fromString(rs.getString("owner_uuid"));
                        UUID trusted = UUID.fromString(rs.getString("trusted_uuid"));
                        trustedBy.computeIfAbsent(owner, k -> ConcurrentHashMap.newKeySet()).add(trusted);
                    }
                }
                plugin.getLogger().info("Claims charges : " + claimsByChunk.size());
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement claims", exception);
            }
            if (onDone != null) {
                Bukkit.getScheduler().runTask(plugin, onDone);
            }
        });
    }

    /**
     * Protege automatiquement une zone (3x3 chunks) autour du spawn de chaque monde en tant
     * que claim UNESCO, si ce n'est pas deja fait. Evite que des joueurs (via le tutoriel
     * /tuto qui enseigne /claim juste apres /spawn, par exemple) reclament accidentellement
     * une portion du spawn du serveur.
     */
    public void protectSpawnChunks() {
        org.bukkit.Location customSpawn = plugin.getConfigManager().getCustomSpawn();
        for (org.bukkit.World world : Bukkit.getWorlds()) {
            org.bukkit.Location target = (customSpawn != null && customSpawn.getWorld().equals(world))
                    ? customSpawn : world.getSpawnLocation();
            protectAroundLocation(target, 1);
        }
    }

    /** Reclame en UNESCO tous les chunks non deja reclames dans un rayon (en chunks) autour d'une position. */
    public void protectAroundLocation(org.bukkit.Location location, int radiusInChunks) {
        Chunk center = location.getChunk();
        String world = location.getWorld().getName();
        for (int dx = -radiusInChunks; dx <= radiusInChunks; dx++) {
            for (int dz = -radiusInChunks; dz <= radiusInChunks; dz++) {
                String key = ClaimChunk.keyOf(world, center.getX() + dx, center.getZ() + dz);
                if (claimsByChunk.containsKey(key)) continue;
                insertClaim(world, center.getX() + dx, center.getZ() + dz, null, null, true, null);
            }
        }
    }

    public ClaimChunk getClaim(Chunk chunk) {
        return claimsByChunk.get(ClaimChunk.keyOf(chunk.getWorld().getName(), chunk.getX(), chunk.getZ()));
    }

    public int countOwnedByPlayer(UUID uuid) {
        int count = 0;
        for (ClaimChunk claim : claimsByChunk.values()) {
            if (uuid.equals(claim.owner())) count++;
        }
        return count;
    }

    public int countOwnedByTeam(int teamId) {
        int count = 0;
        for (ClaimChunk claim : claimsByChunk.values()) {
            if (claim.teamId() != null && claim.teamId() == teamId) count++;
        }
        return count;
    }

    /** Retire du cache memoire tous les claims d'une equipe (appele quand celle-ci est dissoute). */
    public void unloadClaimsOfTeam(int teamId) {
        claimsByChunk.values().removeIf(claim -> claim.teamId() != null && claim.teamId() == teamId);
    }

    public List<ClaimChunk> listOwnedByPlayer(UUID uuid) {
        List<ClaimChunk> list = new ArrayList<>();
        for (ClaimChunk claim : claimsByChunk.values()) {
            if (uuid.equals(claim.owner())) list.add(claim);
        }
        return list;
    }

    /** Peut-on construire dans ce chunk ? (protection joueur / team / unesco). Ne verifie PAS les permissions de bypass, a faire cote appelant. */
    public boolean canBuild(UUID uuid, Chunk chunk, Integer playerTeamId) {
        ClaimChunk claim = getClaim(chunk);
        if (claim == null) return true; // non reclame : libre
        if (claim.unesco()) return false;
        if (claim.owner() != null) {
            return claim.owner().equals(uuid) || isTrusted(claim.owner(), uuid);
        }
        if (claim.teamId() != null) {
            return playerTeamId != null && playerTeamId.equals(claim.teamId());
        }
        return true;
    }

    public boolean isTrusted(UUID owner, UUID trusted) {
        return trustedBy.getOrDefault(owner, Set.of()).contains(trusted);
    }

    public void trust(UUID owner, UUID trusted) {
        trustedBy.computeIfAbsent(owner, k -> ConcurrentHashMap.newKeySet()).add(trusted);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("INSERT OR IGNORE INTO b2c_trust (owner_uuid, trusted_uuid) VALUES (?, ?)")) {
                statement.setString(1, owner.toString());
                statement.setString(2, trusted.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde trust", exception);
            }
        });
    }

    public void claimForPlayer(Player player, int claimLimit, Consumer<ClaimResult> callback) {
        Chunk chunk = player.getLocation().getChunk();
        ClaimChunk existing = getClaim(chunk);
        if (existing != null) {
            callback.accept(ClaimResult.ALREADY_CLAIMED);
            return;
        }
        if (countOwnedByPlayer(player.getUniqueId()) >= claimLimit) {
            callback.accept(ClaimResult.LIMIT_REACHED);
            return;
        }
        insertClaim(chunk.getWorld().getName(), chunk.getX(), chunk.getZ(), player.getUniqueId(), null, false,
                () -> callback.accept(ClaimResult.SUCCESS));
    }

    public void claimForTeam(Player player, int teamId, int teamClaimLimit, Consumer<ClaimResult> callback) {
        Chunk chunk = player.getLocation().getChunk();
        ClaimChunk existing = getClaim(chunk);
        if (existing != null) {
            callback.accept(ClaimResult.ALREADY_CLAIMED);
            return;
        }
        if (countOwnedByTeam(teamId) >= teamClaimLimit) {
            callback.accept(ClaimResult.LIMIT_REACHED);
            return;
        }
        insertClaim(chunk.getWorld().getName(), chunk.getX(), chunk.getZ(), null, teamId, false,
                () -> callback.accept(ClaimResult.SUCCESS));
    }

    public void claimUnesco(Player player, Consumer<ClaimResult> callback) {
        Chunk chunk = player.getLocation().getChunk();
        if (getClaim(chunk) != null) {
            callback.accept(ClaimResult.ALREADY_CLAIMED);
            return;
        }
        insertClaim(chunk.getWorld().getName(), chunk.getX(), chunk.getZ(), null, null, true,
                () -> callback.accept(ClaimResult.SUCCESS));
    }

    private void insertClaim(String world, int x, int z, UUID owner, Integer teamId, boolean unesco, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            long generatedId = -1;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_claims (world, chunk_x, chunk_z, owner_uuid, team_id, unesco) VALUES (?,?,?,?,?,?)",
                         java.sql.Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, world);
                statement.setInt(2, x);
                statement.setInt(3, z);
                statement.setString(4, owner != null ? owner.toString() : null);
                if (teamId != null) statement.setInt(5, teamId); else statement.setNull(5, java.sql.Types.INTEGER);
                statement.setBoolean(6, unesco);
                statement.executeUpdate();
                try (var keys = statement.getGeneratedKeys()) {
                    if (keys.next()) generatedId = keys.getLong(1);
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur creation claim", exception);
            }
            if (generatedId > 0) {
                ClaimChunk claim = new ClaimChunk(generatedId, world, x, z, owner, teamId, unesco);
                claimsByChunk.put(claim.key(), claim);
            }
            if (onDone != null) {
                Bukkit.getScheduler().runTask(plugin, onDone);
            }
        });
    }

    /** Retire le claim du chunk ou se trouve le joueur. isAdmin=true pour forcer la suppression d'un claim UNESCO ou d'autrui. */
    public void unclaim(Player player, Integer playerTeamId, boolean isAdmin, Consumer<ClaimResult> callback) {
        Chunk chunk = player.getLocation().getChunk();
        ClaimChunk claim = getClaim(chunk);
        if (claim == null) {
            callback.accept(ClaimResult.NOT_CLAIMED);
            return;
        }
        if (!isAdmin) {
            if (claim.unesco()) {
                callback.accept(ClaimResult.NO_PERMISSION);
                return;
            }
            if (claim.owner() != null && !claim.owner().equals(player.getUniqueId())) {
                callback.accept(ClaimResult.NO_PERMISSION);
                return;
            }
            if (claim.teamId() != null && (playerTeamId == null || !playerTeamId.equals(claim.teamId()))) {
                callback.accept(ClaimResult.NO_PERMISSION);
                return;
            }
        }
        claimsByChunk.remove(claim.key());
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("DELETE FROM b2c_claims WHERE id = ?")) {
                statement.setLong(1, claim.id());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur suppression claim", exception);
            }
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(ClaimResult.SUCCESS));
        });
    }

    public enum ClaimResult { SUCCESS, ALREADY_CLAIMED, LIMIT_REACHED, NOT_CLAIMED, NO_PERMISSION }
}
