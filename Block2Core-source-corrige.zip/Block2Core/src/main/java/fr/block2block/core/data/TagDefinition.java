package fr.block2block.core.data;

/**
 * Definition d'un tag (nom + couleur MiniMessage + description), qu'il provienne d'une
 * recompense de quete ou d'un tag cree par le staff pour un evenement (/tagadmin create).
 * Le fait qu'un joueur donne l'ait debloque est stocke separement (table b2c_titles_unlocked,
 * voir TagManager).
 */
public record TagDefinition(String name, String color, String description) {
}
