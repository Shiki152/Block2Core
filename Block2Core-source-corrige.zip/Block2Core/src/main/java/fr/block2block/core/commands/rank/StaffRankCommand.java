package fr.block2block.core.commands.rank;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.StaffRank;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

/**
 * /staff set <joueur> <grade> - attribue ou retire (avec "none") un grade staff.
 * Commande necessaire ajoutee pour permettre l'attribution effective des grades
 * staff (Helper/Staff/Moderateur/Admin/Owner), non couverte explicitement par
 * une commande equivalente a /rank set dans le cahier des charges.
 */
public class StaffRankCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public StaffRankCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2 || !args[0].equalsIgnoreCase("set")) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /staff set <joueur> <grade|none>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /staff set <joueur> <grade|none>"));
            return true;
        }

        StaffRank rank = args[2].equalsIgnoreCase("none") ? null : StaffRank.fromKey(args[2]);
        if (rank == null && !args[2].equalsIgnoreCase("none")) {
            sender.sendMessage(TextUtil.parse("<red>Grade invalide. Grades valides : helper, staff, moderateur, admin, owner, none"));
            return true;
        }

        plugin.getRankManager().setStaffRank(target, rank, () -> {
            String display = rank != null ? plugin.getConfigManager().staffDisplayName(rank) : "aucun";
            sender.sendMessage(TextUtil.parse("<green>Grade staff de " + target.getName() + " mis a jour : " + display));
            target.sendMessage(TextUtil.parse("<green>Ton grade staff est maintenant : " + display));
            plugin.getDisplayManager().applyTabSort(target, plugin.getPlayerData(target.getUniqueId()));
            plugin.getDisplayManager().refreshScoreboard(target);
            plugin.getLogManager().logAction(target.getUniqueId(), sender instanceof Player p ? p.getUniqueId() : null,
                    sender.getName(), "STAFF_SET", display);
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return filter(List.of("set"), args[0]);
        if (args.length == 2) return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
        if (args.length == 3) return filter(List.of("helper", "staff", "moderateur", "admin", "owner", "none"), args[2]);
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
