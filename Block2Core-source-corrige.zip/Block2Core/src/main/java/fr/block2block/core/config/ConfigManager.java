package fr.block2block.core.config;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.StaffRank;
import fr.block2block.core.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Point d'acces unique et type a config.yml.
 */
public class ConfigManager {

    private final Block2Core plugin;

    public ConfigManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        plugin.reloadConfig();
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ---------------------------------------------------------------
    // GRADES JOUEURS
    // ---------------------------------------------------------------

    public String gradeDisplayName(Grade grade) {
        return cfg().getString("grades." + grade.key() + ".display-name", grade.name());
    }

    public String gradeColor(Grade grade) {
        return cfg().getString("grades." + grade.key() + ".color", "<white>");
    }

    public Component gradeFormatted(Grade grade) {
        return TextUtil.parse(gradeColor(grade) + "<bold>" + gradeDisplayName(grade));
    }

    public double rankupCost(Grade grade) {
        return cfg().getDouble("grades." + grade.key() + ".rankup-cost", 0);
    }

    public long rankupPlaytimeSeconds(Grade grade) {
        double hours = cfg().getDouble("grades." + grade.key() + ".rankup-playtime-hours", 0);
        return (long) (hours * 3600L);
    }

    /** Nombre de quetes reclamees (toutes difficultes confondues) requises pour ce grade. */
    public int rankupQuestsRequired(Grade grade) {
        return cfg().getInt("grades." + grade.key() + ".rankup-quests-claimed", 0);
    }

    public int claimsMultiplier() {
        return cfg().getInt("grades.claims-multiplier", 2);
    }

    public int claimLimit(Grade grade) {
        return grade.level() * claimsMultiplier();
    }

    // ---------------------------------------------------------------
    // GRADES STAFF
    // ---------------------------------------------------------------

    public String staffDisplayName(StaffRank rank) {
        return cfg().getString("staff-ranks." + rank.key() + ".display-name", rank.name());
    }

    public String staffColor(StaffRank rank) {
        return cfg().getString("staff-ranks." + rank.key() + ".color", "<white>");
    }

    public Component staffFormatted(StaffRank rank) {
        return TextUtil.parse(staffColor(rank) + "<bold>" + staffDisplayName(rank));
    }

    // ---------------------------------------------------------------
    // TITRES
    // ---------------------------------------------------------------

    public String titleColor() {
        return cfg().getString("titles.color", "<dark_green><bold>");
    }

    public Component titleFormatted(String title) {
        return TextUtil.parse(titleColor() + title);
    }

    // ---------------------------------------------------------------
    // FLY
    // ---------------------------------------------------------------

    public long masterDailyFlySeconds() {
        return cfg().getLong("fly.master-daily-seconds", 1800);
    }

    // ---------------------------------------------------------------
    // KITS
    // ---------------------------------------------------------------

    public long kitCooldownSeconds(String gradeKey) {
        return (long) (cfg().getDouble("kits." + gradeKey + ".cooldown-hours", 24) * 3600L);
    }

    public double kitMoney(String gradeKey) {
        return cfg().getDouble("kits." + gradeKey + ".money", 0);
    }

    public List<ItemStack> kitItems(String gradeKey) {
        List<ItemStack> items = new ArrayList<>();
        for (String entry : cfg().getStringList("kits." + gradeKey + ".items")) {
            String[] parts = entry.split(":");
            try {
                Material material = Material.matchMaterial(parts[0].trim().toUpperCase());
                int amount = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 1;
                if (material != null) {
                    items.add(new ItemStack(material, Math.max(1, amount)));
                }
            } catch (Exception exception) {
                plugin.getLogger().warning("Item de kit invalide dans config.yml : " + entry);
            }
        }
        return items;
    }

    // ---------------------------------------------------------------
    // TUTORIEL
    // ---------------------------------------------------------------

    public int tutorialRewardCoins() {
        return cfg().getInt("tutorial.reward-coins", 25);
    }

    public List<String> tutorialSteps() {
        return cfg().getStringList("tutorial.steps");
    }

    public String tutorialStartMessage() {
        return cfg().getString("tutorial.start-message", "");
    }

    public String tutorialCompletionMessage() {
        return cfg().getString("tutorial.completion-message", "");
    }

    // ---------------------------------------------------------------
    // INFOS
    // ---------------------------------------------------------------

    public String infoLink(String key) {
        return cfg().getString("info." + key, "");
    }

    // ---------------------------------------------------------------
    // TAB
    // ---------------------------------------------------------------

    public String tabHeader() {
        return cfg().getString("tab.header", "");
    }

    public String tabFooter() {
        return cfg().getString("tab.footer", "");
    }

    public int tabRefreshSeconds() {
        return cfg().getInt("tab.refresh-seconds", 3);
    }

    // ---------------------------------------------------------------
    // SCOREBOARD
    // ---------------------------------------------------------------

    public boolean scoreboardEnabled() {
        return cfg().getBoolean("scoreboard.enabled", true);
    }

    public int scoreboardRefreshSeconds() {
        return cfg().getInt("scoreboard.refresh-seconds", 2);
    }

    public String scoreboardTitle() {
        return cfg().getString("scoreboard.title", "");
    }

    public List<String> scoreboardLines() {
        return cfg().getStringList("scoreboard.lines");
    }

    // ---------------------------------------------------------------
    // RTP
    // ---------------------------------------------------------------

    public int rtpRadius() {
        return cfg().getInt("rtp.radius", 5000);
    }

    public int rtpCooldownMinutes() {
        return cfg().getInt("rtp.cooldown-minutes", 10);
    }

    public Grade rtpMinGrade() {
        Grade grade = Grade.fromKey(cfg().getString("rtp.min-grade", "master"));
        return grade != null ? grade : Grade.MASTER;
    }

    // ---------------------------------------------------------------
    // AUTH
    // ---------------------------------------------------------------

    public int authSessionTimeoutSeconds() {
        return cfg().getInt("auth.session-timeout-seconds", 60);
    }

    public int authMinPasswordLength() {
        return cfg().getInt("auth.min-password-length", 4);
    }

    public double authMaxMoveDistance() {
        return cfg().getDouble("auth.max-move-distance", 0.3);
    }

    /** Nombre maximum de tentatives de /login avant expulsion automatique (anti-bruteforce). */
    public int authMaxLoginAttempts() {
        return Math.max(1, cfg().getInt("auth.max-login-attempts", 5));
    }

    // ---------------------------------------------------------------
    // BEDROCK / FLOODGATE
    // ---------------------------------------------------------------

    /** Si vrai (defaut), les joueurs Bedrock detectes via Floodgate sont authentifies automatiquement. */
    public boolean bedrockAutoAuthenticate() {
        return cfg().getBoolean("bedrock.auto-authenticate", true);
    }

    // ---------------------------------------------------------------
    // SPAWN PERSONNALISE (/setspawn)
    // ---------------------------------------------------------------

    public boolean hasCustomSpawn() {
        return cfg().isConfigurationSection("spawn.custom");
    }

    public org.bukkit.Location getCustomSpawn() {
        if (!hasCustomSpawn()) return null;
        String worldName = cfg().getString("spawn.custom.world");
        org.bukkit.World world = worldName != null ? org.bukkit.Bukkit.getWorld(worldName) : null;
        if (world == null) return null;
        return new org.bukkit.Location(world,
                cfg().getDouble("spawn.custom.x"), cfg().getDouble("spawn.custom.y"), cfg().getDouble("spawn.custom.z"),
                (float) cfg().getDouble("spawn.custom.yaw"), (float) cfg().getDouble("spawn.custom.pitch"));
    }

    public void setCustomSpawn(org.bukkit.Location location) {
        String path = "spawn.custom.";
        cfg().set(path + "world", location.getWorld().getName());
        cfg().set(path + "x", location.getX());
        cfg().set(path + "y", location.getY());
        cfg().set(path + "z", location.getZ());
        cfg().set(path + "yaw", location.getYaw());
        cfg().set(path + "pitch", location.getPitch());
        plugin.saveConfig();
    }

    // ---------------------------------------------------------------
    // JAILS
    // ---------------------------------------------------------------

    public ConfigurationSection jailSection(String name) {
        return cfg().getConfigurationSection("jails." + name);
    }

    public boolean jailExists(String name) {
        return cfg().isConfigurationSection("jails." + name);
    }

    public void setJail(String name, String world, double x, double y, double z, float yaw, float pitch, int radius) {
        String path = "jails." + name + ".";
        cfg().set(path + "world", world);
        cfg().set(path + "x", x);
        cfg().set(path + "y", y);
        cfg().set(path + "z", z);
        cfg().set(path + "yaw", yaw);
        cfg().set(path + "pitch", pitch);
        cfg().set(path + "radius", radius);
        plugin.saveConfig();
    }

    // ---------------------------------------------------------------
    // ECRANS DE SANCTION / ANNONCES / MAINTENANCE
    // ---------------------------------------------------------------

    public String sanctionScreen(String type, Map<String, String> placeholders) {
        List<String> lines = cfg().getStringList("sanctions-screens." + type);
        String joined = String.join("\n", lines);
        return TextUtil.applyPlaceholders(joined, placeholders);
    }

    public String sanctionBroadcast(String type) {
        return cfg().getString("sanctions-broadcast." + type, "");
    }

    public boolean maintenanceEnabled() {
        return cfg().getBoolean("maintenance.enabled", false);
    }

    public void setMaintenanceEnabled(boolean enabled) {
        cfg().set("maintenance.enabled", enabled);
        plugin.saveConfig();
    }

    public List<String> maintenanceWhitelist() {
        return cfg().getStringList("maintenance.whitelist");
    }

    public void setMaintenanceWhitelist(List<String> names) {
        cfg().set("maintenance.whitelist", names);
        plugin.saveConfig();
    }

    // ---------------------------------------------------------------
    // NETTOYAGE PERIODIQUE
    // ---------------------------------------------------------------

    public int cacheCleanupIntervalMinutes() {
        return Math.max(1, cfg().getInt("cache-cleanup.interval-minutes", 10));
    }

    public int logRetentionDays() {
        return Math.max(1, cfg().getInt("cache-cleanup.log-retention-days", 30));
    }

    // ---------------------------------------------------------------
    // MESSAGES GENERIQUES
    // ---------------------------------------------------------------

    public String message(String key) {
        return cfg().getString("messages." + key, "");
    }

    public Component messageComponent(String key, Map<String, String> placeholders) {
        return TextUtil.parse(message(key), placeholders != null ? placeholders : new HashMap<>());
    }
}
