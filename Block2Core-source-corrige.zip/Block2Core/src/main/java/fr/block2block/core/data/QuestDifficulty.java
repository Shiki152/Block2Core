package fr.block2block.core.data;

import java.util.Locale;

/**
 * Categorie de difficulte d'une quete. Determine l'onglet dans lequel elle apparait dans
 * l'interface /quest (voir gui/QuestGUI).
 */
public enum QuestDifficulty {
    FACILE,
    MOYENNE,
    IMPOSSIBLE;

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }
}
