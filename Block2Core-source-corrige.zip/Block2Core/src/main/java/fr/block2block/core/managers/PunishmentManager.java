package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Punishment;
import fr.block2block.core.data.PunishmentType;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere l'ensemble des sanctions : ban/tempban/unban, mute/tempmute/unmute,
 * kick, warn/warnings/delwarn/clearwarns, ipban/unipban, blacklist/unblacklist.
 * Toutes les sanctions sont stockees dans la table unique b2c_punishments.
 * Chaque sanction "active" (hors warn et reversals) declenche une annonce dans
 * le chat serveur et un ecran de deconnexion/chat formatte (voir config.yml,
 * sections sanctions-screens / sanctions-broadcast).
 */
public class PunishmentManager {

    private final Block2Core plugin;

    public PunishmentManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    /**
     * Resout l'UUID d'un joueur par pseudo en priorisant un joueur actuellement CONNECTE
     * (recherche insensible a la casse) avant de retomber sur le calcul d'UUID offline par nom
     * exact. Important : Bukkit.getOfflinePlayer(nom) calcule un UUID offline different si la
     * casse ne correspond pas exactement au pseudo reel, ce qui faisait echouer silencieusement
     * les sanctions (mute notamment) sur des joueurs en ligne si le staff ne respectait pas la casse.
     */
    private UUID resolveUuid(String name) {
        Player online = Bukkit.getPlayer(name);
        if (online != null) {
            return online.getUniqueId();
        }
        return Bukkit.getOfflinePlayer(name).getUniqueId();
    }

    // ---------------------------------------------------------------
    // VERIFICATIONS BLOQUANTES (utilisees depuis AsyncPlayerPreLoginEvent,
    // qui s'execute deja hors du thread principal : pas besoin de re-async)
    // ---------------------------------------------------------------

    public Punishment checkActiveBanBlocking(UUID uuid) {
        return queryActiveBlocking(uuid, null, List.of(PunishmentType.BAN, PunishmentType.TEMPBAN));
    }

    public Punishment checkActiveIpBanBlocking(String ip) {
        if (ip == null) return null;
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "SELECT * FROM b2c_punishments WHERE ip = ? AND type = 'IPBAN' AND active = 1 ORDER BY id DESC LIMIT 1")) {
            statement.setString(1, ip);
            try (var rs = statement.executeQuery()) {
                if (rs.next()) {
                    Punishment p = mapRow(rs);
                    if (!p.isExpired()) return p;
                }
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur verification ipban", exception);
        }
        return null;
    }

    public Punishment checkActiveBlacklistBlocking(UUID uuid) {
        return queryActiveBlocking(uuid, null, List.of(PunishmentType.BLACKLIST));
    }

    /** Renvoie la sanction de mute active (MUTE/TEMPMUTE), ou null. Utilise pour charger PlayerData au login. */
    public Punishment getActiveMuteBlocking(UUID uuid) {
        return queryActiveBlocking(uuid, null, List.of(PunishmentType.MUTE, PunishmentType.TEMPMUTE));
    }

    /** Verifie si un pseudo (hors ligne) a le droit d'entrer pendant la maintenance (staff en base). */
    public boolean hasStaffRankBlocking(UUID uuid) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("SELECT staff_rank FROM b2c_players WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (var rs = statement.executeQuery()) {
                return rs.next() && rs.getString("staff_rank") != null;
            }
        } catch (Exception exception) {
            return false;
        }
    }

    private Punishment queryActiveBlocking(UUID uuid, String ip, List<PunishmentType> types) {
        StringBuilder sql = new StringBuilder("SELECT * FROM b2c_punishments WHERE active = 1 AND type IN (");
        for (int i = 0; i < types.size(); i++) {
            sql.append("?");
            if (i < types.size() - 1) sql.append(",");
        }
        sql.append(")");
        if (uuid != null) sql.append(" AND target_uuid = ?");
        if (ip != null) sql.append(" AND ip = ?");
        sql.append(" ORDER BY id DESC");

        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(sql.toString())) {
            int idx = 1;
            for (PunishmentType type : types) statement.setString(idx++, type.name());
            if (uuid != null) statement.setString(idx++, uuid.toString());
            if (ip != null) statement.setString(idx++, ip);
            try (var rs = statement.executeQuery()) {
                while (rs.next()) {
                    Punishment p = mapRow(rs);
                    if (!p.isExpired()) return p;
                    else expireBlocking(p.id());
                }
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur verification sanction active", exception);
        }
        return null;
    }

    private void expireBlocking(long id) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("UPDATE b2c_punishments SET active = 0 WHERE id = ?")) {
            statement.setLong(1, id);
            statement.executeUpdate();
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------
    // CREATION DE SANCTIONS
    // ---------------------------------------------------------------

    public void ban(String targetName, UUID staffUuid, String staffName, String reason, Runnable onDone) {
        insert(resolveUuid(targetName), targetName, null, PunishmentType.BAN, reason, staffUuid, staffName, -1, () -> {
            broadcast("ban", targetName, staffName, reason, "Permanent");
            if (onDone != null) onDone.run();
        });
        kickIfOnline(targetName, screen("ban", reason, staffName, "Permanent"));
    }

    public void tempban(String targetName, UUID staffUuid, String staffName, String reason, long durationSeconds, Runnable onDone) {
        long end = System.currentTimeMillis() + durationSeconds * 1000L;
        String duree = TimeUtil.formatShort(durationSeconds);
        insert(resolveUuid(targetName), targetName, null, PunishmentType.TEMPBAN, reason, staffUuid, staffName, end, () -> {
            broadcast("tempban", targetName, staffName, reason, duree);
            if (onDone != null) onDone.run();
        });
        kickIfOnline(targetName, screen("tempban", reason, staffName, duree));
    }

    public void unban(String targetName, Runnable onDone) {
        deactivate(resolveUuid(targetName), List.of(PunishmentType.BAN, PunishmentType.TEMPBAN), onDone);
    }

    public void mute(String targetName, UUID staffUuid, String staffName, String reason, Runnable onDone) {
        UUID targetUuid = resolveUuid(targetName);
        insert(targetUuid, targetName, null, PunishmentType.MUTE, reason, staffUuid, staffName, -1, () -> {
            broadcast("mute", targetName, staffName, reason, "Permanent");
            if (onDone != null) onDone.run();
        });
        applyMuteCache(targetUuid, -1L, reason);
    }

    public void tempmute(String targetName, UUID staffUuid, String staffName, String reason, long durationSeconds, Runnable onDone) {
        UUID targetUuid = resolveUuid(targetName);
        long end = System.currentTimeMillis() + durationSeconds * 1000L;
        String duree = TimeUtil.formatShort(durationSeconds);
        insert(targetUuid, targetName, null, PunishmentType.TEMPMUTE, reason, staffUuid, staffName, end, () -> {
            broadcast("tempmute", targetName, staffName, reason, duree);
            if (onDone != null) onDone.run();
        });
        applyMuteCache(targetUuid, end, reason);
    }

    public void unmute(String targetName, Runnable onDone) {
        UUID targetUuid = resolveUuid(targetName);
        deactivate(targetUuid, List.of(PunishmentType.MUTE, PunishmentType.TEMPMUTE), onDone);
        applyMuteCache(targetUuid, 0L, null);
    }

    private void applyMuteCache(UUID uuid, long until, String reason) {
        var data = plugin.getPlayerData(uuid);
        if (data != null) {
            data.setMutedUntilMillis(until);
            data.setMutedReason(reason);
        }
    }

    public void kick(Player target, String staffName, String reason) {
        insert(target.getUniqueId(), target.getName(), null, PunishmentType.KICK, reason, null, staffName, System.currentTimeMillis(), null);
        target.kick(TextUtil.parse(screen("kick", reason, staffName, null)));
        broadcast("kick", target.getName(), staffName, reason, null);
    }

    public void warn(String targetName, UUID staffUuid, String staffName, String reason, Runnable onDone) {
        insert(resolveUuid(targetName), targetName, null, PunishmentType.WARN, reason, staffUuid, staffName, -1, onDone);
    }

    public void getWarnings(String targetName, Consumer<List<Punishment>> callback) {
        getByTypeForTarget(resolveUuid(targetName), List.of(PunishmentType.WARN), callback);
    }

    public void delWarn(long id, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("DELETE FROM b2c_punishments WHERE id = ? AND type = 'WARN'")) {
                statement.setLong(1, id);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur suppression warn", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void clearWarns(String targetName, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("DELETE FROM b2c_punishments WHERE target_uuid = ? AND type = 'WARN'")) {
                statement.setString(1, resolveUuid(targetName).toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur clearwarns", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void ipban(Player target, UUID staffUuid, String staffName, String reason, Runnable onDone) {
        String ip = target.getAddress() != null ? target.getAddress().getAddress().getHostAddress() : null;
        insert(target.getUniqueId(), target.getName(), ip, PunishmentType.IPBAN, reason, staffUuid, staffName, -1, () -> {
            broadcast("ipban", target.getName(), staffName, reason, null);
            if (onDone != null) onDone.run();
        });
        target.kick(TextUtil.parse(screen("ipban", reason, staffName, null)));
    }

    public void unipban(String ipOrName, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "UPDATE b2c_punishments SET active = 0 WHERE type = 'IPBAN' AND (ip = ? OR target_name = ? COLLATE NOCASE)")) {
                statement.setString(1, ipOrName);
                statement.setString(2, ipOrName);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur unipban", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void blacklist(String targetName, UUID staffUuid, String staffName, String reason, Runnable onDone) {
        insert(resolveUuid(targetName), targetName, null, PunishmentType.BLACKLIST, reason, staffUuid, staffName, -1, () -> {
            broadcast("blacklist", targetName, staffName, reason, null);
            if (onDone != null) onDone.run();
        });
        kickIfOnline(targetName, screen("blacklist", reason, staffName, null));
    }

    public void unblacklist(String targetName, Runnable onDone) {
        deactivate(resolveUuid(targetName), List.of(PunishmentType.BLACKLIST), onDone);
    }

    public void getHistory(String targetName, Consumer<List<Punishment>> callback) {
        getByTypeForTarget(resolveUuid(targetName),
                List.of(PunishmentType.values()), callback);
    }

    private void kickIfOnline(String name, String screenText) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            online.kick(TextUtil.parse(screenText));
        }
    }

    // ---------------------------------------------------------------
    // ECRANS + ANNONCES
    // ---------------------------------------------------------------

    private String screen(String type, String reason, String staffName, String duree) {
        return plugin.getConfigManager().sanctionScreen(type, Map.of(
                "raison", reason != null ? reason : "Aucune raison",
                "staff", staffName != null ? staffName : "Console",
                "duree", duree != null ? duree : "-",
                "discord", plugin.getConfigManager().infoLink("discord")
        ));
    }

    private void broadcast(String type, String targetName, String staffName, String reason, String duree) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            String template = plugin.getConfigManager().sanctionBroadcast(type);
            if (template == null || template.isBlank()) return;
            var placeholders = new java.util.HashMap<String, String>();
            placeholders.put("joueur", targetName);
            placeholders.put("staff", staffName != null ? staffName : "Console");
            placeholders.put("raison", reason != null ? reason : "Aucune raison");
            if (duree != null) placeholders.put("duree", duree);
            Bukkit.getServer().sendMessage(TextUtil.parse(template, placeholders));
        });
    }

    // ---------------------------------------------------------------
    // OUTILS SQL GENERIQUES
    // ---------------------------------------------------------------

    private void insert(UUID targetUuid, String targetName, String ip, PunishmentType type, String reason,
                         UUID staffUuid, String staffName, long endMillis, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_punishments (target_uuid, target_name, ip, type, reason, staff_uuid, staff_name, start_millis, end_millis, active) " +
                                 "VALUES (?,?,?,?,?,?,?,?,?,1)")) {
                statement.setString(1, targetUuid != null ? targetUuid.toString() : null);
                statement.setString(2, targetName);
                statement.setString(3, ip);
                statement.setString(4, type.name());
                statement.setString(5, reason != null ? reason : "Aucune raison");
                statement.setString(6, staffUuid != null ? staffUuid.toString() : null);
                statement.setString(7, staffName);
                statement.setLong(8, System.currentTimeMillis());
                statement.setLong(9, endMillis);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur insertion sanction", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    private void deactivate(UUID targetUuid, List<PunishmentType> types, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            StringBuilder sql = new StringBuilder("UPDATE b2c_punishments SET active = 0 WHERE target_uuid = ? AND type IN (");
            for (int i = 0; i < types.size(); i++) {
                sql.append("?");
                if (i < types.size() - 1) sql.append(",");
            }
            sql.append(")");
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(sql.toString())) {
                statement.setString(1, targetUuid.toString());
                int idx = 2;
                for (PunishmentType type : types) statement.setString(idx++, type.name());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur desactivation sanction", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    private void getByTypeForTarget(UUID targetUuid, List<PunishmentType> types, Consumer<List<Punishment>> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<Punishment> list = new ArrayList<>();
            StringBuilder sql = new StringBuilder("SELECT * FROM b2c_punishments WHERE target_uuid = ? AND type IN (");
            for (int i = 0; i < types.size(); i++) {
                sql.append("?");
                if (i < types.size() - 1) sql.append(",");
            }
            sql.append(") ORDER BY id DESC");
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(sql.toString())) {
                statement.setString(1, targetUuid.toString());
                int idx = 2;
                for (PunishmentType type : types) statement.setString(idx++, type.name());
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) list.add(mapRow(rs));
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur lecture sanctions", exception);
            }
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(list));
        });
    }

    private Punishment mapRow(ResultSet rs) throws SQLException {
        return new Punishment(
                rs.getLong("id"),
                rs.getString("target_uuid") != null ? UUID.fromString(rs.getString("target_uuid")) : null,
                rs.getString("target_name"),
                rs.getString("ip"),
                PunishmentType.valueOf(rs.getString("type")),
                rs.getString("reason"),
                rs.getString("staff_uuid") != null ? UUID.fromString(rs.getString("staff_uuid")) : null,
                rs.getString("staff_name"),
                rs.getLong("start_millis"),
                rs.getLong("end_millis"),
                rs.getBoolean("active")
        );
    }
}
