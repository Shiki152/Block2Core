package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Menu d'aide en GUI 6x9 (54 slots) avec 6 categories, comme demande.
 */
public class HelpGUI implements Listener {

    private final Block2Core plugin;

    private record Category(String title, Material icon, List<String> commands) {
    }

    private static final Map<Integer, Category> CATEGORIES = new LinkedHashMap<>();

    static {
        CATEGORIES.put(10, new Category("<aqua><bold>INFOS", Material.BOOK,
                List.of("/discord", "/don", "/youtube", "/site", "/ip", "/help <page>")));
        CATEGORIES.put(12, new Category("<green><bold>TELEPORTATION", Material.ENDER_PEARL,
                List.of("/spawn", "/home [nom]", "/sethome [nom]", "/delhome <nom>", "/warp [nom]",
                        "/tpa <joueur>", "/tpaccept", "/tpdeny", "/back", "/rtp")));
        CATEGORIES.put(14, new Category("<gold><bold>ECONOMIE", Material.GOLD_INGOT,
                List.of("/bal", "/pay <joueur> <montant>", "/shop", "/sell hand|all", "/kit", "/coinflip <mise>",
                        "/rankup", "/rank info", "/rank top", "/playtime")));
        CATEGORIES.put(16, new Category("<light_purple><bold>SOCIAL", Material.PLAYER_HEAD,
                List.of("/msg <joueur> <message>", "/reply <message>", "/ignore <joueur>", "/report <joueur> <raison>",
                        "/quest", "/tag", "/tuto", "/team chat")));
        CATEGORIES.put(29, new Category("<yellow><bold>CLAIMS / TEAMS", Material.GRASS_BLOCK,
                List.of("/claim", "/unclaim", "/trust <joueur>", "/claims list",
                        "/team create <nom> <cout>", "/team invite <joueur>", "/team accept", "/team home")));
        CATEGORIES.put(33, new Category("<red><bold>MODERATION", Material.IRON_SWORD,
                List.of("/ban /tempban /mute /kick /warn", "/vanish /invsee /tp /freeze /jail",
                        "/staffchat /stafflist /broadcast", "/co /logs /history /reports", "/staffmode")));
    }

    public HelpGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inventory = plugin.getServer().createInventory(new HelpHolder(), 54, TextUtil.parse("<dark_aqua><bold>Menu d'Aide - Block2BlockFr"));

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < 54; i++) {
            inventory.setItem(i, filler);
        }

        for (Map.Entry<Integer, Category> entry : CATEGORIES.entrySet()) {
            Category category = entry.getValue();
            if (category.title().contains("MODERATION") && !player.hasPermission("block2core.staff")) {
                continue;
            }
            List<Component> lore = category.commands().stream()
                    .<Component>map(command -> TextUtil.parse("<gray>" + command))
                    .toList();
            ItemStack item = new ItemBuilder(category.icon())
                    .name(category.title())
                    .lore(lore)
                    .build();
            inventory.setItem(entry.getKey(), item);
        }
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof HelpHolder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !(event.getClickedInventory().getHolder() instanceof HelpHolder)) return;

        Category category = CATEGORIES.get(event.getSlot());
        if (category == null) return;
        Player player = (Player) event.getWhoClicked();
        player.closeInventory();
        player.sendMessage(TextUtil.parse(category.title()));
        for (String command : category.commands()) {
            player.sendMessage(TextUtil.parse("<gray> - <white>" + command));
        }
    }

    public static class HelpHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
