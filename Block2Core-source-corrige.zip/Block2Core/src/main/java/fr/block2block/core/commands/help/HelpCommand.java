package fr.block2block.core.commands.help;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class HelpCommand implements CommandExecutor {

    private static final int PER_PAGE = 8;

    private static final List<String> ALL_COMMANDS = List.of(
            "/spawn - Retour au spawn", "/home [nom] - Aller a une home", "/sethome [nom] - Definir une home",
            "/warp [nom] - Aller a un warp", "/tpa <joueur> - Demander une teleportation", "/back - Derniere position",
            "/bal - Voir son solde", "/pay <joueur> <montant> - Envoyer des Block2Coins", "/shop - Ouvrir la boutique",
            "/sell hand|all - Vendre des objets", "/kit - Reclamer son kit", "/coinflip <mise> - Doubler ou perdre sa mise",
            "/rankup - Monter de grade", "/rank info - Infos grade", "/rank top - Classement",
            "/playtime - Temps de jeu", "/claim - Reclamer un chunk", "/unclaim - Liberer un chunk",
            "/trust <joueur> - Autoriser un joueur", "/team create <nom> <cout> - Creer une equipe",
            "/msg <joueur> <message> - Message prive", "/reply <message> - Repondre",
            "/ignore <joueur> - Ignorer un joueur", "/report <joueur> <raison> - Signaler",
            "/quest - Voir ses quetes", "/tag - Choisir son tag", "/tuto - Tutoriel",
            "/discord - Lien Discord", "/don - Lien don", "/youtube - Lien YouTube", "/site - Lien site", "/ip - IP du serveur"
    );

    private final Block2Core plugin;

    public HelpCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player player) {
                plugin.getHelpGUI().open(player);
                return true;
            }
            sendPage(sender, 1);
            return true;
        }
        try {
            int page = Integer.parseInt(args[0]);
            sendPage(sender, page);
        } catch (NumberFormatException exception) {
            sendPage(sender, 1);
        }
        return true;
    }

    private void sendPage(CommandSender sender, int page) {
        int totalPages = (int) Math.ceil(ALL_COMMANDS.size() / (double) PER_PAGE);
        page = Math.max(1, Math.min(page, totalPages));

        sender.sendMessage(TextUtil.parse("<aqua><bold>--- AIDE (page " + page + "/" + totalPages + ") ---"));
        int start = (page - 1) * PER_PAGE;
        int end = Math.min(start + PER_PAGE, ALL_COMMANDS.size());
        for (int i = start; i < end; i++) {
            sender.sendMessage(TextUtil.parse("<gray>" + ALL_COMMANDS.get(i)));
        }
        sender.sendMessage(TextUtil.parse("<dark_gray>Utilise /help <page> pour naviguer."));
    }
}
