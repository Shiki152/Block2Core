package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Report;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere les signalements de joueurs (/report) et leur traitement par le staff (/reports).
 */
public class ReportManager {

    private final Block2Core plugin;

    public ReportManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void create(Player reporter, String reportedName, String reason) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            long id = -1;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_reports (reporter_uuid, reporter_name, reported_uuid, reported_name, reason, status, created_at) " +
                                 "VALUES (?,?,?,?,?, 'OPEN', ?)", java.sql.Statement.RETURN_GENERATED_KEYS)) {
                var target = Bukkit.getOfflinePlayer(reportedName);
                statement.setString(1, reporter.getUniqueId().toString());
                statement.setString(2, reporter.getName());
                statement.setString(3, target.getUniqueId().toString());
                statement.setString(4, reportedName);
                statement.setString(5, reason);
                statement.setLong(6, System.currentTimeMillis());
                statement.executeUpdate();
                try (var keys = statement.getGeneratedKeys()) {
                    if (keys.next()) id = keys.getLong(1);
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur creation report", exception);
            }
            long finalId = id;
            Bukkit.getScheduler().runTask(plugin, () -> notifyStaff(reporter.getName(), reportedName, reason, finalId));
        });
    }

    private void notifyStaff(String reporterName, String reportedName, String reason, long id) {
        var message = TextUtil.parse("<red><bold>[REPORT] <white>#" + id + " <yellow>" + reporterName +
                " <white>a signale <yellow>" + reportedName + " <gray>: <white>" + reason);
        Sound sound;
        try {
            sound = Sound.valueOf(plugin.getConfig().getString("reports.sound", "ENTITY_EXPERIENCE_ORB_PICKUP"));
        } catch (IllegalArgumentException exception) {
            sound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;
        }
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.hasPermission("block2core.command.reports")) {
                online.sendMessage(message);
                online.playSound(online.getLocation(), sound, 1f, 1f);
            }
        }
    }

    public void list(boolean openOnly, Consumer<List<Report>> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            List<Report> reports = new ArrayList<>();
            String sql = "SELECT * FROM b2c_reports" + (openOnly ? " WHERE status = 'OPEN'" : "") + " ORDER BY created_at DESC LIMIT 50";
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(sql);
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    reports.add(mapRow(rs));
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur liste reports", exception);
            }
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(reports));
        });
    }

    public void get(long id, Consumer<Report> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Report report = null;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_reports WHERE id = ?")) {
                statement.setLong(1, id);
                try (var rs = statement.executeQuery()) {
                    if (rs.next()) report = mapRow(rs);
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur lecture report", exception);
            }
            Report finalReport = report;
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(finalReport));
        });
    }

    public void close(long id, String staffName, String comment, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "UPDATE b2c_reports SET status = 'CLOSED', staff_name = ?, comment = ?, closed_at = ? WHERE id = ?")) {
                statement.setString(1, staffName);
                statement.setString(2, comment);
                statement.setLong(3, System.currentTimeMillis());
                statement.setLong(4, id);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur fermeture report", exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    private Report mapRow(java.sql.ResultSet rs) throws java.sql.SQLException {
        return new Report(
                rs.getLong("id"),
                java.util.UUID.fromString(rs.getString("reporter_uuid")),
                rs.getString("reporter_name"),
                java.util.UUID.fromString(rs.getString("reported_uuid")),
                rs.getString("reported_name"),
                rs.getString("reason"),
                rs.getString("status"),
                rs.getString("comment"),
                rs.getString("staff_name"),
                rs.getLong("created_at"),
                rs.getLong("closed_at")
        );
    }
}
