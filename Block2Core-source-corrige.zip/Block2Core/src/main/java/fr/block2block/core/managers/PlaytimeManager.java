package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;
import java.util.logging.Level;

/**
 * Incremente et persiste le temps de jeu (en secondes) de chaque joueur
 * connecte. Utilise pour les conditions de rankup et /playtime.
 */
public class PlaytimeManager {

    private static final long TICK_INTERVAL_SECONDS = 60L;

    private final Block2Core plugin;
    private BukkitTask task;

    public PlaytimeManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L * TICK_INTERVAL_SECONDS, 20L * TICK_INTERVAL_SECONDS);
    }

    public void stop() {
        if (task != null) {
            task.cancel();
        }
    }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerData(player.getUniqueId());
            if (data == null || !data.isAuthenticated()) continue;
            data.addPlaytimeSeconds(TICK_INTERVAL_SECONDS);
            persist(player.getUniqueId(), data.getPlaytimeSeconds());
        }
    }

    public void persist(UUID uuid, long playtimeSeconds) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("UPDATE b2c_players SET playtime_seconds = ? WHERE uuid = ?")) {
                statement.setLong(1, playtimeSeconds);
                statement.setString(2, uuid.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Impossible de sauvegarder le playtime", exception);
            }
        });
    }

    /** Sauvegarde immediate et synchrone-bloquante cote appelant (a utiliser uniquement en onDisable). */
    public void persistBlocking(UUID uuid, long playtimeSeconds) {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("UPDATE b2c_players SET playtime_seconds = ? WHERE uuid = ?")) {
            statement.setLong(1, playtimeSeconds);
            statement.setString(2, uuid.toString());
            statement.executeUpdate();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Impossible de sauvegarder le playtime (shutdown)", exception);
        }
    }
}
