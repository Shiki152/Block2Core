package fr.block2block.core.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import fr.block2block.core.Block2Core;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

/**
 * Gere la connexion SQLite (via HikariCP) et la creation du schema.
 * Toutes les operations SQL du plugin passent par {@link #getConnection()},
 * appelees depuis un thread asynchrone (jamais depuis le thread principal).
 * <p>
 * SQLite est un fichier local : aucune installation de serveur de base de
 * donnees n'est necessaire. Le pool est volontairement limite a une seule
 * connexion (SQLite n'autorise qu'un seul ecrivain a la fois) ; le mode WAL
 * et un busy_timeout genereux permettent de gerer sereinement les acces
 * concurrents malgre tout.
 */
public class DatabaseManager {

    private final Block2Core plugin;
    private HikariDataSource dataSource;

    public DatabaseManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    /**
     * Initialise la connexion. Retourne false si l'initialisation echoue
     * (le plugin doit alors se desactiver proprement).
     */
    public boolean connect() {
        FileConfiguration cfg = plugin.getConfig();
        String fileName = cfg.getString("database.file", "database.db");

        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }
        File dbFile = new File(plugin.getDataFolder(), fileName);

        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
        // SQLite : un seul ecrivain a la fois, une seule connexion pooled evite les
        // contentions/erreurs "database is locked" inutiles.
        hikariConfig.setMaximumPoolSize(1);
        hikariConfig.setConnectionTimeout(30_000);
        hikariConfig.setPoolName("Block2Core-SQLite-Pool");

        try {
            this.dataSource = new HikariDataSource(hikariConfig);
            try (Connection connection = dataSource.getConnection(); Statement statement = connection.createStatement()) {
                connection.isValid(5);
                // Ameliore fortement la gestion des acces concurrents propre a SQLite.
                statement.execute("PRAGMA journal_mode=WAL;");
                statement.execute("PRAGMA synchronous=NORMAL;");
                statement.execute("PRAGMA busy_timeout=10000;");
                statement.execute("PRAGMA foreign_keys=ON;");
            }
            createTables();
            plugin.getLogger().info("Base de donnees SQLite initialisee avec succes (" + dbFile.getAbsolutePath() + ").");
            return true;
        } catch (Exception exception) {
            plugin.getLogger().log(Level.SEVERE, "Impossible d'initialiser la base SQLite.", exception);
            return false;
        }
    }

    public Connection getConnection() throws SQLException {
        if (dataSource == null || dataSource.isClosed()) {
            throw new SQLException("La source de donnees n'est pas initialisee.");
        }
        return dataSource.getConnection();
    }

    public void disconnect() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    private void createTables() throws SQLException {
        try (Connection connection = getConnection(); Statement statement = connection.createStatement()) {

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_players (
                    uuid VARCHAR(36) NOT NULL PRIMARY KEY,
                    username VARCHAR(16) NOT NULL,
                    grade VARCHAR(32) NOT NULL DEFAULT 'paysan',
                    staff_rank VARCHAR(32) DEFAULT NULL,
                    balance DOUBLE NOT NULL DEFAULT 0,
                    playtime_seconds BIGINT NOT NULL DEFAULT 0,
                    title VARCHAR(64) DEFAULT NULL,
                    fly_remaining_seconds INT NOT NULL DEFAULT 0,
                    fly_last_reset_day BIGINT NOT NULL DEFAULT -1,
                    tutorial_completed INTEGER NOT NULL DEFAULT 0,
                    team_id INT DEFAULT NULL,
                    first_join BIGINT NOT NULL,
                    last_login BIGINT NOT NULL,
                    last_ip VARCHAR(64) DEFAULT NULL
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_auth (
                    uuid VARCHAR(36) NOT NULL PRIMARY KEY,
                    username VARCHAR(16) NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    password_salt VARCHAR(64) NOT NULL,
                    registered_at BIGINT NOT NULL,
                    last_ip VARCHAR(64) DEFAULT NULL
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_homes (
                    owner_uuid VARCHAR(36) NOT NULL,
                    name VARCHAR(32) NOT NULL,
                    world VARCHAR(64) NOT NULL,
                    x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL,
                    yaw FLOAT NOT NULL, pitch FLOAT NOT NULL,
                    PRIMARY KEY (owner_uuid, name)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_warps (
                    name VARCHAR(32) NOT NULL PRIMARY KEY,
                    world VARCHAR(64) NOT NULL,
                    x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL,
                    yaw FLOAT NOT NULL, pitch FLOAT NOT NULL,
                    creator VARCHAR(16) NOT NULL
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_claims (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    world VARCHAR(64) NOT NULL,
                    chunk_x INT NOT NULL,
                    chunk_z INT NOT NULL,
                    owner_uuid VARCHAR(36) DEFAULT NULL,
                    team_id INT DEFAULT NULL,
                    unesco INTEGER NOT NULL DEFAULT 0,
                    UNIQUE (world, chunk_x, chunk_z)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_trust (
                    owner_uuid VARCHAR(36) NOT NULL,
                    trusted_uuid VARCHAR(36) NOT NULL,
                    PRIMARY KEY (owner_uuid, trusted_uuid)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_teams (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(32) NOT NULL UNIQUE,
                    owner_uuid VARCHAR(36) NOT NULL,
                    home_world VARCHAR(64) DEFAULT NULL,
                    home_x DOUBLE DEFAULT NULL, home_y DOUBLE DEFAULT NULL, home_z DOUBLE DEFAULT NULL,
                    home_yaw FLOAT DEFAULT NULL, home_pitch FLOAT DEFAULT NULL,
                    home_set INTEGER NOT NULL DEFAULT 0,
                    created_at BIGINT NOT NULL
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_team_members (
                    team_id INT NOT NULL,
                    uuid VARCHAR(36) NOT NULL,
                    role VARCHAR(16) NOT NULL,
                    PRIMARY KEY (team_id, uuid)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_kit_cooldowns (
                    uuid VARCHAR(36) NOT NULL,
                    kit_key VARCHAR(32) NOT NULL,
                    last_used_millis BIGINT NOT NULL,
                    PRIMARY KEY (uuid, kit_key)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_punishments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    target_uuid VARCHAR(36) DEFAULT NULL,
                    target_name VARCHAR(16) DEFAULT NULL,
                    ip VARCHAR(64) DEFAULT NULL,
                    type VARCHAR(16) NOT NULL,
                    reason VARCHAR(255) DEFAULT NULL,
                    staff_uuid VARCHAR(36) DEFAULT NULL,
                    staff_name VARCHAR(16) DEFAULT NULL,
                    start_millis BIGINT NOT NULL,
                    end_millis BIGINT NOT NULL DEFAULT -1,
                    active INTEGER NOT NULL DEFAULT 1
                )
            """);
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_punishments_target ON b2c_punishments (target_uuid)");
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_punishments_ip ON b2c_punishments (ip)");

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    reporter_uuid VARCHAR(36) NOT NULL,
                    reporter_name VARCHAR(16) NOT NULL,
                    reported_uuid VARCHAR(36) NOT NULL,
                    reported_name VARCHAR(16) NOT NULL,
                    reason VARCHAR(255) NOT NULL,
                    status VARCHAR(16) NOT NULL DEFAULT 'OPEN',
                    comment VARCHAR(255) DEFAULT NULL,
                    staff_name VARCHAR(16) DEFAULT NULL,
                    created_at BIGINT NOT NULL,
                    closed_at BIGINT NOT NULL DEFAULT -1
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_quests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(64) NOT NULL,
                    description VARCHAR(255) DEFAULT NULL,
                    type VARCHAR(16) NOT NULL,
                    target VARCHAR(64) DEFAULT NULL,
                    target_amount INT NOT NULL DEFAULT 1,
                    reward_coins DOUBLE NOT NULL DEFAULT 0,
                    reward_title VARCHAR(64) DEFAULT NULL
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_quest_progress (
                    uuid VARCHAR(36) NOT NULL,
                    quest_id INT NOT NULL,
                    progress INT NOT NULL DEFAULT 0,
                    completed INTEGER NOT NULL DEFAULT 0,
                    reward_claimed INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (uuid, quest_id)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_titles_unlocked (
                    uuid VARCHAR(36) NOT NULL,
                    title VARCHAR(64) NOT NULL,
                    PRIMARY KEY (uuid, title)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_ignores (
                    uuid VARCHAR(36) NOT NULL,
                    ignored_uuid VARCHAR(36) NOT NULL,
                    PRIMARY KEY (uuid, ignored_uuid)
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_block_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uuid VARCHAR(36) NOT NULL,
                    player_name VARCHAR(16) NOT NULL,
                    world VARCHAR(64) NOT NULL,
                    x INT NOT NULL, y INT NOT NULL, z INT NOT NULL,
                    action VARCHAR(8) NOT NULL,
                    block_type VARCHAR(64) NOT NULL,
                    previous_type VARCHAR(64) DEFAULT NULL,
                    rolled_back INTEGER NOT NULL DEFAULT 0,
                    timestamp BIGINT NOT NULL
                )
            """);
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_blocklogs_pos ON b2c_block_logs (world, x, y, z)");
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_blocklogs_player ON b2c_block_logs (uuid)");

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_jails_active (
                    uuid VARCHAR(36) NOT NULL PRIMARY KEY,
                    jail_name VARCHAR(32) NOT NULL,
                    prev_world VARCHAR(64) NOT NULL,
                    prev_x DOUBLE NOT NULL, prev_y DOUBLE NOT NULL, prev_z DOUBLE NOT NULL,
                    prev_yaw FLOAT NOT NULL, prev_pitch FLOAT NOT NULL,
                    end_millis BIGINT NOT NULL
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_staffmode (
                    uuid VARCHAR(36) NOT NULL PRIMARY KEY,
                    inventory TEXT NOT NULL,
                    armor TEXT NOT NULL,
                    offhand TEXT NOT NULL,
                    exp_level INT NOT NULL DEFAULT 0,
                    exp_progress REAL NOT NULL DEFAULT 0,
                    prev_gamemode VARCHAR(16) NOT NULL,
                    saved_at BIGINT NOT NULL
                )
            """);

            statement.executeUpdate("""
                CREATE TABLE IF NOT EXISTS b2c_action_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uuid VARCHAR(36) DEFAULT NULL,
                    staff_uuid VARCHAR(36) DEFAULT NULL,
                    staff_name VARCHAR(16) DEFAULT NULL,
                    action VARCHAR(64) NOT NULL,
                    data VARCHAR(255) DEFAULT NULL,
                    timestamp BIGINT NOT NULL
                )
            """);
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS idx_actionlogs_uuid ON b2c_action_logs (uuid)");
        }
    }
}
