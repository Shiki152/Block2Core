package fr.block2block.core.commands.report;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Report;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class ReportsAdminCommand implements CommandExecutor, TabCompleter {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM HH:mm");

    private final Block2Core plugin;

    public ReportsAdminCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /reports <list|check|close> [id] [commentaire]"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "list" -> handleList(sender);
            case "check" -> handleCheck(sender, args);
            case "close" -> handleClose(sender, args);
            default -> sender.sendMessage(TextUtil.parse("<yellow>Usage : /reports <list|check|close> [id] [commentaire]"));
        }
        return true;
    }

    private void handleList(CommandSender sender) {
        plugin.getReportManager().list(true, reports -> {
            if (reports.isEmpty()) {
                sender.sendMessage(TextUtil.parse("<green>Aucun signalement ouvert."));
                return;
            }
            sender.sendMessage(TextUtil.parse("<red><bold>--- SIGNALEMENTS OUVERTS ---"));
            for (Report report : reports) {
                sender.sendMessage(TextUtil.parse("<gray>#" + report.id() + " <white>" + report.reportedName() +
                        " <gray>signale par <white>" + report.reporterName() + " <gray>: <white>" + report.reason()));
            }
        });
    }

    private void handleCheck(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /reports check <id>"));
            return;
        }
        long id = parseLongOrDefault(args[1], -1);
        plugin.getReportManager().get(id, report -> {
            if (report == null) {
                sender.sendMessage(TextUtil.parse("<red>Signalement introuvable."));
                return;
            }
            sender.sendMessage(TextUtil.parse("<aqua><bold>--- SIGNALEMENT #" + report.id() + " ---"));
            sender.sendMessage(TextUtil.parse("<gray>Signale : <white>" + report.reportedName()));
            sender.sendMessage(TextUtil.parse("<gray>Par : <white>" + report.reporterName()));
            sender.sendMessage(TextUtil.parse("<gray>Raison : <white>" + report.reason()));
            sender.sendMessage(TextUtil.parse("<gray>Statut : <white>" + report.status()));
            sender.sendMessage(TextUtil.parse("<gray>Date : <white>" + DATE_FORMAT.format(new Date(report.createdAt()))));
            if (report.comment() != null) {
                sender.sendMessage(TextUtil.parse("<gray>Commentaire : <white>" + report.comment()));
            }
        });
    }

    private void handleClose(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /reports close <id> <commentaire>"));
            return;
        }
        long id = parseLongOrDefault(args[1], -1);
        String comment = args.length > 2 ? String.join(" ", Arrays.copyOfRange(args, 2, args.length)) : "Aucun commentaire";
        plugin.getReportManager().close(id, sender.getName(), comment,
                () -> sender.sendMessage(TextUtil.parse("<green>Signalement #" + id + " ferme.")));
    }

    private long parseLongOrDefault(String value, long fallback) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException exception) {
            return fallback;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("list", "check", "close").stream()
                    .filter(o -> o.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
