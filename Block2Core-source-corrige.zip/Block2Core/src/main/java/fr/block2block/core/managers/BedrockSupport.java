package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import org.bukkit.Bukkit;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Detecte les joueurs Bedrock connectes via Floodgate, par reflexion.
 * <p>
 * Floodgate est un softdepend (pas une dependance obligatoire dans plugin.yml) : aucune
 * classe Floodgate n'est importee/compilee directement ici, pour que le plugin continue de
 * fonctionner normalement (support Bedrock simplement desactive) si Floodgate n'est pas
 * installe sur le serveur.
 * <p>
 * Les joueurs identifies comme Bedrock par Floodgate n'ont pas de mot de passe Mojang
 * exploitable comme les comptes Java "crack" en mode offline : Floodgate garantit deja leur
 * identite via son propre systeme de comptes lies (XUID). Ils sont donc dispenses de
 * /register /login (authentification automatique au join, voir JoinQuitListener) et ne
 * peuvent pas changer de skin (voir SkinCommand : le client Bedrock ne peut de toute facon
 * pas afficher un skin Java personnalise).
 */
public class BedrockSupport {

    private final Block2Core plugin;
    private boolean floodgateAvailable = false;
    private Object floodgateApiInstance;
    private Method isFloodgatePlayerMethod;

    public BedrockSupport(Block2Core plugin) {
        this.plugin = plugin;
        setup();
    }

    private void setup() {
        if (!Bukkit.getPluginManager().isPluginEnabled("floodgate")) {
            plugin.getLogger().info("Floodgate non detecte : support Bedrock desactive (tous les joueurs sont traites comme Java).");
            return;
        }
        try {
            Class<?> apiClass = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            Method getInstance = apiClass.getMethod("getInstance");
            floodgateApiInstance = getInstance.invoke(null);
            isFloodgatePlayerMethod = apiClass.getMethod("isFloodgatePlayer", UUID.class);
            floodgateAvailable = true;
            plugin.getLogger().info("Floodgate detecte : support Bedrock actif (auto-authentification, /skin bloque pour ces joueurs).");
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING,
                    "Floodgate est installe mais son API n'a pas pu etre chargee par reflexion (version incompatible ?). Support Bedrock desactive.",
                    exception);
            floodgateAvailable = false;
        }
    }

    /** Renvoie true si Floodgate est present ET confirme que ce joueur est connecte depuis Bedrock. */
    public boolean isBedrockPlayer(UUID uuid) {
        if (!floodgateAvailable) return false;
        try {
            Object result = isFloodgatePlayerMethod.invoke(floodgateApiInstance, uuid);
            return result instanceof Boolean isBedrock && isBedrock;
        } catch (Exception exception) {
            return false;
        }
    }
}
