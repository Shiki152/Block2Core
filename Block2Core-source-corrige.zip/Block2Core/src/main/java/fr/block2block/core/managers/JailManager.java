package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gere l'emprisonnement des joueurs (/jail /unjail). Les prisons sont des
 * positions nommees definies dans config.yml (section jails), chacune avec
 * un rayon de confinement. Les emprisonnements actifs sont persistes en base
 * (table b2c_jails_active) pour survivre a un redemarrage du serveur.
 */
public class JailManager {

    private final Block2Core plugin;
    private final Map<UUID, JailedState> jailed = new ConcurrentHashMap<>();
    private BukkitTask expiryTask;

    public JailManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void start() {
        expiryTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkExpirations, 20L * 5, 20L * 5);
    }

    public void stop() {
        if (expiryTask != null) expiryTask.cancel();
    }

    /** Recharge les emprisonnements actifs depuis la base (a appeler au demarrage). */
    public void loadAll() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_jails_active");
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    UUID uuid = UUID.fromString(rs.getString("uuid"));
                    World world = Bukkit.getWorld(rs.getString("prev_world"));
                    Location previous = world != null
                            ? new Location(world, rs.getDouble("prev_x"), rs.getDouble("prev_y"), rs.getDouble("prev_z"),
                                    rs.getFloat("prev_yaw"), rs.getFloat("prev_pitch"))
                            : null;
                    jailed.put(uuid, new JailedState(rs.getString("jail_name"), previous, rs.getLong("end_millis")));
                }
                plugin.getLogger().info("Emprisonnements actifs restaures : " + jailed.size());
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement emprisonnements", exception);
            }
        });
    }

    public boolean jailExists(String name) {
        return plugin.getConfigManager().jailExists(name);
    }

    public Location getJailLocation(String name) {
        ConfigurationSection section = plugin.getConfigManager().jailSection(name);
        if (section == null) return null;
        World world = Bukkit.getWorld(section.getString("world", "world"));
        if (world == null) return null;
        return new Location(world, section.getDouble("x"), section.getDouble("y"), section.getDouble("z"),
                (float) section.getDouble("yaw"), (float) section.getDouble("pitch"));
    }

    public int getJailRadius(String name) {
        ConfigurationSection section = plugin.getConfigManager().jailSection(name);
        return section != null ? section.getInt("radius", 5) : 5;
    }

    public void jail(Player player, String jailName, long durationSeconds, String staffName) {
        Location jailLoc = getJailLocation(jailName);
        if (jailLoc == null) return;
        Location previous = player.getLocation().clone();
        long end = durationSeconds <= 0 ? -1 : System.currentTimeMillis() + durationSeconds * 1000L;
        jailed.put(player.getUniqueId(), new JailedState(jailName, previous, end));
        player.teleport(jailLoc);
        player.sendMessage(TextUtil.parse("<red><bold>Tu as ete emprisonne par <white>" + staffName +
                (durationSeconds > 0 ? "<red> pour " + fr.block2block.core.util.TimeUtil.formatShort(durationSeconds) : "<red> (permanent)")));

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_jails_active (uuid, jail_name, prev_world, prev_x, prev_y, prev_z, prev_yaw, prev_pitch, end_millis) " +
                                 "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET jail_name=excluded.jail_name, " +
                                 "prev_world=excluded.prev_world, prev_x=excluded.prev_x, prev_y=excluded.prev_y, prev_z=excluded.prev_z, " +
                                 "prev_yaw=excluded.prev_yaw, prev_pitch=excluded.prev_pitch, end_millis=excluded.end_millis")) {
                statement.setString(1, player.getUniqueId().toString());
                statement.setString(2, jailName);
                statement.setString(3, previous.getWorld().getName());
                statement.setDouble(4, previous.getX());
                statement.setDouble(5, previous.getY());
                statement.setDouble(6, previous.getZ());
                statement.setFloat(7, previous.getYaw());
                statement.setFloat(8, previous.getPitch());
                statement.setLong(9, end);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde emprisonnement", exception);
            }
        });
    }

    public void unjail(UUID uuid) {
        JailedState state = jailed.remove(uuid);
        if (state == null) return;
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && state.previousLocation() != null) {
            player.teleport(state.previousLocation());
            player.sendMessage(TextUtil.parse("<green>Tu as ete libere de prison !"));
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("DELETE FROM b2c_jails_active WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur suppression emprisonnement", exception);
            }
        });
    }

    public boolean isJailed(UUID uuid) {
        return jailed.containsKey(uuid);
    }

    public JailedState getState(UUID uuid) {
        return jailed.get(uuid);
    }

    private void checkExpirations() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, JailedState> entry : jailed.entrySet()) {
            JailedState state = entry.getValue();
            if (state.endMillis() > 0 && now >= state.endMillis()) {
                unjail(entry.getKey());
            }
        }
    }

    public record JailedState(String jailName, Location previousLocation, long endMillis) {
    }
}
