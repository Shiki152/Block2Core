package fr.block2block.core.data;

import java.util.Locale;

/**
 * Grades staff, dans l'ordre hierarchique croissant.
 * Un joueur peut n'avoir aucun grade staff (null cote PlayerData).
 */
public enum StaffRank {
    HELPER,
    STAFF,
    MODERATEUR,
    ADMIN,
    OWNER;

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public boolean isAtLeast(StaffRank other) {
        return this.ordinal() >= other.ordinal();
    }

    public static StaffRank fromKey(String key) {
        if (key == null) return null;
        for (StaffRank rank : values()) {
            if (rank.key().equalsIgnoreCase(key)) {
                return rank;
            }
        }
        return null;
    }
}
