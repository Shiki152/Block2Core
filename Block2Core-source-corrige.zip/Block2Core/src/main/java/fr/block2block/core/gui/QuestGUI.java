package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Quest;
import fr.block2block.core.data.QuestType;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Interface graphique pour /quest : une grille avec une icone par quete (30 quetes fournies
 * par defaut, plus toutes celles creees par le staff via /quest admin create - la liste est
 * lue en direct depuis QuestManager, donc toujours a jour). Chaque icone reflete le statut de
 * la quete pour le joueur qui l'ouvre (en cours / terminee a reclamer / deja reclamee), et un
 * clic sur une quete terminee reclame sa recompense (voir QuestManager#claimReward).
 * <p>
 * Un raccourci en bas ouvre /tag (choix du tag affiche parmi ceux debloques par les quetes).
 * <p>
 * Limite actuelle : 45 quetes maximum affichables (pas de pagination). Largement suffisant
 * pour les 30 quetes par defaut + les ajouts du staff ; a paginer si ce nombre est depasse.
 */
public class QuestGUI implements Listener {

    private static final int SIZE = 54;
    private static final int MAX_QUESTS = 45; // 5 lignes ; la 6e est reservee au raccourci /tag
    private static final int TAG_SHORTCUT_SLOT = 49;

    private final Block2Core plugin;

    public QuestGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        UUID uuid = player.getUniqueId();
        List<Quest> quests = plugin.getQuestManager().getAllQuests().stream()
                .sorted(Comparator.comparingInt(Quest::id))
                .toList();

        Map<Integer, Quest> slotMap = new HashMap<>();
        Inventory inventory = plugin.getServer().createInventory(new QuestHolder(slotMap), SIZE,
                TextUtil.parse("<aqua><bold>Quetes <gray>(" + quests.size() + ")"));

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < SIZE; i++) {
            inventory.setItem(i, filler);
        }

        int slot = 0;
        for (Quest quest : quests) {
            if (slot >= MAX_QUESTS) break;
            inventory.setItem(slot, buildQuestItem(uuid, quest));
            slotMap.put(slot, quest);
            slot++;
        }

        inventory.setItem(TAG_SHORTCUT_SLOT, new ItemBuilder(Material.NAME_TAG)
                .glow(true)
                .name("<light_purple><bold>Choisir mon tag")
                .loreLine("<gray>Affiche un tag debloque devant ton pseudo.")
                .loreLine("<yellow>Clique pour ouvrir /tag !")
                .build());

        player.openInventory(inventory);
    }

    private ItemStack buildQuestItem(UUID uuid, Quest quest) {
        boolean completed = plugin.getQuestManager().isCompleted(uuid, quest.id());
        boolean claimed = plugin.getQuestManager().isClaimed(uuid, quest.id());
        int progress = plugin.getQuestManager().getProgress(uuid, quest.id());
        Material icon = iconFor(quest.type());

        if (claimed) {
            return new ItemBuilder(Material.LIME_STAINED_GLASS_PANE)
                    .name("<dark_green>" + quest.name())
                    .loreLine("<gray>" + quest.description())
                    .loreLine(" ")
                    .loreLine("<green>✔ Recompense recuperee")
                    .build();
        }
        if (completed) {
            ItemBuilder builder = new ItemBuilder(icon)
                    .glow(true)
                    .name("<gold><bold>" + quest.name())
                    .loreLine("<gray>" + quest.description())
                    .loreLine(" ")
                    .loreLine("<green>✅ Terminee !");
            appendRewardLore(builder, quest);
            builder.loreLine(" ").loreLine("<yellow>Clique pour reclamer ta recompense !");
            return builder.build();
        }
        ItemBuilder builder = new ItemBuilder(icon)
                .name("<white>" + quest.name())
                .loreLine("<gray>" + quest.description())
                .loreLine(" ")
                .loreLine("<yellow>Progression : " + progress + "/" + quest.targetAmount());
        appendRewardLore(builder, quest);
        if (quest.type() == QuestType.CUSTOM) {
            builder.loreLine(" ").loreLine("<gray><italic>Validee manuellement par le staff.");
        }
        return builder.build();
    }

    private void appendRewardLore(ItemBuilder builder, Quest quest) {
        builder.loreLine(" ");
        if (quest.rewardCoins() > 0) {
            builder.loreLine("<gray>Recompense : <gold>" + (long) quest.rewardCoins() + " Block2Coins");
        }
        if (quest.rewardTitle() != null && !quest.rewardTitle().isBlank()) {
            builder.loreLine("<gray>Tag debloque : <dark_green><bold>" + quest.rewardTitle());
        }
    }

    private Material iconFor(QuestType type) {
        return switch (type) {
            case BLOCK_BREAK -> Material.IRON_PICKAXE;
            case BLOCK_PLACE -> Material.BRICKS;
            case MOB_KILL -> Material.IRON_SWORD;
            case CUSTOM -> Material.WRITTEN_BOOK;
        };
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof QuestHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !(event.getClickedInventory().getHolder() instanceof QuestHolder)) return;

        Player player = (Player) event.getWhoClicked();

        if (event.getSlot() == TAG_SHORTCUT_SLOT) {
            plugin.getTagGUI().open(player);
            return;
        }

        Quest quest = holder.questAt(event.getSlot());
        if (quest == null) return;

        boolean claimed = plugin.getQuestManager().claimReward(player, quest.id());
        if (claimed) {
            Bukkit.getScheduler().runTask(plugin, () -> open(player));
        }
    }

    public static class QuestHolder implements InventoryHolder {
        private final Map<Integer, Quest> slotMap;

        public QuestHolder(Map<Integer, Quest> slotMap) {
            this.slotMap = slotMap;
        }

        public Quest questAt(int slot) {
            return slotMap.get(slot);
        }

        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
