package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Quest;
import fr.block2block.core.data.QuestDifficulty;
import fr.block2block.core.data.QuestType;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Interface graphique pour /quest (alias /quetes) : un hub avec 3 categories (Faciles /
 * Moyennes / Impossible, 30 quetes fixes chacune - voir QuestManager), puis une grille par
 * categorie. Chaque icone de quete reflete sa cible : l'oeuf de spawn du mob pour une quete
 * MOB_KILL, le bloc lui-meme pour une quete BLOCK_BREAK/BLOCK_PLACE (voir iconFor()).
 */
public class QuestGUI implements Listener {

    private static final int GRID_SIZE = 54;
    private static final int[] QUEST_SLOTS = buildRange(0, 30); // 30 quetes exactement par categorie
    private static final int BACK_SLOT = 45;
    private static final int TAG_SLOT = 49;

    private static final int HUB_SIZE = 27;
    private static final int FACILE_SLOT = 11;
    private static final int MOYENNE_SLOT = 13;
    private static final int IMPOSSIBLE_SLOT = 15;
    private static final int HUB_TAG_SLOT = 22;

    private final Block2Core plugin;

    public QuestGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    private static int[] buildRange(int start, int count) {
        int[] slots = new int[count];
        for (int i = 0; i < count; i++) slots[i] = start + i;
        return slots;
    }

    public void open(Player player) {
        UUID uuid = player.getUniqueId();
        Inventory inventory = plugin.getServer().createInventory(new QuestHubHolder(), HUB_SIZE,
                TextUtil.parse("<aqua><bold>Quetes"));

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < HUB_SIZE; i++) {
            inventory.setItem(i, filler);
        }

        inventory.setItem(FACILE_SLOT, new ItemBuilder(Material.LIME_WOOL)
                .name("<green><bold>Faciles")
                .loreLine("<gray>30 quetes accessibles a tous.")
                .loreLine(" ")
                .loreLine("<yellow>" + progressSummary(uuid, QuestDifficulty.FACILE))
                .loreLine("<yellow>Clique pour ouvrir")
                .build());
        inventory.setItem(MOYENNE_SLOT, new ItemBuilder(Material.ORANGE_WOOL)
                .name("<gold><bold>Moyennes")
                .loreLine("<gray>30 quetes qui demandent un peu plus d'efforts.")
                .loreLine(" ")
                .loreLine("<yellow>" + progressSummary(uuid, QuestDifficulty.MOYENNE))
                .loreLine("<yellow>Clique pour ouvrir")
                .build());
        inventory.setItem(IMPOSSIBLE_SLOT, new ItemBuilder(Material.RED_WOOL)
                .name("<dark_red><bold>Impossibles")
                .loreLine("<gray>30 quetes de tres long terme, pour les plus acharnes.")
                .loreLine(" ")
                .loreLine("<yellow>" + progressSummary(uuid, QuestDifficulty.IMPOSSIBLE))
                .loreLine("<yellow>Clique pour ouvrir")
                .build());
        inventory.setItem(HUB_TAG_SLOT, new ItemBuilder(Material.NAME_TAG)
                .glow(true)
                .name("<light_purple><bold>Choisir mon tag")
                .loreLine("<gray>Affiche un tag debloque devant ton pseudo.")
                .loreLine("<yellow>Clique pour ouvrir /tag")
                .build());

        player.openInventory(inventory);
    }

    private String progressSummary(UUID uuid, QuestDifficulty difficulty) {
        List<Quest> list = plugin.getQuestManager().getQuestsByDifficulty(difficulty);
        long claimed = list.stream().filter(q -> plugin.getQuestManager().isClaimed(uuid, q.id())).count();
        return claimed + "/" + list.size() + " terminees";
    }

    private void openDifficulty(Player player, QuestDifficulty difficulty) {
        UUID uuid = player.getUniqueId();
        List<Quest> quests = plugin.getQuestManager().getQuestsByDifficulty(difficulty).stream()
                .sorted(Comparator.comparingInt(Quest::id))
                .toList();

        Map<Integer, Quest> slotMap = new HashMap<>();
        Inventory inventory = plugin.getServer().createInventory(new QuestGridHolder(difficulty, slotMap), GRID_SIZE,
                TextUtil.parse(hubTitleColor(difficulty) + "<bold>Quetes " + hubLabel(difficulty) + " <gray>(" + quests.size() + ")"));

        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < GRID_SIZE; i++) {
            inventory.setItem(i, filler);
        }

        for (int i = 0; i < quests.size() && i < QUEST_SLOTS.length; i++) {
            Quest quest = quests.get(i);
            inventory.setItem(QUEST_SLOTS[i], buildQuestItem(uuid, quest));
            slotMap.put(QUEST_SLOTS[i], quest);
        }

        inventory.setItem(BACK_SLOT, new ItemBuilder(Material.ARROW).name("<gray>« Retour").build());
        inventory.setItem(TAG_SLOT, new ItemBuilder(Material.NAME_TAG)
                .glow(true)
                .name("<light_purple><bold>Choisir mon tag")
                .loreLine("<yellow>Clique pour ouvrir /tag")
                .build());

        player.openInventory(inventory);
    }

    private String hubLabel(QuestDifficulty difficulty) {
        return switch (difficulty) {
            case FACILE -> "Faciles";
            case MOYENNE -> "Moyennes";
            case IMPOSSIBLE -> "Impossibles";
        };
    }

    private String hubTitleColor(QuestDifficulty difficulty) {
        return switch (difficulty) {
            case FACILE -> "<green>";
            case MOYENNE -> "<gold>";
            case IMPOSSIBLE -> "<dark_red>";
        };
    }

    /** Icone de la quete : l'oeuf de spawn du mob pour MOB_KILL, le bloc cible lui-meme pour BLOCK_BREAK/BLOCK_PLACE. */
    private Material iconFor(Quest quest) {
        if (quest.target() != null) {
            if (quest.type() == QuestType.MOB_KILL) {
                try {
                    return Material.valueOf(quest.target() + "_SPAWN_EGG");
                } catch (IllegalArgumentException ignored) {
                    return Material.IRON_SWORD;
                }
            }
            try {
                return Material.valueOf(quest.target());
            } catch (IllegalArgumentException ignored) {
                // cible non representable telle quelle, on retombe sur l'icone generique ci-dessous
            }
        }
        return quest.type() == QuestType.BLOCK_PLACE ? Material.BRICKS : Material.IRON_PICKAXE;
    }

    private ItemStack buildQuestItem(UUID uuid, Quest quest) {
        boolean completed = plugin.getQuestManager().isCompleted(uuid, quest.id());
        boolean claimed = plugin.getQuestManager().isClaimed(uuid, quest.id());
        int progress = plugin.getQuestManager().getProgress(uuid, quest.id());
        Material icon = iconFor(quest);

        if (claimed) {
            return new ItemBuilder(icon)
                    .name("<dark_green>" + quest.name())
                    .loreLine("<gray>" + quest.description())
                    .loreLine(" ")
                    .loreLine("<green>✔ Recompense recuperee")
                    .build();
        }
        if (completed) {
            ItemBuilder builder = new ItemBuilder(icon)
                    .glow(true)
                    .name("<gold><bold>" + quest.name())
                    .loreLine("<gray>" + quest.description())
                    .loreLine(" ")
                    .loreLine("<green>✅ Terminee !");
            appendRewardLore(builder, quest);
            builder.loreLine(" ").loreLine("<yellow>Clique pour reclamer ta recompense !");
            return builder.build();
        }
        ItemBuilder builder = new ItemBuilder(icon)
                .name("<white>" + quest.name())
                .loreLine("<gray>" + quest.description())
                .loreLine(" ")
                .loreLine("<yellow>Progression : " + progress + "/" + quest.targetAmount());
        appendRewardLore(builder, quest);
        return builder.build();
    }

    private void appendRewardLore(ItemBuilder builder, Quest quest) {
        builder.loreLine(" ");
        if (quest.rewardCoins() > 0) {
            builder.loreLine("<gray>Recompense : <gold>" + (long) quest.rewardCoins() + " Block2Coins");
        }
        if (quest.rewardTitle() != null && !quest.rewardTitle().isBlank()) {
            String color = quest.titleColor() != null ? quest.titleColor() : "<dark_green>";
            builder.loreLine("<gray>Tag debloque : " + color + "<bold>" + quest.rewardTitle());
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof QuestHubHolder) && !(holder instanceof QuestGridHolder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || event.getClickedInventory().getHolder() != holder) return;

        Player player = (Player) event.getWhoClicked();

        if (holder instanceof QuestHubHolder) {
            switch (event.getSlot()) {
                case FACILE_SLOT -> openDifficulty(player, QuestDifficulty.FACILE);
                case MOYENNE_SLOT -> openDifficulty(player, QuestDifficulty.MOYENNE);
                case IMPOSSIBLE_SLOT -> openDifficulty(player, QuestDifficulty.IMPOSSIBLE);
                case HUB_TAG_SLOT -> plugin.getTagGUI().open(player);
                default -> {
                }
            }
            return;
        }

        QuestGridHolder gridHolder = (QuestGridHolder) holder;
        if (event.getSlot() == BACK_SLOT) {
            open(player);
            return;
        }
        if (event.getSlot() == TAG_SLOT) {
            plugin.getTagGUI().open(player);
            return;
        }
        Quest quest = gridHolder.questAt(event.getSlot());
        if (quest == null) return;

        boolean claimed = plugin.getQuestManager().claimReward(player, quest.id());
        if (claimed) {
            Bukkit.getScheduler().runTask(plugin, () -> openDifficulty(player, gridHolder.difficulty()));
        }
    }

    public static class QuestHubHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }

    public static class QuestGridHolder implements InventoryHolder {
        private final QuestDifficulty difficulty;
        private final Map<Integer, Quest> slotMap;

        public QuestGridHolder(QuestDifficulty difficulty, Map<Integer, Quest> slotMap) {
            this.difficulty = difficulty;
            this.slotMap = slotMap;
        }

        public QuestDifficulty difficulty() {
            return difficulty;
        }

        public Quest questAt(int slot) {
            return slotMap.get(slot);
        }

        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
