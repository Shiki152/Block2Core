package fr.block2block.core.commands.economy;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

public class EconomyCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public EconomyCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("bal")) {
            return handleBal(sender, args);
        }
        return handlePay(sender, args);
    }

    private boolean handleBal(CommandSender sender, String[] args) {
        OfflinePlayer target;
        if (args.length > 0) {
            target = Bukkit.getOfflinePlayer(args[0]);
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            sender.sendMessage("Usage : /bal <joueur>");
            return true;
        }
        double balance = plugin.getEconomyManager().getBalance(target.getUniqueId());
        String who = args.length > 0 ? target.getName() : "Ton";
        sender.sendMessage(TextUtil.parse("<gray>" + (args.length > 0 ? "Solde de " + who : "Ton solde") +
                " : <gold>" + String.format("%,.0f", balance) + " Block2Coins"));
        return true;
    }

    private boolean handlePay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /pay <joueur> <montant>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            sender.sendMessage(TextUtil.parse("<red>Tu ne peux pas te payer toi-meme."));
            return true;
        }
        double amount;
        try {
            amount = Double.parseDouble(args[1]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", java.util.Map.of("valeur", args[1])));
            return true;
        }
        if (amount <= 0) {
            sender.sendMessage(TextUtil.parse("<red>Le montant doit etre positif."));
            return true;
        }
        if (!plugin.getEconomyManager().withdraw(player.getUniqueId(), amount)) {
            sender.sendMessage(TextUtil.parse("<red>Solde insuffisant."));
            return true;
        }
        plugin.getEconomyManager().deposit(target.getUniqueId(), amount);
        player.sendMessage(TextUtil.parse("<green>Tu as envoye <gold>" + String.format("%,.0f", amount) + " Block2Coins <green>a " + target.getName()));
        target.sendMessage(TextUtil.parse("<green>Tu as recu <gold>" + String.format("%,.0f", amount) + " Block2Coins <green>de " + player.getName()));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
