package fr.block2block.core.data;

import java.util.UUID;

public record QuestProgress(UUID uuid, int questId, int progress, boolean completed, boolean rewardClaimed) {
}
