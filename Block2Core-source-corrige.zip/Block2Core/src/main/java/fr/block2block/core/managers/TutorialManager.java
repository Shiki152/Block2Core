package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * Gere le tutoriel guide (/tuto) : le joueur doit taper une serie de
 * commandes dans l'ordre, une seule fois dans sa vie sur le serveur.
 * <p>
 * La correspondance identifiant d'etape -> commande reelle attendue est
 * definie ici (le cahier des charges liste les etapes comme du texte libre,
 * ex. "/home set" pour designer l'action de definir une home, alors que la
 * commande reellement implementee est /sethome : c'est cette derniere qui
 * est attendue).
 */
public class TutorialManager {

    private final Block2Core plugin;

    private static final Map<String, String> STEP_COMMAND = new LinkedHashMap<>();
    private static final Map<String, String> STEP_DISPLAY = new LinkedHashMap<>();

    static {
        STEP_COMMAND.put("spawn", "/spawn");
        STEP_COMMAND.put("bal", "/bal");
        STEP_COMMAND.put("homeset", "/sethome");
        STEP_COMMAND.put("claim", "/claim");
        STEP_COMMAND.put("teamcreate", "/team create");
        STEP_COMMAND.put("discord", "/discord");

        STEP_DISPLAY.put("spawn", "/spawn");
        STEP_DISPLAY.put("bal", "/bal");
        STEP_DISPLAY.put("homeset", "/sethome");
        STEP_DISPLAY.put("claim", "eloigne-toi du spawn puis tape /claim");
        STEP_DISPLAY.put("teamcreate", "/team create <nom> <cout>");
        STEP_DISPLAY.put("discord", "/discord");
    }

    public TutorialManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void start(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return;

        if (data.isTutorialCompleted()) {
            player.sendMessage(TextUtil.parse("<yellow>Tu as deja termine le tutoriel !"));
            return;
        }
        data.setTutorialStep(0);
        sendStepInstruction(player, 0);
    }

    private List<String> steps() {
        List<String> configured = plugin.getConfigManager().tutorialSteps();
        return !configured.isEmpty() ? configured : List.copyOf(STEP_COMMAND.keySet());
    }

    private void sendStepInstruction(Player player, int stepIndex) {
        List<String> steps = steps();
        if (stepIndex >= steps.size()) return;
        String stepId = steps.get(stepIndex);
        String display = STEP_DISPLAY.getOrDefault(stepId, "/" + stepId);
        Map<String, String> placeholders = Map.of(
                "commande", display,
                "etape", String.valueOf(stepIndex + 1),
                "total", String.valueOf(steps.size())
        );
        player.sendMessage(TextUtil.parse(plugin.getConfigManager().tutorialStartMessage(), placeholders));
    }

    /** Appele par TutorialListener a chaque commande tapee par un joueur en cours de tutoriel. */
    public void onCommandTyped(Player player, String fullCommandLower) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null || data.isTutorialCompleted() || data.getTutorialStep() < 0) {
            return;
        }
        List<String> steps = steps();
        int currentStep = data.getTutorialStep();
        if (currentStep >= steps.size()) return;

        String stepId = steps.get(currentStep);
        String expected = STEP_COMMAND.getOrDefault(stepId, "/" + stepId).toLowerCase();

        if (matchesCommand(fullCommandLower, expected)) {
            int nextStep = currentStep + 1;
            data.setTutorialStep(nextStep);
            if (nextStep >= steps.size()) {
                complete(player, data);
            } else {
                sendStepInstruction(player, nextStep);
            }
        }
    }

    /**
     * Compare la commande tapee et la commande attendue mot par mot (et non via un simple
     * startsWith sur la chaine brute) : sinon "/claim" matchait aussi "/claims list", qui est
     * une commande differente.
     */
    private boolean matchesCommand(String typedLower, String expectedLower) {
        String[] typedParts = typedLower.trim().split("\\s+");
        String[] expectedParts = expectedLower.trim().split("\\s+");
        if (typedParts.length < expectedParts.length) return false;
        for (int i = 0; i < expectedParts.length; i++) {
            if (!typedParts[i].equals(expectedParts[i])) return false;
        }
        return true;
    }

    private void complete(Player player, PlayerData data) {
        data.setTutorialCompleted(true);
        data.setTutorialStep(-1);
        int reward = plugin.getConfigManager().tutorialRewardCoins();
        plugin.getEconomyManager().deposit(player.getUniqueId(), reward);

        player.sendMessage(TextUtil.parse(plugin.getConfigManager().tutorialCompletionMessage(),
                Map.of("amount", String.valueOf(reward))));

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("UPDATE b2c_players SET tutorial_completed = 1 WHERE uuid = ?")) {
                statement.setString(1, player.getUniqueId().toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde fin de tutoriel", exception);
            }
        });
    }
}
