package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.logging.Level;

/**
 * Purge periodiquement :
 * - les caches en memoire qui accumulent des entrees au fil du temps
 *   (positions /back, cibles /reply, demandes /tpa expirees, cooldowns /rtp,
 *   invitations d'equipe expirees, compteurs de slowchat) ;
 * - les vieilles lignes des tables de logs (b2c_block_logs, b2c_action_logs),
 *   qui grossiraient sinon indefiniment sur un serveur actif.
 * <p>
 * Sans ce nettoyage, ces structures grandiraient sans jamais retrecir sur la
 * duree de vie du serveur (des mois, des annees), ce qui finit par degrader
 * les performances et gonfler le fichier SQLite.
 */
public class CacheCleanupManager {

    private final Block2Core plugin;
    private BukkitTask task;

    public CacheCleanupManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void start() {
        int intervalMinutes = plugin.getConfigManager().cacheCleanupIntervalMinutes();
        long periodTicks = 20L * 60 * intervalMinutes;
        // Execution asynchrone : la purge SQL et le nettoyage des ConcurrentHashMap n'ont pas
        // besoin du thread principal.
        task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::runCleanup, periodTicks, periodTicks);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void runCleanup() {
        try {
            plugin.getSocialManager().cleanupStaleEntries();
            plugin.getChatModerationManager().cleanupStaleEntries();
            plugin.getTeamManager().cleanupStaleInvites();
            purgeOldLogs();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur pendant le nettoyage periodique des caches", exception);
        }
    }

    private void purgeOldLogs() {
        long cutoff = System.currentTimeMillis() - plugin.getConfigManager().logRetentionDays() * 86_400_000L;
        try (var connection = plugin.getDatabaseManager().getConnection()) {
            try (var statement = connection.prepareStatement("DELETE FROM b2c_block_logs WHERE timestamp < ?")) {
                statement.setLong(1, cutoff);
                int deleted = statement.executeUpdate();
                if (deleted > 0) {
                    plugin.getLogger().info("Nettoyage : " + deleted + " anciennes entrees b2c_block_logs supprimees.");
                }
            }
            try (var statement = connection.prepareStatement("DELETE FROM b2c_action_logs WHERE timestamp < ?")) {
                statement.setLong(1, cutoff);
                int deleted = statement.executeUpdate();
                if (deleted > 0) {
                    plugin.getLogger().info("Nettoyage : " + deleted + " anciennes entrees b2c_action_logs supprimees.");
                }
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur purge des vieux logs", exception);
        }
    }
}
