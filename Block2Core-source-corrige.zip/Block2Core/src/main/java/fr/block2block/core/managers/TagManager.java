package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.TagDefinition;
import fr.block2block.core.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Registre central de tous les tags (titres affiches dans le chat, DARK_GREEN BOLD par
 * defaut), qu'ils proviennent d'une recompense de quete ou d'un tag cree par le staff pour un
 * evenement (voir /tagadmin). Gere trois choses distinctes :
 * <ul>
 *     <li>les DEFINITIONS (nom, couleur, description), stockees dans b2c_tag_definitions ;</li>
 *     <li>les DEBLOCAGES par joueur (qui a le droit d'utiliser quel tag), dans
 *     b2c_titles_unlocked - commun aux tags de quete et aux tags donnes par le staff ;</li>
 *     <li>le tag ACTUELLEMENT AFFICHE par chaque joueur (PlayerData#getTitle(), colonne
 *     b2c_players.title).</li>
 * </ul>
 * QuestManager delegue ici l'attribution du tag associe a une quete (voir
 * QuestManager#grantReward) : ce manager ne connait rien des quetes elles-memes.
 */
public class TagManager {

    private final Block2Core plugin;
    private final Map<String, TagDefinition> definitions = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> unlockedCache = new ConcurrentHashMap<>();

    public TagManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // DEFINITIONS
    // ---------------------------------------------------------------

    public void loadAllDefinitions() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_tag_definitions");
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    TagDefinition def = new TagDefinition(rs.getString("name"), rs.getString("color"), rs.getString("description"));
                    definitions.put(key(def.name()), def);
                }
                plugin.getLogger().info("Tags charges : " + definitions.size());
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement des tags", exception);
            }
        });
    }

    private String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    /** Cree ou met a jour un tag (utilise par /tagadmin create : ecrase couleur/description si le tag existe deja). */
    public void defineTag(String name, String color, String description, Runnable onDone) {
        definitions.put(key(name), new TagDefinition(name, color, description));
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_tag_definitions (name, color, description) VALUES (?,?,?) " +
                                 "ON CONFLICT(name) DO UPDATE SET color = excluded.color, description = excluded.description")) {
                statement.setString(1, name);
                statement.setString(2, color);
                statement.setString(3, description);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde du tag " + name, exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    /**
     * Enregistre un tag SEULEMENT s'il n'existe pas deja (n'ecrase jamais une definition
     * existante). Utilise par la seed des quetes par defaut : si un admin a personnalise la
     * couleur/description d'un tag de quete via /tagadmin, un redemarrage ne doit jamais
     * revenir en arriere dessus.
     */
    public void seedTagIfMissing(String name, String color, String description) {
        if (definitions.containsKey(key(name))) return;
        definitions.put(key(name), new TagDefinition(name, color, description));
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT OR IGNORE INTO b2c_tag_definitions (name, color, description) VALUES (?,?,?)")) {
                statement.setString(1, name);
                statement.setString(2, color);
                statement.setString(3, description);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur seed du tag " + name, exception);
            }
        });
    }

    public boolean deleteTag(String name) {
        TagDefinition removed = definitions.remove(key(name));
        if (removed == null) return false;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("DELETE FROM b2c_tag_definitions WHERE name = ?")) {
                statement.setString(1, name);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur suppression du tag " + name, exception);
            }
        });
        return true;
    }

    public TagDefinition getTag(String name) {
        if (name == null) return null;
        return definitions.get(key(name));
    }

    public List<TagDefinition> getAllTags() {
        return new ArrayList<>(definitions.values());
    }

    public String getColor(String tagName) {
        TagDefinition def = getTag(tagName);
        return def != null ? def.color() : plugin.getConfigManager().titleColor();
    }

    /** Formatte un tag avec sa propre couleur, pret a afficher dans le chat ou une GUI. */
    public Component formatTag(String tagName) {
        if (tagName == null || tagName.isBlank()) return Component.empty();
        return TextUtil.parse(getColor(tagName) + tagName);
    }

    // ---------------------------------------------------------------
    // DEBLOCAGES PAR JOUEUR
    // ---------------------------------------------------------------

    public void loadPlayer(UUID uuid, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Set<String> titles = new HashSet<>();
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT title FROM b2c_titles_unlocked WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) titles.add(rs.getString("title"));
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement des tags debloques", exception);
            }
            unlockedCache.put(uuid, titles);
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    public void unloadPlayer(UUID uuid) {
        unlockedCache.remove(uuid);
    }

    public Set<String> getUnlockedTags(UUID uuid) {
        return unlockedCache.getOrDefault(uuid, Set.of());
    }

    public boolean hasTag(UUID uuid, String tagName) {
        if (tagName == null) return false;
        for (String unlocked : getUnlockedTags(uuid)) {
            if (unlocked.equalsIgnoreCase(tagName)) return true;
        }
        return false;
    }

    /** Debloque un tag pour un joueur en ligne (recompense de quete, ou /tagadmin give). */
    public void giveTag(Player player, String tagName, Runnable onDone) {
        unlockedCache.computeIfAbsent(player.getUniqueId(), k -> ConcurrentHashMap.newKeySet()).add(tagName);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("INSERT OR IGNORE INTO b2c_titles_unlocked (uuid, title) VALUES (?, ?)")) {
                statement.setString(1, player.getUniqueId().toString());
                statement.setString(2, tagName);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur attribution du tag " + tagName, exception);
            }
            if (onDone != null) Bukkit.getScheduler().runTask(plugin, onDone);
        });
    }

    /** Retire un tag debloque a un joueur en ligne (/tagadmin remove). Le retire aussi de son affichage actif si c'etait celui-la. */
    public boolean removeTag(Player target, String tagName) {
        Set<String> unlocked = unlockedCache.get(target.getUniqueId());
        boolean had = unlocked != null && unlocked.removeIf(t -> t.equalsIgnoreCase(tagName));
        if (!had) return false;

        PlayerData data = plugin.getPlayerData(target.getUniqueId());
        if (data != null && tagName.equalsIgnoreCase(data.getTitle())) {
            data.setTitle(null);
            persistActiveTitle(target.getUniqueId(), null);
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "DELETE FROM b2c_titles_unlocked WHERE uuid = ? AND title = ? COLLATE NOCASE")) {
                statement.setString(1, target.getUniqueId().toString());
                statement.setString(2, tagName);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur retrait du tag " + tagName, exception);
            }
        });
        return true;
    }

    // ---------------------------------------------------------------
    // TAG ACTUELLEMENT AFFICHE
    // ---------------------------------------------------------------

    /** Change le tag affiche du joueur, s'il est bien debloque (ou null/"aucun" pour ne plus rien afficher). */
    public boolean setActiveTitle(Player player, String title) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return false;
        if (title == null || title.equalsIgnoreCase("none") || title.equalsIgnoreCase("aucun")) {
            data.setTitle(null);
            persistActiveTitle(player.getUniqueId(), null);
            return true;
        }
        if (!hasTag(player.getUniqueId(), title)) {
            return false;
        }
        data.setTitle(title);
        persistActiveTitle(player.getUniqueId(), title);
        return true;
    }

    private void persistActiveTitle(UUID uuid, String title) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("UPDATE b2c_players SET title = ? WHERE uuid = ?")) {
                statement.setString(1, title);
                statement.setString(2, uuid.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde titre actif", exception);
            }
        });
    }
}
