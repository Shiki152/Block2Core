package fr.block2block.core.placeholder;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.PlayerTeam;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Expansion PlaceholderAPI exposant les donnees Block2Core :
 * %block2core_rank%, %block2core_rank_display%, %block2core_staffrank%,
 * %block2core_balance%, %block2core_playtime%, %block2core_playtime_formatted%,
 * %block2core_title%, %block2core_claims_used%, %block2core_claims_max%,
 * %block2core_team%
 */
public class Block2CorePlaceholders extends PlaceholderExpansion {

    private final Block2Core plugin;

    public Block2CorePlaceholders(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "block2core";
    }

    @Override
    public @NotNull String getAuthor() {
        return "Block2BlockFr";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onPlaceholderRequest(@Nullable org.bukkit.entity.Player player, @NotNull String params) {
        if (player == null) return "";
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return "";

        return switch (params.toLowerCase()) {
            case "rank" -> data.getGrade().key();
            case "rank_display" -> plugin.getConfigManager().gradeDisplayName(data.getGrade());
            case "staffrank" -> data.getStaffRank() != null ? data.getStaffRank().key() : "";
            case "staffrank_display" -> data.getStaffRank() != null ? plugin.getConfigManager().staffDisplayName(data.getStaffRank()) : "";
            case "balance" -> String.format("%,.0f", data.getBalance());
            case "playtime" -> String.valueOf(data.getPlaytimeSeconds());
            case "playtime_formatted" -> fr.block2block.core.util.TimeUtil.formatHoursMinutes(data.getPlaytimeSeconds());
            case "title" -> data.getTitle() != null ? data.getTitle() : "";
            case "claims_used" -> String.valueOf(plugin.getClaimManager().countOwnedByPlayer(player.getUniqueId()));
            case "claims_max" -> String.valueOf(plugin.getConfigManager().claimLimit(data.getGrade()));
            case "team" -> {
                if (data.getTeamId() == null) yield "";
                PlayerTeam team = plugin.getTeamManager().getTeam(data.getTeamId());
                yield team != null ? team.getName() : "";
            }
            default -> null;
        };
    }
}
