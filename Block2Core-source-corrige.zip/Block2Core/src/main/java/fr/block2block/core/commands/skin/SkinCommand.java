package fr.block2block.core.commands.skin;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * /skin set <pseudo> : recupere la texture de skin d'un pseudo via l'API
 * Mojang (PlayerProfile#update(), disponible nativement sur Paper) et
 * l'applique au joueur.
 * <p>
 * Limitation connue : le joueur lui-meme peut avoir besoin de se reconnecter
 * pour voir son propre nouveau skin en 3e personne / dans certains menus ;
 * c'est une limitation de l'API vanilla (sans NMS ni ProtocolLib) commune
 * a la plupart des plugins de skin legers.
 */
public class SkinCommand implements CommandExecutor {

    private final Block2Core plugin;

    public SkinCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 2 || !args[0].equalsIgnoreCase("set")) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /skin set <pseudo>"));
            return true;
        }
        if (plugin.getBedrockSupport().isBedrockPlayer(player.getUniqueId())) {
            player.sendMessage(TextUtil.parse("<red>Le changement de skin n'est pas disponible sur Bedrock."));
            return true;
        }
        String targetName = args[1];
        player.sendMessage(TextUtil.parse("<gray>Recuperation du skin de " + targetName + "..."));

        var profile = Bukkit.createProfile(UUID.randomUUID(), targetName);
        profile.update().thenAccept(updated -> Bukkit.getScheduler().runTask(plugin, () -> applySkin(player, updated, targetName)));
        return true;
    }

    private void applySkin(Player player, com.destroystokyo.paper.profile.PlayerProfile fetchedProfile, String targetName) {
        var textures = fetchedProfile.getTextures();
        if (textures.getSkin() == null) {
            player.sendMessage(TextUtil.parse("<red>Impossible de recuperer le skin de " + targetName + " (pseudo invalide ?)."));
            return;
        }
        var ownProfile = player.getPlayerProfile();
        ownProfile.setTextures(textures);
        player.setPlayerProfile(ownProfile);

        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.equals(player)) {
                viewer.hidePlayer(plugin, player);
                viewer.showPlayer(plugin, player);
            }
        }
        player.sendMessage(TextUtil.parse("<green>Skin change ! <gray>(reconnecte-toi si tu ne le vois pas sur toi-meme)"));
    }
}
