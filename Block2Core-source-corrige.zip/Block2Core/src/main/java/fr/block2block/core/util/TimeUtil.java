package fr.block2block.core.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utilitaires de duree : parsing de chaines type "10m", "2h", "1d12h30m"
 * et formatage de secondes en texte lisible ("1j 2h 30m").
 */
public final class TimeUtil {

    private static final Pattern TOKEN = Pattern.compile("(?i)(\\d+)\\s*(s|sec|secondes?|m|min|minutes?|h|heures?|d|j|jours?|w|sem|semaines?)");

    private TimeUtil() {
    }

    /**
     * Parse une duree humaine en secondes. Retourne -1 si la chaine
     * correspond a une duree permanente ("perm", "permanent", "0", "-1").
     * Retourne null (via exception) si le format est invalide.
     */
    public static long parseSeconds(String input) {
        if (input == null) {
            throw new IllegalArgumentException("Duree vide");
        }
        String trimmed = input.trim().toLowerCase();
        if (trimmed.equals("perm") || trimmed.equals("permanent") || trimmed.equals("-1")) {
            return -1L;
        }
        Matcher matcher = TOKEN.matcher(trimmed);
        long totalSeconds = 0;
        boolean found = false;
        while (matcher.find()) {
            found = true;
            long value = Long.parseLong(matcher.group(1));
            String unit = matcher.group(2).toLowerCase();
            if (unit.startsWith("s")) {
                totalSeconds += value;
            } else if (unit.startsWith("m")) {
                totalSeconds += value * 60L;
            } else if (unit.startsWith("h")) {
                totalSeconds += value * 3600L;
            } else if (unit.startsWith("d") || unit.startsWith("j")) {
                totalSeconds += value * 86400L;
            } else if (unit.startsWith("w") || unit.startsWith("sem")) {
                totalSeconds += value * 604800L;
            }
        }
        if (!found) {
            throw new IllegalArgumentException("Format de duree invalide : " + input);
        }
        return totalSeconds;
    }

    /** Formate un nombre de secondes en texte lisible court : "1j 2h 30m 5s" */
    public static String formatShort(long totalSeconds) {
        if (totalSeconds < 0) {
            return "permanent";
        }
        long days = totalSeconds / 86400;
        long hours = (totalSeconds % 86400) / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;

        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("j ");
        if (hours > 0) sb.append(hours).append("h ");
        if (minutes > 0) sb.append(minutes).append("m ");
        if (seconds > 0 || sb.isEmpty()) sb.append(seconds).append("s");
        return sb.toString().trim();
    }

    /** Formate en heures/minutes uniquement, utile pour le playtime (ex: "12h 45m"). */
    public static String formatHoursMinutes(long totalSeconds) {
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        return hours + "h " + minutes + "m";
    }

    public static String formatEpochRemaining(long endEpochMillis) {
        long remaining = (endEpochMillis - System.currentTimeMillis()) / 1000L;
        if (remaining <= 0) {
            return "expire";
        }
        return formatShort(remaining);
    }
}
