package fr.block2block.core.data;

import java.util.UUID;

/**
 * Sanction appliquee a un joueur (ban, mute, warn...) et/ou a une IP.
 *
 * @param endMillis -1 si permanent
 */
public record Punishment(long id, UUID targetUuid, String targetName, String ip, PunishmentType type,
                          String reason, UUID staffUuid, String staffName,
                          long startMillis, long endMillis, boolean active) {

    public boolean isPermanent() {
        return endMillis < 0;
    }

    public boolean isExpired() {
        return !isPermanent() && System.currentTimeMillis() >= endMillis;
    }
}
