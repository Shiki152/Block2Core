package fr.block2block.core.commands.economy;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.SellPrices;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/**
 * /sell hand : vend l'objet actuellement en main.
 * /sell all : vend tout ce qui est vendable dans l'inventaire (voir SellPrices).
 * Les objets sans prix defini (outils, blocs de deco, objets de boutique/quete...) ne sont
 * jamais vendables, pour eviter toute boucle d'arbitrage avec /shop.
 */
public class SellCommand implements CommandExecutor {

    private final Block2Core plugin;

    public SellCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1 || (!args[0].equalsIgnoreCase("hand") && !args[0].equalsIgnoreCase("all"))) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /sell hand <gray>(objet en main) <yellow>ou /sell all <gray>(tout l'inventaire)"));
            return true;
        }

        if (args[0].equalsIgnoreCase("hand")) {
            sellHand(player);
        } else {
            sellAll(player);
        }
        return true;
    }

    private void sellHand(Player player) {
        PlayerInventory inventory = player.getInventory();
        ItemStack item = inventory.getItemInMainHand();
        if (item == null || item.getType() == Material.AIR) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as rien en main."));
            return;
        }
        Double unitPrice = SellPrices.priceOf(item.getType());
        if (unitPrice == null) {
            player.sendMessage(TextUtil.parse("<red>Cet objet ne peut pas etre vendu."));
            return;
        }
        int amount = item.getAmount();
        double total = unitPrice * amount;

        inventory.setItemInMainHand(null);
        plugin.getEconomyManager().deposit(player.getUniqueId(), total);
        player.sendMessage(TextUtil.parse("<green>Vendu : <white>" + amount + "x " + niceName(item.getType()) +
                " <green>pour <gold>" + formatMoney(total) + " Block2Coins"));
    }

    private void sellAll(Player player) {
        PlayerInventory inventory = player.getInventory();
        double total = 0;
        int itemsSold = 0;

        ItemStack[] contents = inventory.getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType() == Material.AIR) continue;
            Double unitPrice = SellPrices.priceOf(item.getType());
            if (unitPrice == null) continue;

            total += unitPrice * item.getAmount();
            itemsSold += item.getAmount();
            contents[i] = null;
        }

        if (itemsSold == 0) {
            player.sendMessage(TextUtil.parse("<red>Tu n'as rien de vendable dans ton inventaire."));
            return;
        }

        inventory.setStorageContents(contents);
        plugin.getEconomyManager().deposit(player.getUniqueId(), total);
        player.sendMessage(TextUtil.parse("<green>Vendu : <white>" + itemsSold + " objet(s) <green>pour <gold>" +
                formatMoney(total) + " Block2Coins"));
    }

    private String formatMoney(double amount) {
        return String.format("%,.0f", amount);
    }

    private String niceName(Material material) {
        String raw = material.name().toLowerCase().replace('_', ' ');
        return Character.toUpperCase(raw.charAt(0)) + raw.substring(1);
    }
}
