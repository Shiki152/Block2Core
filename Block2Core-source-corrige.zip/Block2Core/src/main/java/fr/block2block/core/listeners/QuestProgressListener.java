package fr.block2block.core.listeners;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.QuestType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;

/**
 * Alimente la progression des quetes (BLOCK_BREAK, BLOCK_PLACE, MOB_KILL).
 * ignoreCancelled = true : si ProtectionListener a deja annule l'evenement
 * (claim protege), aucune progression n'est comptee.
 */
public class QuestProgressListener implements Listener {

    private final Block2Core plugin;

    public QuestProgressListener(Block2Core plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        plugin.getQuestManager().progress(event.getPlayer(), QuestType.BLOCK_BREAK, event.getBlock().getType().name(), 1);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        plugin.getQuestManager().progress(event.getPlayer(), QuestType.BLOCK_PLACE, event.getBlock().getType().name(), 1);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMobKill(EntityDeathEvent event) {
        if (event.getEntity().getKiller() instanceof Player killer) {
            plugin.getQuestManager().progress(killer, QuestType.MOB_KILL, event.getEntityType().name(), 1);
        }
    }
}
