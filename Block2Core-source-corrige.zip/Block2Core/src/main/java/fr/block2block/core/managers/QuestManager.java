package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.Quest;
import fr.block2block.core.data.QuestType;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere les quetes creees par le staff (ou celles fournies par defaut), la progression des
 * joueurs, la reclamation des recompenses et les tags (titres de quete) debloques, affiches
 * dans le chat en DARK_GREEN BOLD.
 * <p>
 * Une quete terminee (progress >= targetAmount) ne verse PAS automatiquement sa recompense :
 * le joueur doit la reclamer (voir claimReward(), utilise par gui/QuestGUI) - c'est le sens
 * du champ "reward_claimed" deja present dans le schema b2c_quest_progress depuis le debut,
 * mais qui n'etait jusqu'ici jamais lu ni ecrit.
 */
public class QuestManager {

    private final Block2Core plugin;

    private final Map<Integer, Quest> quests = new ConcurrentHashMap<>();
    private final Map<UUID, Map<Integer, Integer>> progressCache = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Integer>> completedCache = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Integer>> claimedCache = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> unlockedTitlesCache = new ConcurrentHashMap<>();

    /**
     * 30 quetes fournies par defaut, inserees automatiquement au premier demarrage si la
     * table b2c_quests est vide (voir seedDefaultQuestsIfEmpty()). Le staff peut ensuite en
     * ajouter/modifier/supprimer librement : ceci n'est qu'un point de depart.
     */
    private static final List<Quest> DEFAULT_QUESTS = List.of(
            // --- Minage (BLOCK_BREAK) ---
            new Quest(-1, "Premiers pas de mineur", "Casse 50 blocs de pierre.", QuestType.BLOCK_BREAK, "STONE", 50, 100, null),
            new Quest(-1, "Bucheron debutant", "Abats 100 rondins de chene.", QuestType.BLOCK_BREAK, "OAK_LOG", 100, 150, null),
            new Quest(-1, "Chercheur de charbon", "Recolte 64 minerais de charbon.", QuestType.BLOCK_BREAK, "COAL_ORE", 64, 200, null),
            new Quest(-1, "Ruee vers le fer", "Recolte 64 minerais de fer.", QuestType.BLOCK_BREAK, "IRON_ORE", 64, 400, null),
            new Quest(-1, "Eclat d'or", "Recolte 32 minerais d'or.", QuestType.BLOCK_BREAK, "GOLD_ORE", 32, 600, null),
            new Quest(-1, "Chasseur de diamants", "Recolte 16 minerais de diamant.", QuestType.BLOCK_BREAK, "DIAMOND_ORE", 16, 1500, "Diamantaire"),
            new Quest(-1, "Sable et desert", "Casse 128 blocs de sable.", QuestType.BLOCK_BREAK, "SAND", 128, 150, null),
            new Quest(-1, "Le grand mineur", "Casse 500 blocs de pierre au total.", QuestType.BLOCK_BREAK, "STONE", 500, 2000, "Taupe legendaire"),

            // --- Construction (BLOCK_PLACE) ---
            new Quest(-1, "Premier batisseur", "Pose 100 blocs de pierre taillee.", QuestType.BLOCK_PLACE, "COBBLESTONE", 100, 100, null),
            new Quest(-1, "Decorateur", "Pose 50 torches.", QuestType.BLOCK_PLACE, "TORCH", 50, 100, null),
            new Quest(-1, "Architecte en herbe", "Pose 200 planches de chene.", QuestType.BLOCK_PLACE, "OAK_PLANKS", 200, 300, null),
            new Quest(-1, "Macon", "Pose 256 briques de pierre.", QuestType.BLOCK_PLACE, "STONE_BRICKS", 256, 500, null),
            new Quest(-1, "Urbaniste hors pair", "Pose 1000 blocs, n'importe lesquels.", QuestType.BLOCK_PLACE, null, 1000, 1200, "Batisseur"),
            new Quest(-1, "Le grand mur", "Pose 500 blocs de pierre taillee.", QuestType.BLOCK_PLACE, "COBBLESTONE", 500, 400, null),

            // --- Combat (MOB_KILL) ---
            new Quest(-1, "Exterminateur de zombies", "Elimine 30 zombies.", QuestType.MOB_KILL, "ZOMBIE", 30, 200, null),
            new Quest(-1, "Chasseur de squelettes", "Elimine 30 squelettes.", QuestType.MOB_KILL, "SKELETON", 30, 200, null),
            new Quest(-1, "Araignees en pagaille", "Elimine 20 araignees.", QuestType.MOB_KILL, "SPIDER", 20, 150, null),
            new Quest(-1, "Fin des creepers", "Elimine 15 creepers.", QuestType.MOB_KILL, "CREEPER", 15, 300, null),
            new Quest(-1, "Traqueur d'enderman", "Elimine 10 endermen.", QuestType.MOB_KILL, "ENDERMAN", 10, 500, null),
            new Quest(-1, "Chasseur des profondeurs", "Elimine 20 noyes.", QuestType.MOB_KILL, "DROWNED", 20, 300, null),
            new Quest(-1, "Le fleau des morts-vivants", "Elimine 100 zombies au total.", QuestType.MOB_KILL, "ZOMBIE", 100, 1000, "Fleau des morts"),
            new Quest(-1, "Sang-froid", "Elimine 20 sorcieres.", QuestType.MOB_KILL, "WITCH", 20, 800, null),
            new Quest(-1, "Legende du combat", "Elimine 200 monstres, n'importe lesquels.", QuestType.MOB_KILL, null, 200, 2000, "Legende du combat"),
            new Quest(-1, "Piegeur de blaze", "Elimine 10 blazes dans le Nether.", QuestType.MOB_KILL, "BLAZE", 10, 700, null),

            // --- Speciales (CUSTOM, validees manuellement par le staff via /quest admin complete) ---
            new Quest(-1, "Bienvenue sur Block2BlockFr", "Termine le tutoriel de bienvenue.", QuestType.CUSTOM, null, 1, 100, null),
            new Quest(-1, "Ambassadeur Discord", "Rejoins le serveur Discord officiel.", QuestType.CUSTOM, null, 1, 300, "Ambassadeur"),
            new Quest(-1, "Createur inspire", "Soumets une construction remarquable au staff.", QuestType.CUSTOM, null, 1, 1000, "Artiste"),
            new Quest(-1, "Ame genereuse", "Aide un nouveau joueur (valide par le staff).", QuestType.CUSTOM, null, 1, 400, null),
            new Quest(-1, "Voteur fidele", "Soutiens le serveur a plusieurs reprises.", QuestType.CUSTOM, null, 1, 500, null),
            new Quest(-1, "Legende du serveur", "Accomplissement exceptionnel reconnu par le staff.", QuestType.CUSTOM, null, 1, 5000, "Legende")
    );

    public QuestManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    /**
     * Insere les 30 quetes par defaut si la table b2c_quests est vide (premier demarrage
     * uniquement). Appelee de facon synchrone au demarrage, avant loadAllQuests() : c'est
     * le meme genre d'appel bloquant ponctuel que la creation des tables dans
     * DatabaseManager#connect(), acceptable car il n'a lieu qu'une seule fois par serveur.
     */
    public void seedDefaultQuestsIfEmpty() {
        try (var connection = plugin.getDatabaseManager().getConnection();
             var countStatement = connection.prepareStatement("SELECT COUNT(*) AS total FROM b2c_quests");
             var rs = countStatement.executeQuery()) {
            if (rs.next() && rs.getInt("total") > 0) {
                return;
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur verification des quetes existantes", exception);
            return;
        }

        plugin.getLogger().info("Aucune quete en base : insertion des " + DEFAULT_QUESTS.size() + " quetes par defaut...");
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "INSERT INTO b2c_quests (name, description, type, target, target_amount, reward_coins, reward_title) VALUES (?,?,?,?,?,?,?)")) {
            for (Quest quest : DEFAULT_QUESTS) {
                statement.setString(1, quest.name());
                statement.setString(2, quest.description());
                statement.setString(3, quest.type().name());
                statement.setString(4, quest.target());
                statement.setInt(5, quest.targetAmount());
                statement.setDouble(6, quest.rewardCoins());
                statement.setString(7, quest.rewardTitle());
                statement.addBatch();
            }
            statement.executeBatch();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur insertion des quetes par defaut", exception);
        }
    }

    public void loadAllQuests() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_quests");
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    Quest quest = new Quest(
                            rs.getInt("id"), rs.getString("name"), rs.getString("description"),
                            QuestType.valueOf(rs.getString("type")), rs.getString("target"),
                            rs.getInt("target_amount"), rs.getDouble("reward_coins"), rs.getString("reward_title"));
                    quests.put(quest.id(), quest);
                }
                plugin.getLogger().info("Quetes chargees : " + quests.size());
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement quetes", exception);
            }
        });
    }

    public List<Quest> getAllQuests() {
        return new ArrayList<>(quests.values());
    }

    public Quest getQuest(int id) {
        return quests.get(id);
    }

    public void createQuest(Quest quest, Consumer<Integer> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int generatedId = -1;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_quests (name, description, type, target, target_amount, reward_coins, reward_title) VALUES (?,?,?,?,?,?,?)",
                         java.sql.Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, quest.name());
                statement.setString(2, quest.description());
                statement.setString(3, quest.type().name());
                statement.setString(4, quest.target());
                statement.setInt(5, quest.targetAmount());
                statement.setDouble(6, quest.rewardCoins());
                statement.setString(7, quest.rewardTitle());
                statement.executeUpdate();
                try (var keys = statement.getGeneratedKeys()) {
                    if (keys.next()) {
                        generatedId = keys.getInt(1);
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur creation quete", exception);
            }
            if (generatedId > 0) {
                // La quete nouvellement creee est immediatement ajoutee au cache en memoire :
                // elle apparait donc tout de suite dans /quest (interface) pour tous les
                // joueurs, sans avoir besoin de redemarrer le serveur.
                Quest saved = new Quest(generatedId, quest.name(), quest.description(), quest.type(),
                        quest.target(), quest.targetAmount(), quest.rewardCoins(), quest.rewardTitle());
                quests.put(generatedId, saved);
            }
            int finalId = generatedId;
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(finalId));
        });
    }

    /** Charge la progression + quetes reclamees + titres debloques d'un joueur (a appeler au join). */
    public void loadPlayer(UUID uuid, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Map<Integer, Integer> progress = new HashMap<>();
            Set<Integer> completed = new HashSet<>();
            Set<Integer> claimed = new HashSet<>();
            Set<String> titles = new HashSet<>();
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                try (var statement = connection.prepareStatement(
                        "SELECT quest_id, progress, completed, reward_claimed FROM b2c_quest_progress WHERE uuid = ?")) {
                    statement.setString(1, uuid.toString());
                    try (var rs = statement.executeQuery()) {
                        while (rs.next()) {
                            progress.put(rs.getInt("quest_id"), rs.getInt("progress"));
                            if (rs.getBoolean("completed")) {
                                completed.add(rs.getInt("quest_id"));
                            }
                            if (rs.getBoolean("reward_claimed")) {
                                claimed.add(rs.getInt("quest_id"));
                            }
                        }
                    }
                }
                try (var statement = connection.prepareStatement("SELECT title FROM b2c_titles_unlocked WHERE uuid = ?")) {
                    statement.setString(1, uuid.toString());
                    try (var rs = statement.executeQuery()) {
                        while (rs.next()) {
                            titles.add(rs.getString("title"));
                        }
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement progression quetes", exception);
            }
            progressCache.put(uuid, progress);
            completedCache.put(uuid, completed);
            claimedCache.put(uuid, claimed);
            unlockedTitlesCache.put(uuid, titles);
            if (onDone != null) {
                Bukkit.getScheduler().runTask(plugin, onDone);
            }
        });
    }

    public void unloadPlayer(UUID uuid) {
        progressCache.remove(uuid);
        completedCache.remove(uuid);
        claimedCache.remove(uuid);
        unlockedTitlesCache.remove(uuid);
    }

    public Set<String> getUnlockedTitles(UUID uuid) {
        return unlockedTitlesCache.getOrDefault(uuid, Set.of());
    }

    public int getProgress(UUID uuid, int questId) {
        return progressCache.getOrDefault(uuid, Map.of()).getOrDefault(questId, 0);
    }

    public boolean isCompleted(UUID uuid, int questId) {
        return completedCache.getOrDefault(uuid, Set.of()).contains(questId);
    }

    public boolean isClaimed(UUID uuid, int questId) {
        return claimedCache.getOrDefault(uuid, Set.of()).contains(questId);
    }

    // ---------------------------------------------------------------
    // PROGRESSION (appele depuis QuestProgressListener)
    // ---------------------------------------------------------------

    public void progress(Player player, QuestType type, String target, int amount) {
        UUID uuid = player.getUniqueId();
        for (Quest quest : quests.values()) {
            if (quest.type() != type) continue;
            if (quest.target() != null && target != null && !quest.target().equalsIgnoreCase(target)) continue;
            if (isCompleted(uuid, quest.id())) continue;

            Map<Integer, Integer> playerProgress = progressCache.computeIfAbsent(uuid, k -> new HashMap<>());
            int newProgress = playerProgress.getOrDefault(quest.id(), 0) + amount;
            playerProgress.put(quest.id(), newProgress);

            boolean justCompleted = newProgress >= quest.targetAmount();
            if (justCompleted) {
                completedCache.computeIfAbsent(uuid, k -> new HashSet<>()).add(quest.id());
                player.sendMessage(TextUtil.parse("<gold><bold>QUETE TERMINEE ! <yellow>" + quest.name() +
                        " <gray>- fais /quest pour reclamer ta recompense !"));
            }
            persistProgress(uuid, quest.id(), newProgress, justCompleted);
        }
    }

    /**
     * Marque une quete CUSTOM comme terminee pour un joueur (validation manuelle par le
     * staff, voir /quest admin complete) : ce type de quete n'est jamais suivi
     * automatiquement par QuestProgressListener.
     */
    public boolean forceComplete(Player target, int questId) {
        Quest quest = quests.get(questId);
        if (quest == null) return false;
        UUID uuid = target.getUniqueId();
        if (isCompleted(uuid, questId)) return false;

        progressCache.computeIfAbsent(uuid, k -> new HashMap<>()).put(questId, quest.targetAmount());
        completedCache.computeIfAbsent(uuid, k -> new HashSet<>()).add(questId);
        target.sendMessage(TextUtil.parse("<gold><bold>QUETE TERMINEE ! <yellow>" + quest.name() +
                " <gray>- fais /quest pour reclamer ta recompense !"));
        persistProgress(uuid, questId, quest.targetAmount(), true);
        return true;
    }

    /**
     * Reclame la recompense d'une quete terminee (bouton dans l'interface /quest). Ne verse
     * la recompense qu'une seule fois : une deuxieme tentative (double-clic, etc.) est sans
     * effet grace a la verification isClaimed().
     */
    public boolean claimReward(Player player, int questId) {
        UUID uuid = player.getUniqueId();
        Quest quest = quests.get(questId);
        if (quest == null) return false;
        if (!isCompleted(uuid, questId) || isClaimed(uuid, questId)) return false;

        claimedCache.computeIfAbsent(uuid, k -> new HashSet<>()).add(questId);
        grantReward(player, quest);
        persistClaim(uuid, questId);
        return true;
    }

    private void grantReward(Player player, Quest quest) {
        if (quest.rewardCoins() > 0) {
            plugin.getEconomyManager().deposit(player.getUniqueId(), quest.rewardCoins());
            player.sendMessage(TextUtil.parse("<gray>+ <gold>" + (long) quest.rewardCoins() + " Block2Coins"));
        }
        if (quest.rewardTitle() != null && !quest.rewardTitle().isBlank()) {
            unlockedTitlesCache.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>()).add(quest.rewardTitle());
            player.sendMessage(TextUtil.parse("<gray>Tag debloque : ")
                    .append(plugin.getConfigManager().titleFormatted(quest.rewardTitle()))
                    .append(TextUtil.parse("<gray> - choisis-le avec /tag !")));
            persistTitleUnlock(player.getUniqueId(), quest.rewardTitle());
        }
        player.sendMessage(TextUtil.parse("<green>Recompense reclamee : ").append(TextUtil.parse("<yellow>" + quest.name())));
    }

    private void persistProgress(UUID uuid, int questId, int progress, boolean completed) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_quest_progress (uuid, quest_id, progress, completed) VALUES (?,?,?,?) " +
                                 "ON CONFLICT(uuid, quest_id) DO UPDATE SET progress = excluded.progress, completed = excluded.completed")) {
                statement.setString(1, uuid.toString());
                statement.setInt(2, questId);
                statement.setInt(3, progress);
                statement.setBoolean(4, completed);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde progression quete", exception);
            }
        });
    }

    private void persistClaim(UUID uuid, int questId) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "UPDATE b2c_quest_progress SET reward_claimed = 1 WHERE uuid = ? AND quest_id = ?")) {
                statement.setString(1, uuid.toString());
                statement.setInt(2, questId);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde reclamation quete", exception);
            }
        });
    }

    private void persistTitleUnlock(UUID uuid, String title) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("INSERT OR IGNORE INTO b2c_titles_unlocked (uuid, title) VALUES (?, ?)")) {
                statement.setString(1, uuid.toString());
                statement.setString(2, title);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde titre debloque", exception);
            }
        });
    }

    /** Change le tag (titre) affiche du joueur, si celui-ci est bien debloque (ou null pour retirer). */
    public boolean setActiveTitle(Player player, String title) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return false;
        if (title == null || title.equalsIgnoreCase("none") || title.equalsIgnoreCase("aucun")) {
            data.setTitle(null);
            persistActiveTitle(player.getUniqueId(), null);
            return true;
        }
        if (!getUnlockedTitles(player.getUniqueId()).contains(title)) {
            return false;
        }
        data.setTitle(title);
        persistActiveTitle(player.getUniqueId(), title);
        return true;
    }

    private void persistActiveTitle(UUID uuid, String title) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("UPDATE b2c_players SET title = ? WHERE uuid = ?")) {
                statement.setString(1, title);
                statement.setString(2, uuid.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde titre actif", exception);
            }
        });
    }
}
