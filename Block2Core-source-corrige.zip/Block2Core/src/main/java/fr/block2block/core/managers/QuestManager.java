package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Quest;
import fr.block2block.core.data.QuestDifficulty;
import fr.block2block.core.data.QuestType;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Gere les 90 quetes fournies par defaut (30 par QuestDifficulty : FACILE / MOYENNE /
 * IMPOSSIBLE), la progression des joueurs, la reclamation des recompenses et les tags
 * (titres de quete, chacun avec sa propre couleur) debloques.
 * <p>
 * Il n'existe plus de commande pour ajouter des quetes : la liste ci-dessous (DEFAULT_QUESTS)
 * est LA source de verite, inseree une seule fois en base au premier demarrage. La modifier
 * necessite de changer le code (et redemarrer avec une base vide, ou executer soi-meme les
 * requetes SQL correspondantes) - c'est voulu, voir la demande "pas de quetes ajoutable par
 * admin".
 * <p>
 * Une quete terminee (progress >= targetAmount) ne verse pas automatiquement sa recompense :
 * le joueur doit la reclamer dans l'interface (voir claimReward(), utilise par gui/QuestGUI).
 */
public class QuestManager {

    private final Block2Core plugin;

    private final Map<Integer, Quest> quests = new ConcurrentHashMap<>();
    private final Map<UUID, Map<Integer, Integer>> progressCache = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Integer>> completedCache = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Integer>> claimedCache = new ConcurrentHashMap<>();

    /** Minerais dont la variante DEEPSLATE_* doit compter comme la variante normale dans les quetes de minage. */
    private static final Set<String> DEEPSLATE_NORMALIZABLE_ORES = Set.of(
            "COAL_ORE", "IRON_ORE", "GOLD_ORE", "DIAMOND_ORE", "LAPIS_ORE", "REDSTONE_ORE", "EMERALD_ORE", "COPPER_ORE"
    );

    private static final List<Quest> DEFAULT_QUESTS = buildDefaultQuests();

    public QuestManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // GENERATION DES 90 QUETES PAR DEFAUT (30 templates x 3 paliers)
    // ---------------------------------------------------------------

    private static List<Quest> buildDefaultQuests() {
        List<Quest> list = new ArrayList<>();

        // --- Minage (les variantes deepslate comptent aussi, voir normalizeTarget()) ---
        addTemplate(list, "Charbon", QuestType.BLOCK_BREAK, "COAL_ORE", "Recolte %d minerais de charbon (les variantes deepslate comptent aussi).",
                new int[]{32, 200, 2500}, new double[]{150, 900, 8000}, null, null);
        addTemplate(list, "Fer", QuestType.BLOCK_BREAK, "IRON_ORE", "Recolte %d minerais de fer (les variantes deepslate comptent aussi).",
                new int[]{24, 150, 2000}, new double[]{200, 1000, 9000}, null, null);
        addTemplate(list, "Or", QuestType.BLOCK_BREAK, "GOLD_ORE", "Recolte %d minerais d'or (les variantes deepslate comptent aussi).",
                new int[]{16, 100, 1500}, new double[]{200, 1000, 9000}, null, null);
        addTemplate(list, "Diamant", QuestType.BLOCK_BREAK, "DIAMOND_ORE", "Recolte %d minerais de diamant (les variantes deepslate comptent aussi).",
                new int[]{8, 50, 800}, new double[]{500, 2500, 16000}, "Empereur du Diamant", "<aqua>");
        addTemplate(list, "Lapis-lazuli", QuestType.BLOCK_BREAK, "LAPIS_ORE", "Recolte %d minerais de lapis-lazuli (les variantes deepslate comptent aussi).",
                new int[]{16, 100, 1500}, new double[]{200, 1000, 8500}, null, null);
        addTemplate(list, "Redstone", QuestType.BLOCK_BREAK, "REDSTONE_ORE", "Recolte %d minerais de redstone (les variantes deepslate comptent aussi).",
                new int[]{16, 100, 1500}, new double[]{200, 1000, 8500}, null, null);
        addTemplate(list, "Emeraude", QuestType.BLOCK_BREAK, "EMERALD_ORE", "Recolte %d minerais d'emeraude (les variantes deepslate comptent aussi).",
                new int[]{8, 40, 600}, new double[]{400, 2000, 14000}, "Roi de l'Emeraude", "<green>");
        addTemplate(list, "Cuivre", QuestType.BLOCK_BREAK, "COPPER_ORE", "Recolte %d minerais de cuivre (les variantes deepslate comptent aussi).",
                new int[]{24, 150, 2000}, new double[]{150, 900, 8000}, null, null);

        // --- Minage (blocs simples) ---
        addTemplate(list, "Pierre", QuestType.BLOCK_BREAK, "STONE", "Casse %d blocs de pierre.",
                new int[]{100, 600, 8000}, new double[]{120, 800, 6500}, null, null);
        addTemplate(list, "Bucheron", QuestType.BLOCK_BREAK, "OAK_LOG", "Abats %d rondins de chene.",
                new int[]{50, 300, 4000}, new double[]{120, 800, 6500}, null, null);
        addTemplate(list, "Sable", QuestType.BLOCK_BREAK, "SAND", "Casse %d blocs de sable.",
                new int[]{64, 400, 5000}, new double[]{120, 800, 6500}, null, null);
        addTemplate(list, "Gravier", QuestType.BLOCK_BREAK, "GRAVEL", "Casse %d blocs de gravier.",
                new int[]{64, 400, 5000}, new double[]{100, 700, 6000}, null, null);

        // --- Construction ---
        addTemplate(list, "Macon", QuestType.BLOCK_PLACE, "COBBLESTONE", "Pose %d blocs de pierre taillee.",
                new int[]{50, 300, 4000}, new double[]{100, 700, 6000}, null, null);
        addTemplate(list, "Eclaireur", QuestType.BLOCK_PLACE, "TORCH", "Pose %d torches.",
                new int[]{30, 150, 2000}, new double[]{100, 700, 6000}, null, null);
        addTemplate(list, "Charpentier", QuestType.BLOCK_PLACE, "OAK_PLANKS", "Pose %d planches de chene.",
                new int[]{100, 600, 8000}, new double[]{120, 800, 6500}, null, null);
        addTemplate(list, "Vitrier", QuestType.BLOCK_PLACE, "GLASS", "Pose %d blocs de verre.",
                new int[]{50, 300, 4000}, new double[]{120, 800, 6500}, null, null);
        addTemplate(list, "Brique", QuestType.BLOCK_PLACE, "BRICKS", "Pose %d briques de pierre.",
                new int[]{40, 250, 3000}, new double[]{150, 1000, 8000}, null, null);
        addTemplate(list, "Tisserand", QuestType.BLOCK_PLACE, "WHITE_WOOL", "Pose %d blocs de laine blanche.",
                new int[]{40, 250, 3000}, new double[]{150, 1000, 8000}, null, null);

        // --- Combat ---
        addTemplate(list, "Exterminateur", QuestType.MOB_KILL, "ZOMBIE", "Elimine %d zombies.",
                new int[]{15, 100, 1500}, new double[]{150, 900, 8000}, "Fleau des Morts", "<gray>");
        addTemplate(list, "Chasseur d'os", QuestType.MOB_KILL, "SKELETON", "Elimine %d squelettes.",
                new int[]{15, 100, 1500}, new double[]{150, 900, 8000}, null, null);
        addTemplate(list, "Tisse-toile", QuestType.MOB_KILL, "SPIDER", "Elimine %d araignees.",
                new int[]{15, 80, 1200}, new double[]{150, 800, 7000}, null, null);
        addTemplate(list, "Demineur", QuestType.MOB_KILL, "CREEPER", "Elimine %d creepers.",
                new int[]{10, 60, 900}, new double[]{200, 1200, 9000}, "Demineur", "<red>");
        addTemplate(list, "Traqueur de l'End", QuestType.MOB_KILL, "ENDERMAN", "Elimine %d endermen.",
                new int[]{5, 30, 500}, new double[]{350, 2000, 14000}, "Traqueur de l'End", "<light_purple>");
        addTemplate(list, "Plongeur", QuestType.MOB_KILL, "DROWNED", "Elimine %d noyes.",
                new int[]{10, 60, 900}, new double[]{200, 1200, 9000}, null, null);
        addTemplate(list, "Sang-Froid", QuestType.MOB_KILL, "WITCH", "Elimine %d sorcieres.",
                new int[]{8, 40, 600}, new double[]{350, 1800, 12000}, "Sang-Froid", "<dark_green>");
        addTemplate(list, "Pyromane", QuestType.MOB_KILL, "BLAZE", "Elimine %d blazes dans le Nether.",
                new int[]{8, 40, 600}, new double[]{400, 2000, 13000}, "Pyromane", "<gold>");
        addTemplate(list, "Chasse-fantome", QuestType.MOB_KILL, "PHANTOM", "Elimine %d phantoms.",
                new int[]{8, 40, 600}, new double[]{300, 1600, 11000}, null, null);
        addTemplate(list, "Garde-frontiere", QuestType.MOB_KILL, "PILLAGER", "Elimine %d pillards.",
                new int[]{12, 70, 1000}, new double[]{250, 1400, 10000}, null, null);
        addTemplate(list, "Bourreau", QuestType.MOB_KILL, "VINDICATOR", "Elimine %d justiciers (vindicators).",
                new int[]{6, 35, 500}, new double[]{350, 1800, 12000}, "Bourreau", "<dark_red>");
        addTemplate(list, "Chasseur du desert", QuestType.MOB_KILL, "HUSK", "Elimine %d zombies des sables (husks).",
                new int[]{12, 70, 1000}, new double[]{200, 1200, 9000}, null, null);

        return List.copyOf(list);
    }

    /**
     * Cree les 3 paliers (FACILE/MOYENNE/IMPOSSIBLE) d'un meme objectif, avec un nom commun
     * suffixe en chiffres romains. Le tag (titre) et sa couleur, si fournis, ne sont accordes
     * qu'au palier IMPOSSIBLE (recompense de prestige pour l'objectif le plus difficile).
     */
    private static void addTemplate(List<Quest> list, String label, QuestType type, String target, String descriptionTemplate,
                                     int[] amounts, double[] coins, String tag, String tagColor) {
        QuestDifficulty[] tiers = {QuestDifficulty.FACILE, QuestDifficulty.MOYENNE, QuestDifficulty.IMPOSSIBLE};
        String[] suffixes = {" I", " II", " III"};
        for (int i = 0; i < 3; i++) {
            boolean isTopTier = tiers[i] == QuestDifficulty.IMPOSSIBLE;
            list.add(new Quest(-1, label + suffixes[i], String.format(descriptionTemplate, amounts[i]), tiers[i], type,
                    target, amounts[i], coins[i], isTopTier ? tag : null, isTopTier ? tagColor : null));
        }
    }

    /** Ramene une variante deepslate d'un minerai (ex DEEPSLATE_DIAMOND_ORE) vers sa forme normale pour le suivi de quete. */
    private static String normalizeTarget(String rawTarget) {
        if (rawTarget != null && rawTarget.startsWith("DEEPSLATE_")) {
            String base = rawTarget.substring("DEEPSLATE_".length());
            if (DEEPSLATE_NORMALIZABLE_ORES.contains(base)) {
                return base;
            }
        }
        return rawTarget;
    }

    /**
     * Insere les quetes par defaut MANQUANTES (comparaison par nom), sans jamais toucher a
     * celles deja en base. Contrairement a une simple verification "table vide ou pas", ceci
     * fonctionne aussi pour completer une base qui a deja ete partiellement seedee par une
     * version anterieure du plugin (par exemple si un demarrage precedent n'avait que 8 des 30
     * objectifs de base) : les quetes manquantes sont detectees et ajoutees, celles existantes
     * (et la progression des joueurs dessus) restent intactes.
     */
    public void seedDefaultQuests() {
        Set<String> existingNames = new HashSet<>();
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement("SELECT name FROM b2c_quests");
             var rs = statement.executeQuery()) {
            while (rs.next()) {
                existingNames.add(rs.getString("name"));
            }
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur verification des quetes existantes", exception);
            return;
        }

        List<Quest> missing = new ArrayList<>();
        for (Quest quest : DEFAULT_QUESTS) {
            if (!existingNames.contains(quest.name())) {
                missing.add(quest);
            }
        }
        if (missing.isEmpty()) {
            return;
        }

        plugin.getLogger().info("Insertion de " + missing.size() + " quete(s) par defaut manquante(s) sur " +
                DEFAULT_QUESTS.size() + " au total (" + existingNames.size() + " deja en base)...");
        try (var connection = plugin.getDatabaseManager().getConnection();
             var statement = connection.prepareStatement(
                     "INSERT INTO b2c_quests (name, description, difficulty, type, target, target_amount, reward_coins, reward_title, title_color) " +
                             "VALUES (?,?,?,?,?,?,?,?,?)")) {
            for (Quest quest : missing) {
                statement.setString(1, quest.name());
                statement.setString(2, quest.description());
                statement.setString(3, quest.difficulty().name());
                statement.setString(4, quest.type().name());
                statement.setString(5, quest.target());
                statement.setInt(6, quest.targetAmount());
                statement.setDouble(7, quest.rewardCoins());
                statement.setString(8, quest.rewardTitle());
                statement.setString(9, quest.titleColor());
                statement.addBatch();
            }
            statement.executeBatch();
        } catch (Exception exception) {
            plugin.getLogger().log(Level.WARNING, "Erreur insertion des quetes par defaut manquantes", exception);
        }
    }

    /**
     * Enregistre la definition (couleur + description) de chaque tag distinct accorde par les
     * 90 quetes par defaut, dans le registre central de TagManager. Comme seedDefaultQuests(),
     * tourne a chaque demarrage et est sans risque a rejouer : seedTagIfMissing() n'ecrase
     * jamais un tag deja personnalise par le staff via /tagadmin, et permet aussi de "reparer"
     * un tag qui aurait ete supprime par erreur.
     */
    public void seedDefaultTagDefinitions() {
        for (Quest quest : DEFAULT_QUESTS) {
            if (quest.rewardTitle() == null || quest.rewardTitle().isBlank()) continue;
            String color = quest.titleColor() != null ? quest.titleColor() : plugin.getConfigManager().titleColor();
            plugin.getTagManager().seedTagIfMissing(quest.rewardTitle(), color,
                    "Recompense de la quete \"" + quest.name() + "\"");
        }
    }

    public void loadAllQuests() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int loaded = 0;
            int skipped = 0;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_quests");
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    // Chaque ligne est traitee independamment : une seule quete avec une donnee
                    // invalide (ex. valeur de difficulte/type corrompue) ne doit jamais faire
                    // perdre le chargement de toutes les autres.
                    try {
                        Quest quest = new Quest(
                                rs.getInt("id"), rs.getString("name"), rs.getString("description"),
                                QuestDifficulty.valueOf(rs.getString("difficulty")), QuestType.valueOf(rs.getString("type")),
                                rs.getString("target"), rs.getInt("target_amount"), rs.getDouble("reward_coins"),
                                rs.getString("reward_title"), rs.getString("title_color"));
                        quests.put(quest.id(), quest);
                        loaded++;
                    } catch (Exception rowException) {
                        skipped++;
                        plugin.getLogger().log(Level.WARNING, "Quete ignoree (donnees invalides, id=" + rs.getInt("id") + ")", rowException);
                    }
                }
                plugin.getLogger().info("Quetes chargees : " + loaded + "/" + DEFAULT_QUESTS.size() +
                        (skipped > 0 ? " (" + skipped + " ignorees, voir logs ci-dessus)" : ""));
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement quetes", exception);
            }
        });
    }

    public List<Quest> getAllQuests() {
        return new ArrayList<>(quests.values());
    }

    public List<Quest> getQuestsByDifficulty(QuestDifficulty difficulty) {
        List<Quest> result = new ArrayList<>();
        for (Quest quest : quests.values()) {
            if (quest.difficulty() == difficulty) result.add(quest);
        }
        return result;
    }

    public Quest getQuest(int id) {
        return quests.get(id);
    }

    /** Charge la progression et les quetes reclamees d'un joueur (a appeler au join ; voir aussi TagManager#loadPlayer). */
    public void loadPlayer(UUID uuid, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Map<Integer, Integer> progress = new HashMap<>();
            Set<Integer> completed = new HashSet<>();
            Set<Integer> claimed = new HashSet<>();
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "SELECT quest_id, progress, completed, reward_claimed FROM b2c_quest_progress WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                try (var rs = statement.executeQuery()) {
                    while (rs.next()) {
                        progress.put(rs.getInt("quest_id"), rs.getInt("progress"));
                        if (rs.getBoolean("completed")) {
                            completed.add(rs.getInt("quest_id"));
                        }
                        if (rs.getBoolean("reward_claimed")) {
                            claimed.add(rs.getInt("quest_id"));
                        }
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement progression quetes", exception);
            }
            progressCache.put(uuid, progress);
            completedCache.put(uuid, completed);
            claimedCache.put(uuid, claimed);
            if (onDone != null) {
                Bukkit.getScheduler().runTask(plugin, onDone);
            }
        });
    }

    public void unloadPlayer(UUID uuid) {
        progressCache.remove(uuid);
        completedCache.remove(uuid);
        claimedCache.remove(uuid);
    }

    public int getProgress(UUID uuid, int questId) {
        return progressCache.getOrDefault(uuid, Map.of()).getOrDefault(questId, 0);
    }

    public boolean isCompleted(UUID uuid, int questId) {
        return completedCache.getOrDefault(uuid, Set.of()).contains(questId);
    }

    public boolean isClaimed(UUID uuid, int questId) {
        return claimedCache.getOrDefault(uuid, Set.of()).contains(questId);
    }

    /** Nombre total de quetes reclamees par ce joueur, toutes difficultes confondues (utilise par /rankup). */
    public int getClaimedCount(UUID uuid) {
        return claimedCache.getOrDefault(uuid, Set.of()).size();
    }

    // ---------------------------------------------------------------
    // PROGRESSION (appele depuis QuestProgressListener)
    // ---------------------------------------------------------------

    public void progress(Player player, QuestType type, String rawTarget, int amount) {
        UUID uuid = player.getUniqueId();
        String target = normalizeTarget(rawTarget);
        for (Quest quest : quests.values()) {
            if (quest.type() != type) continue;
            if (quest.target() != null && target != null && !quest.target().equalsIgnoreCase(target)) continue;
            if (isCompleted(uuid, quest.id())) continue;

            Map<Integer, Integer> playerProgress = progressCache.computeIfAbsent(uuid, k -> new HashMap<>());
            int newProgress = playerProgress.getOrDefault(quest.id(), 0) + amount;
            playerProgress.put(quest.id(), newProgress);

            boolean justCompleted = newProgress >= quest.targetAmount();
            if (justCompleted) {
                completedCache.computeIfAbsent(uuid, k -> new HashSet<>()).add(quest.id());
                player.sendMessage(TextUtil.parse("<gold><bold>QUETE TERMINEE ! <yellow>" + quest.name() +
                        " <gray>- fais /quest pour reclamer ta recompense !"));
            }
            persistProgress(uuid, quest.id(), newProgress, justCompleted);
        }
    }

    /**
     * Reclame la recompense d'une quete terminee (bouton dans l'interface /quest). Ne verse
     * la recompense qu'une seule fois : une deuxieme tentative (double-clic, etc.) est sans
     * effet grace a la verification isClaimed().
     */
    public boolean claimReward(Player player, int questId) {
        UUID uuid = player.getUniqueId();
        Quest quest = quests.get(questId);
        if (quest == null) return false;
        if (!isCompleted(uuid, questId) || isClaimed(uuid, questId)) return false;

        claimedCache.computeIfAbsent(uuid, k -> new HashSet<>()).add(questId);
        grantReward(player, quest);
        persistClaim(uuid, questId);
        return true;
    }

    private void grantReward(Player player, Quest quest) {
        if (quest.rewardCoins() > 0) {
            plugin.getEconomyManager().deposit(player.getUniqueId(), quest.rewardCoins());
            player.sendMessage(TextUtil.parse("<gray>+ <gold>" + (long) quest.rewardCoins() + " Block2Coins"));
        }
        if (quest.rewardTitle() != null && !quest.rewardTitle().isBlank()) {
            plugin.getTagManager().giveTag(player, quest.rewardTitle(), null);
            player.sendMessage(TextUtil.parse("<gray>Tag debloque : ")
                    .append(plugin.getTagManager().formatTag(quest.rewardTitle()))
                    .append(TextUtil.parse("<gray> - choisis-le avec /tag !")));
        }
        player.sendMessage(TextUtil.parse("<green>Recompense reclamee : ").append(TextUtil.parse("<yellow>" + quest.name())));
    }

    private void persistProgress(UUID uuid, int questId, int progress, boolean completed) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_quest_progress (uuid, quest_id, progress, completed) VALUES (?,?,?,?) " +
                                 "ON CONFLICT(uuid, quest_id) DO UPDATE SET progress = excluded.progress, completed = excluded.completed")) {
                statement.setString(1, uuid.toString());
                statement.setInt(2, questId);
                statement.setInt(3, progress);
                statement.setBoolean(4, completed);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde progression quete", exception);
            }
        });
    }

    private void persistClaim(UUID uuid, int questId) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "UPDATE b2c_quest_progress SET reward_claimed = 1 WHERE uuid = ? AND quest_id = ?")) {
                statement.setString(1, uuid.toString());
                statement.setInt(2, questId);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde reclamation quete", exception);
            }
        });
    }
}
