package fr.block2block.core.managers;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.Quest;
import fr.block2block.core.data.QuestType;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Gere les quetes creees par le staff, la progression des joueurs et les
 * titres de quete debloques (affiches dans le chat, DARK_GREEN BOLD).
 */
public class QuestManager {

    private final Block2Core plugin;

    private final Map<Integer, Quest> quests = new ConcurrentHashMap<>();
    private final Map<UUID, Map<Integer, Integer>> progressCache = new ConcurrentHashMap<>();
    private final Map<UUID, Set<Integer>> completedCache = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> unlockedTitlesCache = new ConcurrentHashMap<>();

    public QuestManager(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void loadAllQuests() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("SELECT * FROM b2c_quests");
                 var rs = statement.executeQuery()) {
                while (rs.next()) {
                    Quest quest = new Quest(
                            rs.getInt("id"), rs.getString("name"), rs.getString("description"),
                            QuestType.valueOf(rs.getString("type")), rs.getString("target"),
                            rs.getInt("target_amount"), rs.getDouble("reward_coins"), rs.getString("reward_title"));
                    quests.put(quest.id(), quest);
                }
                plugin.getLogger().info("Quetes chargees : " + quests.size());
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement quetes", exception);
            }
        });
    }

    public List<Quest> getAllQuests() {
        return new ArrayList<>(quests.values());
    }

    public void createQuest(Quest quest, Consumer<Integer> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            int generatedId = -1;
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_quests (name, description, type, target, target_amount, reward_coins, reward_title) VALUES (?,?,?,?,?,?,?)",
                         java.sql.Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, quest.name());
                statement.setString(2, quest.description());
                statement.setString(3, quest.type().name());
                statement.setString(4, quest.target());
                statement.setInt(5, quest.targetAmount());
                statement.setDouble(6, quest.rewardCoins());
                statement.setString(7, quest.rewardTitle());
                statement.executeUpdate();
                try (var keys = statement.getGeneratedKeys()) {
                    if (keys.next()) {
                        generatedId = keys.getInt(1);
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur creation quete", exception);
            }
            if (generatedId > 0) {
                Quest saved = new Quest(generatedId, quest.name(), quest.description(), quest.type(),
                        quest.target(), quest.targetAmount(), quest.rewardCoins(), quest.rewardTitle());
                quests.put(generatedId, saved);
            }
            int finalId = generatedId;
            Bukkit.getScheduler().runTask(plugin, () -> callback.accept(finalId));
        });
    }

    /** Charge la progression + titres debloques d'un joueur (a appeler au join). */
    public void loadPlayer(UUID uuid, Runnable onDone) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Map<Integer, Integer> progress = new HashMap<>();
            Set<Integer> completed = new HashSet<>();
            Set<String> titles = new HashSet<>();
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                try (var statement = connection.prepareStatement("SELECT quest_id, progress, completed FROM b2c_quest_progress WHERE uuid = ?")) {
                    statement.setString(1, uuid.toString());
                    try (var rs = statement.executeQuery()) {
                        while (rs.next()) {
                            progress.put(rs.getInt("quest_id"), rs.getInt("progress"));
                            if (rs.getBoolean("completed")) {
                                completed.add(rs.getInt("quest_id"));
                            }
                        }
                    }
                }
                try (var statement = connection.prepareStatement("SELECT title FROM b2c_titles_unlocked WHERE uuid = ?")) {
                    statement.setString(1, uuid.toString());
                    try (var rs = statement.executeQuery()) {
                        while (rs.next()) {
                            titles.add(rs.getString("title"));
                        }
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement progression quetes", exception);
            }
            progressCache.put(uuid, progress);
            completedCache.put(uuid, completed);
            unlockedTitlesCache.put(uuid, titles);
            if (onDone != null) {
                Bukkit.getScheduler().runTask(plugin, onDone);
            }
        });
    }

    public void unloadPlayer(UUID uuid) {
        progressCache.remove(uuid);
        completedCache.remove(uuid);
        unlockedTitlesCache.remove(uuid);
    }

    public Set<String> getUnlockedTitles(UUID uuid) {
        return unlockedTitlesCache.getOrDefault(uuid, Set.of());
    }

    public int getProgress(UUID uuid, int questId) {
        return progressCache.getOrDefault(uuid, Map.of()).getOrDefault(questId, 0);
    }

    public boolean isCompleted(UUID uuid, int questId) {
        return completedCache.getOrDefault(uuid, Set.of()).contains(questId);
    }

    // ---------------------------------------------------------------
    // PROGRESSION (appele depuis QuestProgressListener)
    // ---------------------------------------------------------------

    public void progress(Player player, QuestType type, String target, int amount) {
        UUID uuid = player.getUniqueId();
        for (Quest quest : quests.values()) {
            if (quest.type() != type) continue;
            if (quest.target() != null && target != null && !quest.target().equalsIgnoreCase(target)) continue;
            if (isCompleted(uuid, quest.id())) continue;

            Map<Integer, Integer> playerProgress = progressCache.computeIfAbsent(uuid, k -> new HashMap<>());
            int newProgress = playerProgress.getOrDefault(quest.id(), 0) + amount;
            playerProgress.put(quest.id(), newProgress);

            boolean justCompleted = newProgress >= quest.targetAmount();
            if (justCompleted) {
                completedCache.computeIfAbsent(uuid, k -> new HashSet<>()).add(quest.id());
                onQuestCompleted(player, quest);
            }
            persistProgress(uuid, quest.id(), newProgress, justCompleted);
        }
    }

    private void onQuestCompleted(Player player, Quest quest) {
        player.sendMessage(TextUtil.parse("<gold><bold>QUETE TERMINEE ! <yellow>" + quest.name()));
        if (quest.rewardCoins() > 0) {
            plugin.getEconomyManager().deposit(player.getUniqueId(), quest.rewardCoins());
            player.sendMessage(TextUtil.parse("<gray>+ <gold>" + (long) quest.rewardCoins() + " Block2Coins"));
        }
        if (quest.rewardTitle() != null && !quest.rewardTitle().isBlank()) {
            unlockedTitlesCache.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>()).add(quest.rewardTitle());
            player.sendMessage(TextUtil.parse("<gray>Titre debloque : ")
                    .append(plugin.getConfigManager().titleFormatted(quest.rewardTitle())));
            persistTitleUnlock(player.getUniqueId(), quest.rewardTitle());
        }
    }

    private void persistProgress(UUID uuid, int questId, int progress, boolean completed) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement(
                         "INSERT INTO b2c_quest_progress (uuid, quest_id, progress, completed) VALUES (?,?,?,?) " +
                                 "ON CONFLICT(uuid, quest_id) DO UPDATE SET progress = excluded.progress, completed = excluded.completed")) {
                statement.setString(1, uuid.toString());
                statement.setInt(2, questId);
                statement.setInt(3, progress);
                statement.setBoolean(4, completed);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde progression quete", exception);
            }
        });
    }

    private void persistTitleUnlock(UUID uuid, String title) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("INSERT OR IGNORE INTO b2c_titles_unlocked (uuid, title) VALUES (?, ?)")) {
                statement.setString(1, uuid.toString());
                statement.setString(2, title);
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde titre debloque", exception);
            }
        });
    }

    /** Change le titre affiche du joueur, si celui-ci est bien debloque (ou "none" pour retirer). */
    public boolean setActiveTitle(Player player, String title) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return false;
        if (title == null || title.equalsIgnoreCase("none") || title.equalsIgnoreCase("aucun")) {
            data.setTitle(null);
            persistActiveTitle(player.getUniqueId(), null);
            return true;
        }
        if (!getUnlockedTitles(player.getUniqueId()).contains(title)) {
            return false;
        }
        data.setTitle(title);
        persistActiveTitle(player.getUniqueId(), title);
        return true;
    }

    private void persistActiveTitle(UUID uuid, String title) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (var connection = plugin.getDatabaseManager().getConnection();
                 var statement = connection.prepareStatement("UPDATE b2c_players SET title = ? WHERE uuid = ?")) {
                statement.setString(1, title);
                statement.setString(2, uuid.toString());
                statement.executeUpdate();
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur sauvegarde titre actif", exception);
            }
        });
    }
}
