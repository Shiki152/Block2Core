package fr.block2block.core.commands.quest;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Quest;
import fr.block2block.core.data.QuestType;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

/**
 * /quest (seul) ouvre desormais l'interface graphique (voir gui/QuestGUI) plutot que
 * d'afficher une liste en texte. Les sous-commandes admin restent en texte, coherent avec le
 * reste des commandes de moderation du plugin.
 */
public class QuestCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public QuestCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("admin")) {
            return handleAdmin(sender, args);
        }
        return handleOpen(sender);
    }

    private boolean handleOpen(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getQuestGUI().open(player);
        return true;
    }

    private boolean handleAdmin(CommandSender sender, String[] args) {
        // Permission dediee, distincte de "block2core.command.quest" (accordee a tous par
        // defaut pour la consultation des quetes) : sans cela, n'importe quel joueur pouvait
        // creer/valider des quetes via /quest admin.
        if (!sender.hasPermission("block2core.command.quest.admin")) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("no-permission", null));
            return true;
        }
        if (args.length >= 2 && args[1].equalsIgnoreCase("complete")) {
            return handleAdminComplete(sender, args);
        }
        if (args.length < 7 || !args[1].equalsIgnoreCase("create")) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /quest admin create <nom> <type> <cible|none> <montant> <recompense_coins> [titre]"));
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /quest admin complete <joueur> <id_quete>"));
            return true;
        }
        // /quest admin create <nom> <type> <cible> <montant> <recompenseCoins> [titre]
        String name = args[2];
        QuestType type;
        try {
            type = QuestType.valueOf(args[3].toUpperCase());
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(TextUtil.parse("<red>Type invalide. Valeurs : BLOCK_BREAK, BLOCK_PLACE, MOB_KILL, CUSTOM"));
            return true;
        }
        String target = args[4].equalsIgnoreCase("none") ? null : args[4].toUpperCase();
        int amount;
        double rewardCoins;
        try {
            amount = Integer.parseInt(args[5]);
            rewardCoins = Double.parseDouble(args[6]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", java.util.Map.of("valeur", args[5])));
            return true;
        }
        String rewardTitle = args.length > 7 ? args[7] : null;

        Quest quest = new Quest(-1, name, "", type, target, amount, rewardCoins, rewardTitle);
        plugin.getQuestManager().createQuest(quest, id -> {
            if (id > 0) {
                // La quete apparait immediatement dans l'interface /quest de tous les joueurs
                // (voir QuestManager#createQuest, qui met a jour le cache en memoire).
                sender.sendMessage(TextUtil.parse("<green>Quete creee avec l'id #" + id + " - visible immediatement dans /quest."));
            } else {
                sender.sendMessage(TextUtil.parse("<red>Erreur lors de la creation de la quete."));
            }
        });
        return true;
    }

    private boolean handleAdminComplete(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /quest admin complete <joueur> <id_quete>"));
            return true;
        }
        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        int questId;
        try {
            questId = Integer.parseInt(args[3]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", java.util.Map.of("valeur", args[3])));
            return true;
        }
        if (plugin.getQuestManager().getQuest(questId) == null) {
            sender.sendMessage(TextUtil.parse("<red>Aucune quete avec l'id #" + questId + "."));
            return true;
        }
        boolean success = plugin.getQuestManager().forceComplete(target, questId);
        if (success) {
            sender.sendMessage(TextUtil.parse("<green>Quete #" + questId + " marquee terminee pour " + target.getName() +
                    " (a lui de la reclamer dans /quest)."));
        } else {
            sender.sendMessage(TextUtil.parse("<red>Cette quete est deja terminee pour ce joueur."));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return filter(List.of("admin"), args[0]);
        if (args.length == 2 && args[0].equalsIgnoreCase("admin")) return filter(List.of("create", "complete"), args[1]);
        if (args.length == 4 && args[0].equalsIgnoreCase("admin") && args[1].equalsIgnoreCase("create")) {
            return filter(List.of("BLOCK_BREAK", "BLOCK_PLACE", "MOB_KILL", "CUSTOM"), args[3]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
