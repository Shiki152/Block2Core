package fr.block2block.core.commands.quest;

import fr.block2block.core.Block2Core;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /quest (alias /quetes) ouvre l'interface graphique des quetes (voir gui/QuestGUI). Les 90
 * quetes du serveur sont fixes et fournies par defaut : il n'existe plus de sous-commande
 * admin pour en ajouter/valider manuellement.
 */
public class QuestCommand implements CommandExecutor {

    private final Block2Core plugin;

    public QuestCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getQuestGUI().open(player);
        return true;
    }
}
