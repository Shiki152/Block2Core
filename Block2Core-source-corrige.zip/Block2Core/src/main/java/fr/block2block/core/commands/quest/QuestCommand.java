package fr.block2block.core.commands.quest;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Quest;
import fr.block2block.core.data.QuestType;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

public class QuestCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public QuestCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("admin")) {
            return handleAdmin(sender, args);
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("settitle")) {
            return handleSetTitle(sender, args);
        }
        return handleList(sender);
    }

    private boolean handleList(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        List<Quest> quests = plugin.getQuestManager().getAllQuests();
        if (quests.isEmpty()) {
            player.sendMessage(TextUtil.parse("<gray>Aucune quete disponible pour le moment."));
            return true;
        }
        player.sendMessage(TextUtil.parse("<aqua><bold>--- TES QUETES ---"));
        for (Quest quest : quests) {
            boolean completed = plugin.getQuestManager().isCompleted(player.getUniqueId(), quest.id());
            int progress = plugin.getQuestManager().getProgress(player.getUniqueId(), quest.id());
            String status = completed ? "<green>TERMINEE" : "<yellow>" + progress + "/" + quest.targetAmount();
            player.sendMessage(TextUtil.parse("<gray>- <white>" + quest.name() + " <gray>[" + status + "<gray>]"));
        }
        player.sendMessage(TextUtil.parse("<gray>Titres debloques : <dark_green><bold>" +
                String.join("<gray>, <dark_green><bold>", plugin.getQuestManager().getUnlockedTitles(player.getUniqueId()))));
        return true;
    }

    private boolean handleSetTitle(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /quest settitle <titre|none>"));
            return true;
        }
        String title = String.join("_", java.util.Arrays.copyOfRange(args, 1, args.length));
        boolean success = plugin.getQuestManager().setActiveTitle(player, title);
        if (success) {
            player.sendMessage(TextUtil.parse("<green>Titre mis a jour !"));
        } else {
            player.sendMessage(TextUtil.parse("<red>Tu n'as pas debloque ce titre."));
        }
        return true;
    }

    private boolean handleAdmin(CommandSender sender, String[] args) {
        // Permission dediee, distincte de "block2core.command.quest" (accordee a tous par
        // defaut pour la liste/consultation des quetes) : sans cela, n'importe quel joueur
        // pouvait creer des quetes via /quest admin create.
        if (!sender.hasPermission("block2core.command.quest.admin")) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("no-permission", null));
            return true;
        }
        if (args.length < 2 || !args[1].equalsIgnoreCase("create")) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /quest admin create <nom> <type> <cible> <montant> <recompense_coins> [titre]"));
            return true;
        }
        // /quest admin create <nom> <type> <cible> <montant> <recompenseCoins> [titre]
        if (args.length < 7) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /quest admin create <nom> <type> <cible> <montant> <recompense_coins> [titre]"));
            return true;
        }
        String name = args[2];
        QuestType type;
        try {
            type = QuestType.valueOf(args[3].toUpperCase());
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(TextUtil.parse("<red>Type invalide. Valeurs : BLOCK_BREAK, BLOCK_PLACE, MOB_KILL, CUSTOM"));
            return true;
        }
        String target = args[4].equalsIgnoreCase("none") ? null : args[4].toUpperCase();
        int amount;
        double rewardCoins;
        try {
            amount = Integer.parseInt(args[5]);
            rewardCoins = Double.parseDouble(args[6]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", java.util.Map.of("valeur", args[5])));
            return true;
        }
        String rewardTitle = args.length > 7 ? args[7] : null;

        Quest quest = new Quest(-1, name, "", type, target, amount, rewardCoins, rewardTitle);
        plugin.getQuestManager().createQuest(quest, id -> {
            if (id > 0) {
                sender.sendMessage(TextUtil.parse("<green>Quete creee avec l'id #" + id));
            } else {
                sender.sendMessage(TextUtil.parse("<red>Erreur lors de la creation de la quete."));
            }
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return filter(List.of("admin", "settitle"), args[0]);
        if (args.length == 2 && args[0].equalsIgnoreCase("admin")) return filter(List.of("create"), args[1]);
        if (args.length == 4 && args[0].equalsIgnoreCase("admin")) {
            return filter(List.of("BLOCK_BREAK", "BLOCK_PLACE", "MOB_KILL", "CUSTOM"), args[3]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
