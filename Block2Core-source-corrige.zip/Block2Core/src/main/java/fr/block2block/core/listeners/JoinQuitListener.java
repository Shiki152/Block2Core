package fr.block2block.core.listeners;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.Punishment;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.StaffRank;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.logging.Level;

/**
 * Gere tout le cycle de vie d'un joueur : verification des sanctions au
 * pre-login, chargement des donnees (grade, playtime, homes, ignores,
 * quetes...) au join, sauvegarde et nettoyage des caches au quit.
 */
public class JoinQuitListener implements Listener {

    private final Block2Core plugin;

    public JoinQuitListener(Block2Core plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        var punishments = plugin.getPunishmentManager();
        var config = plugin.getConfigManager();

        if (config.maintenanceEnabled() && !isMaintenanceBypassed(event)) {
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                    TextUtil.parse(config.sanctionScreen("maintenance", java.util.Map.of(
                            "discord", config.infoLink("discord")))));
            return;
        }

        Punishment ipBan = punishments.checkActiveIpBanBlocking(event.getAddress().getHostAddress());
        if (ipBan != null) {
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED,
                    TextUtil.parse(config.sanctionScreen("ipban", java.util.Map.of(
                            "raison", ipBan.reason() != null ? ipBan.reason() : "Aucune raison",
                            "staff", ipBan.staffName() != null ? ipBan.staffName() : "Console",
                            "discord", config.infoLink("discord")))));
            return;
        }

        Punishment blacklist = punishments.checkActiveBlacklistBlocking(event.getUniqueId());
        if (blacklist != null) {
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED,
                    TextUtil.parse(config.sanctionScreen("blacklist", java.util.Map.of(
                            "raison", blacklist.reason() != null ? blacklist.reason() : "Aucune raison",
                            "staff", blacklist.staffName() != null ? blacklist.staffName() : "Console",
                            "discord", config.infoLink("discord")))));
            return;
        }

        Punishment ban = punishments.checkActiveBanBlocking(event.getUniqueId());
        if (ban != null) {
            String duree = ban.isPermanent() ? "Permanent" : TimeUtil.formatEpochRemaining(ban.endMillis());
            String type = ban.isPermanent() ? "ban" : "tempban";
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED,
                    TextUtil.parse(config.sanctionScreen(type, java.util.Map.of(
                            "raison", ban.reason() != null ? ban.reason() : "Aucune raison",
                            "staff", ban.staffName() != null ? ban.staffName() : "Console",
                            "duree", duree,
                            "discord", config.infoLink("discord")))));
        }
    }

    private boolean isMaintenanceBypassed(AsyncPlayerPreLoginEvent event) {
        if (Bukkit.getOfflinePlayer(event.getUniqueId()).isOp()) return true;
        for (String whitelisted : plugin.getConfigManager().maintenanceWhitelist()) {
            if (whitelisted.equalsIgnoreCase(event.getName())) return true;
        }
        return plugin.getPunishmentManager().hasStaffRankBlocking(event.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        event.joinMessage(null); // messages de connexion geres manuellement pour un controle total
        var player = event.getPlayer();
        var uuid = player.getUniqueId();

        PlayerData data = new PlayerData(uuid, player.getName());
        plugin.putPlayerData(uuid, data);

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            boolean isNewPlayer = false;
            try (var connection = plugin.getDatabaseManager().getConnection()) {
                try (var check = connection.prepareStatement("SELECT 1 FROM b2c_players WHERE uuid = ?")) {
                    check.setString(1, uuid.toString());
                    try (var rs = check.executeQuery()) {
                        isNewPlayer = !rs.next();
                    }
                }
                if (isNewPlayer) {
                    try (var insert = connection.prepareStatement(
                            "INSERT INTO b2c_players (uuid, username, grade, first_join, last_login) VALUES (?,?,?,?,?)")) {
                        insert.setString(1, uuid.toString());
                        insert.setString(2, player.getName());
                        insert.setString(3, Grade.PAYSAN.key());
                        long now = System.currentTimeMillis();
                        insert.setLong(4, now);
                        insert.setLong(5, now);
                        insert.executeUpdate();
                    }
                } else {
                    try (var update = connection.prepareStatement(
                            "UPDATE b2c_players SET username = ?, last_login = ?, last_ip = ? WHERE uuid = ?")) {
                        update.setString(1, player.getName());
                        update.setLong(2, System.currentTimeMillis());
                        update.setString(3, player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : null);
                        update.setString(4, uuid.toString());
                        update.executeUpdate();
                    }
                }
                try (var select = connection.prepareStatement("SELECT * FROM b2c_players WHERE uuid = ?")) {
                    select.setString(1, uuid.toString());
                    try (var rs = select.executeQuery()) {
                        if (rs.next()) {
                            data.setGrade(Grade.fromKey(rs.getString("grade")) != null ? Grade.fromKey(rs.getString("grade")) : Grade.PAYSAN);
                            data.setStaffRank(StaffRank.fromKey(rs.getString("staff_rank")));
                            data.setBalance(rs.getDouble("balance"));
                            data.setPlaytimeSeconds(rs.getLong("playtime_seconds"));
                            data.setTitle(rs.getString("title"));
                            data.setFlyTimeRemainingSeconds(rs.getInt("fly_remaining_seconds"));
                            data.setFlyLastResetEpochDay(rs.getLong("fly_last_reset_day"));
                            data.setTutorialCompleted(rs.getBoolean("tutorial_completed"));
                            // team_id charge depuis TeamManager (source de verite : b2c_team_members),
                            // pas depuis la colonne b2c_players.team_id qui n'est jamais mise a jour.
                        }
                    }
                }
            } catch (Exception exception) {
                plugin.getLogger().log(Level.WARNING, "Erreur chargement joueur au join", exception);
            }
            var currentTeam = plugin.getTeamManager().getTeamOf(uuid);
            data.setTeamId(currentTeam != null ? currentTeam.getId() : null);

            boolean registered = plugin.getAuthManager().isRegisteredBlocking(uuid);
            data.setHasPasswordSet(registered);
            Punishment activeMute = plugin.getPunishmentManager().getActiveMuteBlocking(uuid);
            data.setMutedUntilMillis(activeMute == null ? 0L : (activeMute.isPermanent() ? -1L : activeMute.endMillis()));
            data.setMutedReason(activeMute == null ? null : activeMute.reason());

            boolean finalIsNewPlayer = isNewPlayer;
            boolean isBedrock = plugin.getBedrockSupport().isBedrockPlayer(uuid);
            boolean autoAuth = isBedrock && plugin.getConfigManager().bedrockAutoAuthenticate();

            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;

                // SECURITE : les permissions staff ne sont JAMAIS accordees ici, au join.
                // Le serveur tourne en mode offline (crack+premium) : n'importe qui peut se
                // connecter sous le pseudo d'un membre du staff tant qu'il n'a pas prouve son
                // identite avec /login. Les permissions ne sont appliquees qu'apres une
                // authentification reussie (voir AuthManager/AuthCommand), ou immediatement
                // pour les joueurs Bedrock authentifies automatiquement ci-dessous.
                if (data.getStaffRank() != null && !autoAuth) {
                    plugin.getAuthManager().alertStaffOfUnauthenticatedStaffAccount(player, data.getStaffRank());
                }

                plugin.getDisplayManager().applyTabSort(player, data);
                plugin.getDisplayManager().refreshTab(player);
                plugin.getDisplayManager().initScoreboard(player);
                plugin.getPlayerStateManager().applyVanishVisibility(player);

                if (plugin.getJailManager().isJailed(uuid)) {
                    var loc = plugin.getJailManager().getJailLocation(plugin.getJailManager().getState(uuid).jailName());
                    if (loc != null) player.teleport(loc);
                    player.sendMessage(TextUtil.parse("<red>Tu es toujours emprisonne."));
                }

                if (autoAuth) {
                    // Joueur Bedrock : pas de /register /login (Floodgate garantit deja
                    // l'identite via son propre systeme de comptes), authentification immediate.
                    plugin.getAuthManager().finalizeAuthentication(player);
                    player.sendMessage(TextUtil.parse("<aqua>Connexion Bedrock detectee : authentification automatique."));
                    if (finalIsNewPlayer) {
                        player.sendMessage(TextUtil.parse("<aqua>Bienvenue sur Block2BlockFr ! <gray>Tape <yellow>/tuto <gray>pour decouvrir le serveur."));
                    }
                } else {
                    sendAuthPrompt(player, registered, finalIsNewPlayer);
                }
            });

            plugin.getLocationManager().loadHomes(uuid, null);
            plugin.getSocialManager().loadIgnores(uuid, null);
            plugin.getQuestManager().loadPlayer(uuid, null);
        });
    }

    private void sendAuthPrompt(org.bukkit.entity.Player player, boolean registered, boolean isNewPlayer) {
        Component message = registered
                ? TextUtil.parse("<yellow><bold>CONNEXION REQUISE <gray>- <white>Tape <yellow>/login <motdepasse>")
                : TextUtil.parse("<yellow><bold>INSCRIPTION REQUISE <gray>- <white>Tape <yellow>/register <motdepasse> <motdepasse>");
        player.sendMessage(message);
        if (isNewPlayer) {
            player.sendMessage(TextUtil.parse("<aqua>Bienvenue sur Block2BlockFr ! <gray>Une fois connecte, tape <yellow>/tuto <gray>pour decouvrir le serveur."));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        event.quitMessage(null);
        var player = event.getPlayer();
        var uuid = player.getUniqueId();
        PlayerData data = plugin.getPlayerData(uuid);

        if (data != null) {
            plugin.getPlaytimeManager().persist(uuid, data.getPlaytimeSeconds());
            plugin.getPlayerStateManager().persistFlyBudget(uuid, data.getFlyTimeRemainingSeconds(), data.getFlyLastResetEpochDay());
        }
        plugin.getRankManager().clearAttachment(uuid);
        plugin.getAuthManager().resetLoginAttempts(uuid);
        plugin.getLocationManager().unloadHomes(uuid);
        plugin.getSocialManager().unloadIgnores(uuid);
        plugin.getQuestManager().unloadPlayer(uuid);
        plugin.removePlayerData(uuid);
    }
}
