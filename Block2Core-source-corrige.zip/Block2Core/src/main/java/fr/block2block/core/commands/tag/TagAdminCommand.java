package fr.block2block.core.commands.tag;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.TagDefinition;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /tagadmin : cree/gere les tags (utile pour des recompenses d'evenements, par exemple),
 * independamment des quetes. Un tag cree ici apparait immediatement dans l'interface /tag de
 * tous les joueurs (verrouille tant qu'il n'est pas attribue).
 * <p>
 * Usage :
 * /tagadmin create <nom_avec_underscores> <couleur> <description...>
 * /tagadmin give <joueur> <nom_avec_underscores>
 * /tagadmin remove <joueur> <nom_avec_underscores>
 * /tagadmin delete <nom_avec_underscores>
 * /tagadmin list
 */
public class TagAdminCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public TagAdminCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 1) {
            sendUsage(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "create" -> handleCreate(sender, args);
            case "give" -> handleGive(sender, args);
            case "remove" -> handleRemove(sender, args);
            case "delete" -> handleDelete(sender, args);
            case "list" -> handleList(sender);
            default -> sendUsage(sender);
        }
        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(TextUtil.parse("<yellow>Usage :"));
        sender.sendMessage(TextUtil.parse("<yellow>/tagadmin create <nom_avec_underscores> <couleur> <description...>"));
        sender.sendMessage(TextUtil.parse("<yellow>/tagadmin give <joueur> <nom_avec_underscores>"));
        sender.sendMessage(TextUtil.parse("<yellow>/tagadmin remove <joueur> <nom_avec_underscores>"));
        sender.sendMessage(TextUtil.parse("<yellow>/tagadmin delete <nom_avec_underscores>"));
        sender.sendMessage(TextUtil.parse("<yellow>/tagadmin list"));
    }

    /** Les noms de tag passent en argument avec des underscores a la place des espaces (ex Halloween_2026 -> "Halloween 2026"). */
    private String denormalizeName(String raw) {
        return raw.replace('_', ' ');
    }

    private String normalizeColor(String raw) {
        String trimmed = raw.trim();
        if (trimmed.startsWith("<") && trimmed.endsWith(">")) {
            return trimmed;
        }
        return "<" + trimmed + ">";
    }

    private void handleCreate(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tagadmin create <nom_avec_underscores> <couleur> <description...>"));
            return;
        }
        String name = denormalizeName(args[1]);
        String color = normalizeColor(args[2]);
        String description = String.join(" ", Arrays.copyOfRange(args, 3, args.length));

        plugin.getTagManager().defineTag(name, color, description, () ->
                sender.sendMessage(TextUtil.parse("<green>Tag cree/mis a jour : ")
                        .append(plugin.getTagManager().formatTag(name))
                        .append(TextUtil.parse("<gray> - " + description))));
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tagadmin give <joueur> <nom_avec_underscores>"));
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return;
        }
        String name = denormalizeName(args[2]);
        if (plugin.getTagManager().getTag(name) == null) {
            sender.sendMessage(TextUtil.parse("<red>Ce tag n'existe pas. Cree-le d'abord avec /tagadmin create."));
            return;
        }
        plugin.getTagManager().giveTag(target, name, () -> {
            sender.sendMessage(TextUtil.parse("<green>Tag ")
                    .append(plugin.getTagManager().formatTag(name))
                    .append(TextUtil.parse("<green> attribue a " + target.getName() + ".")));
            target.sendMessage(TextUtil.parse("<gray>Tu as recu un nouveau tag : ")
                    .append(plugin.getTagManager().formatTag(name))
                    .append(TextUtil.parse("<gray> - choisis-le avec /tag !")));
        });
    }

    private void handleRemove(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tagadmin remove <joueur> <nom_avec_underscores>"));
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return;
        }
        String name = denormalizeName(args[2]);
        boolean removed = plugin.getTagManager().removeTag(target, name);
        if (removed) {
            sender.sendMessage(TextUtil.parse("<green>Tag retire a " + target.getName() + "."));
        } else {
            sender.sendMessage(TextUtil.parse("<red>" + target.getName() + " n'a pas ce tag."));
        }
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /tagadmin delete <nom_avec_underscores>"));
            return;
        }
        String name = denormalizeName(args[1]);
        boolean deleted = plugin.getTagManager().deleteTag(name);
        sender.sendMessage(TextUtil.parse(deleted
                ? "<green>Tag \"" + name + "\" supprime (les joueurs qui l'avaient debloque le perdent)."
                : "<red>Aucun tag nomme \"" + name + "\"."));
    }

    private void handleList(CommandSender sender) {
        List<TagDefinition> tags = plugin.getTagManager().getAllTags();
        if (tags.isEmpty()) {
            sender.sendMessage(TextUtil.parse("<yellow>Aucun tag defini."));
            return;
        }
        sender.sendMessage(TextUtil.parse("<aqua><bold>Tags (" + tags.size() + ") :"));
        for (TagDefinition tag : tags) {
            sender.sendMessage(TextUtil.parse("<gray>- ")
                    .append(plugin.getTagManager().formatTag(tag.name()))
                    .append(TextUtil.parse("<gray> (" + tag.color() + ") - " +
                            (tag.description() != null ? tag.description() : "sans description"))));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("create", "give", "remove", "delete", "list"), args[0]);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("remove"))) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
