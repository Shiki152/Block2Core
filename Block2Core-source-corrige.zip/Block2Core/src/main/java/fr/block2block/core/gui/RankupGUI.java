package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

/**
 * Interface graphique pour /rankup : affiche la progression du joueur dans les 5 grades
 * (Paysan -> Aventurier -> Aguerris -> Master -> Partenaire), avec pour chacun son statut
 * (obtenu / actuel / prochain avec conditions / verrouille), et un bouton central qui valide
 * le rankup si les conditions (cout en Block2Coins + temps de jeu) sont remplies.
 * <p>
 * Reutilise integralement la logique deja existante de RankManager#rankup() (memes messages
 * d'erreur, meme broadcast, memes verifications) : cette interface n'est qu'une couche
 * visuelle par-dessus, /rankup en ligne de commande n'existe plus separement.
 */
public class RankupGUI implements Listener {

    private static final int PROFILE_SLOT = 4;
    private static final int[] PATH_SLOTS = {11, 12, 13, 14, 15};
    private static final int CONFIRM_SLOT = 22;

    private final Block2Core plugin;

    public RankupGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data == null) return;

        Grade current = data.getGrade();
        Grade next = current.next();

        Inventory inventory = plugin.getServer().createInventory(new RankupHolder(), 27,
                TextUtil.parse("<gold><bold>Progression de grade"));

        ItemStack filler = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < 27; i++) {
            inventory.setItem(i, filler);
        }

        inventory.setItem(PROFILE_SLOT, buildProfileItem(player, data, current));

        Grade[] order = Grade.values();
        for (int i = 0; i < order.length && i < PATH_SLOTS.length; i++) {
            inventory.setItem(PATH_SLOTS[i], buildGradeItem(order[i], current, next, data));
        }

        inventory.setItem(CONFIRM_SLOT, buildConfirmItem(data, current, next));

        player.openInventory(inventory);
    }

    private ItemStack buildProfileItem(Player player, PlayerData data, Grade current) {
        return new ItemBuilder(Material.PLAYER_HEAD)
                .skullOwner(player.getName())
                .name("<gold><bold>" + player.getName())
                .loreLine(" ")
                .loreLine("<gray>Grade actuel : " + plugin.getConfigManager().gradeColor(current) +
                        plugin.getConfigManager().gradeDisplayName(current))
                .loreLine("<gray>Temps de jeu : <white>" + TimeUtil.formatHoursMinutes(data.getPlaytimeSeconds()))
                .loreLine("<gray>Solde : <gold>" + (long) data.getBalance() + " Block2Coins")
                .build();
    }

    private ItemStack buildGradeItem(Grade grade, Grade current, Grade next, PlayerData data) {
        String color = plugin.getConfigManager().gradeColor(grade);
        String displayName = plugin.getConfigManager().gradeDisplayName(grade);

        if (grade.ordinal() < current.ordinal()) {
            return new ItemBuilder(Material.LIME_STAINED_GLASS_PANE)
                    .name(color + "<bold>" + displayName)
                    .loreLine("<green>✔ Grade obtenu")
                    .build();
        }
        if (grade == current) {
            return new ItemBuilder(Material.YELLOW_STAINED_GLASS_PANE)
                    .glow(true)
                    .name(color + "<bold>" + displayName + " <gray>(actuel)")
                    .loreLine("<yellow>➡ Ton grade actuel")
                    .build();
        }
        if (grade == next) {
            double cost = plugin.getConfigManager().rankupCost(grade);
            long required = plugin.getConfigManager().rankupPlaytimeSeconds(grade);
            boolean hasMoney = data.getBalance() >= cost;
            boolean hasPlaytime = data.getPlaytimeSeconds() >= required;

            ItemBuilder builder = new ItemBuilder(hasMoney && hasPlaytime ? Material.EMERALD : Material.COAL)
                    .name(color + "<bold>" + displayName + " <gray>(prochain)")
                    .loreLine(" ")
                    .loreLine((hasMoney ? "<green>✔ " : "<red>✘ ") + "Cout : " + (long) cost + " Block2Coins")
                    .loreLine((hasPlaytime ? "<green>✔ " : "<red>✘ ") + "Temps de jeu requis : " + TimeUtil.formatShort(required));
            if (!hasPlaytime) {
                builder.loreLine("<gray>  (encore " + TimeUtil.formatShort(required - data.getPlaytimeSeconds()) + ")");
            }
            return builder.build();
        }
        return new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE)
                .name("<dark_gray><bold>" + displayName)
                .loreLine("<dark_gray>🔒 Verrouille")
                .build();
    }

    private ItemStack buildConfirmItem(PlayerData data, Grade current, Grade next) {
        if (next == null) {
            return new ItemBuilder(Material.NETHER_STAR)
                    .glow(true)
                    .name("<light_purple><bold>Grade maximum atteint !")
                    .loreLine("<gray>Tu es deja " + plugin.getConfigManager().gradeDisplayName(current) + ".")
                    .build();
        }

        double cost = plugin.getConfigManager().rankupCost(next);
        long required = plugin.getConfigManager().rankupPlaytimeSeconds(next);
        boolean hasMoney = data.getBalance() >= cost;
        boolean hasPlaytime = data.getPlaytimeSeconds() >= required;
        boolean eligible = hasMoney && hasPlaytime;

        ItemBuilder builder = new ItemBuilder(eligible ? Material.EMERALD_BLOCK : Material.REDSTONE_BLOCK)
                .glow(eligible)
                .name(eligible
                        ? "<green><bold>PASSER " + plugin.getConfigManager().gradeDisplayName(next).toUpperCase() + " !"
                        : "<red><bold>Conditions non remplies")
                .loreLine(" ");
        if (!hasMoney) {
            builder.loreLine("<red>Il te manque " + (long) Math.ceil(cost - data.getBalance()) + " Block2Coins");
        }
        if (!hasPlaytime) {
            builder.loreLine("<red>Il te manque " + TimeUtil.formatShort(required - data.getPlaytimeSeconds()) + " de jeu");
        }
        if (eligible) {
            builder.loreLine("<yellow>Clique pour valider ton rankup !");
        }
        return builder.build();
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof RankupHolder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !(event.getClickedInventory().getHolder() instanceof RankupHolder)) return;
        if (event.getSlot() != CONFIRM_SLOT) return;

        Player player = (Player) event.getWhoClicked();
        plugin.getRankManager().rankup(player);
        // Rankup() met a jour grade/solde en memoire de facon synchrone avant de retourner :
        // on peut donc reconstruire l'inventaire immediatement pour refleter le nouvel etat.
        Bukkit.getScheduler().runTask(plugin, () -> open(player));
    }

    public static class RankupHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
