package fr.block2block.core.util;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

/**
 * Serialise/deserialise des tableaux d'ItemStack en base64 (encodage texte, stockable
 * directement dans une colonne SQLite). Utilise pour sauvegarder l'inventaire de survie
 * d'un joueur en base lors d'un /staffmode (voir PlayerStateManager), afin qu'il resiste
 * a un crash serveur ou une deconnexion pendant la session staff.
 */
public final class InventorySerializer {

    private InventorySerializer() {
    }

    public static String toBase64(ItemStack[] items) {
        try (ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
             BukkitObjectOutputStream dataStream = new BukkitObjectOutputStream(byteStream)) {
            dataStream.writeInt(items.length);
            for (ItemStack item : items) {
                dataStream.writeObject(item);
            }
            dataStream.flush();
            return Base64.getEncoder().encodeToString(byteStream.toByteArray());
        } catch (Exception exception) {
            throw new IllegalStateException("Erreur serialisation inventaire", exception);
        }
    }

    public static ItemStack[] fromBase64(String base64) {
        if (base64 == null || base64.isBlank()) {
            return new ItemStack[0];
        }
        try (ByteArrayInputStream byteStream = new ByteArrayInputStream(Base64.getDecoder().decode(base64));
             BukkitObjectInputStream dataStream = new BukkitObjectInputStream(byteStream)) {
            int length = dataStream.readInt();
            ItemStack[] items = new ItemStack[length];
            for (int i = 0; i < length; i++) {
                items[i] = (ItemStack) dataStream.readObject();
            }
            return items;
        } catch (Exception exception) {
            throw new IllegalStateException("Erreur deserialisation inventaire", exception);
        }
    }
}
