package fr.block2block.core.commands.economy;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class B2CAdminCommand implements CommandExecutor, TabCompleter {

    private final Block2Core plugin;

    public B2CAdminCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /b2c <give|take|set|top> <joueur> [montant]"));
            return true;
        }

        if (args[0].equalsIgnoreCase("top")) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                var top = plugin.getEconomyManager().getTopBlocking(10);
                Bukkit.getScheduler().runTask(plugin, () -> {
                    sender.sendMessage(TextUtil.parse("<gold><bold>--- TOP 10 BLOCK2COINS ---"));
                    int pos = 1;
                    for (var entry : top) {
                        sender.sendMessage(TextUtil.parse("<gray>#" + pos + " <white>" + entry.name() + " <gray>: <gold>" +
                                String.format("%,.0f", entry.balance()) + " Block2Coins"));
                        pos++;
                    }
                });
            });
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /b2c <give|take|set> <joueur> <montant>"));
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException exception) {
            sender.sendMessage(plugin.getConfigManager().messageComponent("not-a-number", Map.of("valeur", args[2])));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give" -> {
                plugin.getEconomyManager().deposit(target.getUniqueId(), amount);
                sender.sendMessage(TextUtil.parse("<green>+" + (long) amount + " Block2Coins pour " + target.getName()));
            }
            case "take" -> {
                plugin.getEconomyManager().withdraw(target.getUniqueId(), amount);
                sender.sendMessage(TextUtil.parse("<green>-" + (long) amount + " Block2Coins pour " + target.getName()));
            }
            case "set" -> {
                plugin.getEconomyManager().setBalance(target.getUniqueId(), amount);
                sender.sendMessage(TextUtil.parse("<green>Solde de " + target.getName() + " fixe a " + (long) amount + " Block2Coins"));
            }
            default -> sender.sendMessage(TextUtil.parse("<yellow>Usage : /b2c <give|take|set|top> <joueur> [montant]"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("give", "take", "set", "top").stream()
                    .filter(o -> o.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
