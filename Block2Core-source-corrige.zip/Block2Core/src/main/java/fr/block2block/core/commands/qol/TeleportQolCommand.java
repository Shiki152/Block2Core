package fr.block2block.core.commands.qol;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.Grade;
import fr.block2block.core.data.Home;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.Warp;
import fr.block2block.core.managers.LocationManager;
import fr.block2block.core.managers.SocialManager;
import fr.block2block.core.util.TextUtil;
import fr.block2block.core.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.security.SecureRandom;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Dispatcher pour les commandes de teleportation "QOL" : spawn, home,
 * sethome, delhome, warp, setwarp, delwarp, tpa, tpaccept, tpdeny, rtp.
 */
public class TeleportQolCommand implements CommandExecutor, TabCompleter {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String DEFAULT_HOME = "home";

    private final Block2Core plugin;

    public TeleportQolCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase()) {
            case "spawn" -> spawn(sender);
            case "setspawn" -> setspawn(sender);
            case "home" -> home(sender, args);
            case "sethome" -> sethome(sender, args);
            case "delhome" -> delhome(sender, args);
            case "warp" -> warp(sender, args);
            case "setwarp" -> setwarp(sender, args);
            case "delwarp" -> delwarp(sender, args);
            case "tpa" -> tpa(sender, args);
            case "tpaccept" -> tpaccept(sender);
            case "tpdeny" -> tpdeny(sender);
            case "rtp" -> rtp(sender);
            default -> false;
        };
    }

    private boolean spawn(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        Location spawnLocation = plugin.getConfigManager().hasCustomSpawn()
                ? plugin.getConfigManager().getCustomSpawn()
                : Bukkit.getWorlds().get(0).getSpawnLocation();
        plugin.getSocialManager().saveBackLocation(player);
        player.teleport(spawnLocation);
        player.sendMessage(TextUtil.parse("<green>Teleporte au spawn."));
        return true;
    }

    private boolean setspawn(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getConfigManager().setCustomSpawn(player.getLocation());
        plugin.getClaimManager().protectAroundLocation(player.getLocation(), 1);
        player.sendMessage(TextUtil.parse("<green>Spawn du serveur defini ici ! <gray>(zone alentour automatiquement protegee)"));
        return true;
    }

    private boolean home(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        String name = args.length > 0 ? args[0] : DEFAULT_HOME;
        Home home = plugin.getLocationManager().getHome(player.getUniqueId(), name);
        if (home == null) {
            player.sendMessage(TextUtil.parse("<red>Home introuvable : " + name));
            return true;
        }
        Location location = LocationManager.toLocation(home);
        if (location == null) {
            player.sendMessage(TextUtil.parse("<red>Le monde de cette home n'existe plus."));
            return true;
        }
        plugin.getSocialManager().saveBackLocation(player);
        player.teleport(location);
        player.sendMessage(TextUtil.parse("<green>Teleporte a la home " + name));
        return true;
    }

    private boolean sethome(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        String name = args.length > 0 ? args[0] : DEFAULT_HOME;
        plugin.getLocationManager().setHome(player, name, () -> player.sendMessage(TextUtil.parse("<green>Home " + name + " definie ici.")));
        return true;
    }

    private boolean delhome(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /delhome <nom>"));
            return true;
        }
        plugin.getLocationManager().deleteHome(player.getUniqueId(), args[0],
                () -> player.sendMessage(TextUtil.parse("<green>Home " + args[0] + " supprimee.")));
        return true;
    }

    private boolean warp(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(TextUtil.parse("<aqua><bold>--- WARPS DISPONIBLES ---"));
            for (String name : plugin.getLocationManager().getWarps().keySet()) {
                player.sendMessage(TextUtil.parse("<gray>- <white>" + name));
            }
            return true;
        }
        Warp warp = plugin.getLocationManager().getWarp(args[0]);
        if (warp == null) {
            player.sendMessage(TextUtil.parse("<red>Warp introuvable : " + args[0]));
            return true;
        }
        Location location = LocationManager.toLocation(warp);
        if (location == null) {
            player.sendMessage(TextUtil.parse("<red>Le monde de ce warp n'existe plus."));
            return true;
        }
        plugin.getSocialManager().saveBackLocation(player);
        player.teleport(location);
        player.sendMessage(TextUtil.parse("<green>Teleporte au warp " + args[0]));
        return true;
    }

    private boolean setwarp(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /setwarp <nom>"));
            return true;
        }
        plugin.getLocationManager().setWarp(args[0], player.getLocation(), player.getName(),
                () -> player.sendMessage(TextUtil.parse("<green>Warp " + args[0] + " cree.")));
        return true;
    }

    private boolean delwarp(CommandSender sender, String[] args) {
        if (args.length < 1) {
            sender.sendMessage(TextUtil.parse("<yellow>Usage : /delwarp <nom>"));
            return true;
        }
        plugin.getLocationManager().deleteWarp(args[0], () -> sender.sendMessage(TextUtil.parse("<green>Warp " + args[0] + " supprime.")));
        return true;
    }

    private boolean tpa(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /tpa <joueur>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(plugin.getConfigManager().messageComponent("player-not-online", null));
            return true;
        }
        plugin.getSocialManager().createTpaRequest(player.getUniqueId(), target.getUniqueId());
        player.sendMessage(TextUtil.parse("<green>Demande envoyee a " + target.getName()));
        target.sendMessage(TextUtil.parse("<aqua>" + player.getName() + " souhaite se teleporter a toi. <yellow>/tpaccept <gray>ou <yellow>/tpdeny"));
        return true;
    }

    private boolean tpaccept(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        SocialManager.TpaRequest request = plugin.getSocialManager().getTpaRequest(player.getUniqueId());
        if (request == null) {
            player.sendMessage(TextUtil.parse("<red>Aucune demande en attente."));
            return true;
        }
        Player requester = Bukkit.getPlayer(request.requester());
        plugin.getSocialManager().clearTpaRequest(player.getUniqueId());
        if (requester == null) {
            player.sendMessage(TextUtil.parse("<red>Ce joueur n'est plus connecte."));
            return true;
        }
        plugin.getSocialManager().saveBackLocation(requester);
        requester.teleport(player);
        requester.sendMessage(TextUtil.parse("<green>Demande acceptee par " + player.getName()));
        player.sendMessage(TextUtil.parse("<green>Tu as accepte la demande de " + requester.getName()));
        return true;
    }

    private boolean tpdeny(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        plugin.getSocialManager().clearTpaRequest(player.getUniqueId());
        player.sendMessage(TextUtil.parse("<gray>Demande refusee."));
        return true;
    }

    private boolean rtp(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        Grade minGrade = plugin.getConfigManager().rtpMinGrade();
        boolean isStaff = player.hasPermission("block2core.staff");
        boolean allowed = isStaff || (data != null && data.getGrade().ordinal() >= minGrade.ordinal());
        if (!allowed) {
            player.sendMessage(TextUtil.parse("<red>Le RTP est reserve au grade " + plugin.getConfigManager().gradeDisplayName(minGrade) + " et plus."));
            return true;
        }

        long cooldownSeconds = plugin.getConfigManager().rtpCooldownMinutes() * 60L;
        long lastUse = plugin.getSocialManager().getRtpLastUse(player.getUniqueId());
        if (lastUse > 0 && !isStaff) {
            long elapsed = (System.currentTimeMillis() - lastUse) / 1000L;
            if (elapsed < cooldownSeconds) {
                player.sendMessage(TextUtil.parse("<red>RTP disponible dans " + TimeUtil.formatShort(cooldownSeconds - elapsed)));
                return true;
            }
        }

        int radius = plugin.getConfigManager().rtpRadius();
        World world = player.getWorld();
        int x = RANDOM.nextInt(radius * 2) - radius;
        int z = RANDOM.nextInt(radius * 2) - radius;
        int y = world.getHighestBlockYAt(x, z) + 1;

        plugin.getSocialManager().setRtpLastUse(player.getUniqueId());
        plugin.getSocialManager().saveBackLocation(player);
        player.teleport(new Location(world, x + 0.5, y, z + 0.5));
        player.sendMessage(TextUtil.parse("<green>Teleportation aleatoire effectuee !"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String cmdName = command.getName().toLowerCase();
        if (args.length == 1 && cmdName.equals("home") && sender instanceof Player player) {
            return filter(plugin.getLocationManager().getHomes(player.getUniqueId()).keySet().stream().toList(), args[0]);
        }
        if (args.length == 1 && cmdName.equals("warp")) {
            return filter(plugin.getLocationManager().getWarps().keySet().stream().toList(), args[0]);
        }
        if (args.length == 1 && cmdName.equals("tpa")) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[0]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String input) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(input.toLowerCase())).collect(Collectors.toList());
    }
}
