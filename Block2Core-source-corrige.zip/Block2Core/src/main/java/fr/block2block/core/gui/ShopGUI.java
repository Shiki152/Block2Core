package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Boutique en Block2Coins (/shop). Le cahier des charges ne precisait pas
 * le contenu exact de la boutique : la liste ci-dessous est un exemple
 * concret et fonctionnel, a adapter facilement (ajoute/retire des entrees
 * dans OFFERS pour changer le catalogue).
 */
public class ShopGUI implements Listener {

    private final Block2Core plugin;

    private record Offer(Material material, int amount, double price, String displayName) {
    }

    private static final Map<Integer, Offer> OFFERS = new LinkedHashMap<>();

    static {
        OFFERS.put(10, new Offer(Material.EXPERIENCE_BOTTLE, 16, 200, "<green>16x Fiole d'experience"));
        OFFERS.put(11, new Offer(Material.SADDLE, 1, 150, "<gold>Selle"));
        OFFERS.put(12, new Offer(Material.NAME_TAG, 1, 100, "<white>Etiquette"));
        OFFERS.put(13, new Offer(Material.ENDER_PEARL, 4, 300, "<light_purple>4x Perle d'Ender"));
        OFFERS.put(14, new Offer(Material.GOLDEN_APPLE, 2, 500, "<yellow>2x Pomme doree"));
        OFFERS.put(15, new Offer(Material.FIREWORK_ROCKET, 8, 80, "<red>8x Feu d'artifice"));
        OFFERS.put(16, new Offer(Material.OAK_BOAT, 1, 120, "<dark_green>Barque en bois"));
        OFFERS.put(20, new Offer(Material.DIAMOND, 5, 1200, "<aqua>5x Diamant"));
        OFFERS.put(21, new Offer(Material.NETHERITE_INGOT, 1, 3000, "<dark_purple>Lingot de Netherite"));
        OFFERS.put(22, new Offer(Material.SHULKER_BOX, 1, 2500, "<gray>Shulker Box"));
    }

    public ShopGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inventory = plugin.getServer().createInventory(new ShopHolder(), 27, TextUtil.parse("<gold><bold>Boutique Block2Coins"));

        ItemStack filler = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < 27; i++) {
            inventory.setItem(i, filler);
        }
        for (Map.Entry<Integer, Offer> entry : OFFERS.entrySet()) {
            Offer offer = entry.getValue();
            ItemStack item = new ItemBuilder(offer.material(), offer.amount())
                    .name(offer.displayName())
                    .loreLine("<gray>Prix : <gold>" + (long) offer.price() + " Block2Coins")
                    .loreLine("<yellow>Clique pour acheter")
                    .build();
            inventory.setItem(entry.getKey(), item);
        }
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof ShopHolder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !(event.getClickedInventory().getHolder() instanceof ShopHolder)) return;

        Offer offer = OFFERS.get(event.getSlot());
        if (offer == null) return;
        Player player = (Player) event.getWhoClicked();

        double balance = plugin.getEconomyManager().getBalance(player.getUniqueId());
        if (balance < offer.price()) {
            player.sendMessage(TextUtil.parse("<red>Solde insuffisant ! Il te manque <white>" +
                    (long) (offer.price() - balance) + " Block2Coins<red>."));
            return;
        }
        plugin.getEconomyManager().withdraw(player.getUniqueId(), offer.price());
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack(offer.material(), offer.amount()));
        leftover.values().forEach(extra -> player.getWorld().dropItemNaturally(player.getLocation(), extra));
        player.sendMessage(TextUtil.parse("<green>Achat effectue : ").append(TextUtil.parse(offer.displayName())));
    }

    public static class ShopHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
