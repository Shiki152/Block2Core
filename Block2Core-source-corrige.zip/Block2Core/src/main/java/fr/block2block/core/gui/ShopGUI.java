package fr.block2block.core.gui;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.ItemBuilder;
import fr.block2block.core.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

/**
 * Boutique en Block2Coins (/shop), organisee en 6 categories avec pres de 50 objets au total.
 * Les prix restent calibres sur l'echelle economique du serveur (rankup Aguerris 5 000,
 * Master 25 000, Partenaire 100 000 Block2Coins) : les objets les plus puissants sont des
 * achats de prestige a long terme. Certains objets "grail" de la categorie Objets rares
 * restent en plus reserves a partir d'un grade minimum (voir GradeTiers), independamment du
 * prix : un joueur qui n'a pas encore le grade requis les voit grises.
 */
public class ShopGUI implements Listener {

    private static final int[] CATEGORY_SLOTS = {10, 12, 14, 19, 21, 23};
    private static final int[] ITEM_SLOTS = buildRange(0, 36); // 4 lignes pleines, la 5e est reservee a "Retour"
    private static final int BACK_SLOT = 40;
    private static final int GRID_SIZE = 45;

    private final Block2Core plugin;

    private record Offer(Material material, int amount, double price, String displayName,
                          String requiredPermission, String unlockHint) {
        Offer(Material material, int amount, double price, String displayName) {
            this(material, amount, price, displayName, null, null);
        }
    }

    private record Category(String id, String displayName, Material icon, List<Offer> offers) {
    }

    private static int[] buildRange(int start, int count) {
        int[] slots = new int[count];
        for (int i = 0; i < count; i++) slots[i] = start + i;
        return slots;
    }

    private static final List<Category> CATEGORIES = List.of(
            new Category("resources", "<aqua><bold>Ressources", Material.DIAMOND, List.of(
                    new Offer(Material.IRON_INGOT, 16, 200, "<white>16x Lingot de fer"),
                    new Offer(Material.GOLD_INGOT, 16, 400, "<gold>16x Lingot d'or"),
                    new Offer(Material.COPPER_INGOT, 16, 200, "<gold>16x Lingot de cuivre"),
                    new Offer(Material.DIAMOND, 1, 600, "<aqua>1x Diamant"),
                    new Offer(Material.EMERALD, 4, 800, "<green>4x Emeraude"),
                    new Offer(Material.LAPIS_LAZULI, 32, 250, "<blue>32x Lapis-lazuli"),
                    new Offer(Material.REDSTONE, 32, 200, "<red>32x Redstone"),
                    new Offer(Material.COAL, 32, 150, "<dark_gray>32x Charbon"),
                    new Offer(Material.NETHERITE_INGOT, 1, 15000, "<dark_purple>1x Lingot de Netherite")
            )),
            new Category("blocks", "<gold><bold>Blocs de construction", Material.BRICKS, List.of(
                    new Offer(Material.GLASS, 64, 300, "<white>64x Verre"),
                    new Offer(Material.WHITE_TERRACOTTA, 64, 300, "<white>64x Terracotta blanche"),
                    new Offer(Material.QUARTZ_BLOCK, 64, 500, "<white>64x Bloc de quartz"),
                    new Offer(Material.PRISMARINE, 64, 500, "<aqua>64x Prismarine"),
                    new Offer(Material.WHITE_WOOL, 64, 250, "<white>64x Laine blanche"),
                    new Offer(Material.SMOOTH_STONE, 64, 250, "<gray>64x Pierre lisse"),
                    new Offer(Material.WHITE_CONCRETE, 64, 400, "<white>64x Beton blanc"),
                    new Offer(Material.OBSIDIAN, 16, 1200, "<dark_purple>16x Obsidienne")
            )),
            new Category("consumables", "<green><bold>Consommables", Material.GOLDEN_APPLE, List.of(
                    new Offer(Material.BREAD, 16, 100, "<gold>16x Pain"),
                    new Offer(Material.COOKED_BEEF, 16, 150, "<red>16x Steak cuit"),
                    new Offer(Material.EXPERIENCE_BOTTLE, 16, 300, "<green>16x Fiole d'experience"),
                    new Offer(Material.GOLDEN_CARROT, 8, 400, "<gold>8x Carotte doree"),
                    new Offer(Material.CAKE, 1, 400, "<white>1x Gateau"),
                    new Offer(Material.MILK_BUCKET, 5, 200, "<white>5x Seau de lait"),
                    new Offer(Material.GOLDEN_APPLE, 1, 800, "<yellow>1x Pomme doree"),
                    new Offer(Material.ENCHANTED_GOLDEN_APPLE, 1, 10000, "<light_purple>1x Pomme doree enchantee")
            )),
            new Category("gear", "<red><bold>Outils & Armures", Material.DIAMOND_SWORD, List.of(
                    new Offer(Material.FISHING_ROD, 1, 400, "<gold>1x Canne a peche"),
                    new Offer(Material.BOW, 1, 500, "<white>1x Arc"),
                    new Offer(Material.SHIELD, 1, 500, "<white>1x Bouclier"),
                    new Offer(Material.IRON_SWORD, 1, 300, "<white>1x Epee en fer"),
                    new Offer(Material.DIAMOND_SWORD, 1, 1500, "<aqua>1x Epee en diamant"),
                    new Offer(Material.DIAMOND_PICKAXE, 1, 1500, "<aqua>1x Pioche en diamant"),
                    new Offer(Material.DIAMOND_CHESTPLATE, 1, 2500, "<aqua>1x Plastron en diamant"),
                    new Offer(Material.NETHERITE_CHESTPLATE, 1, 20000, "<dark_purple>1x Plastron en Netherite")
            )),
            new Category("utility", "<yellow><bold>Utilitaire", Material.ENDER_PEARL, List.of(
                    new Offer(Material.LEAD, 2, 150, "<white>2x Laisse"),
                    new Offer(Material.NAME_TAG, 1, 200, "<white>1x Etiquette"),
                    new Offer(Material.CLOCK, 1, 150, "<gold>1x Horloge"),
                    new Offer(Material.OAK_BOAT, 1, 200, "<dark_green>1x Barque en bois"),
                    new Offer(Material.FIREWORK_ROCKET, 8, 150, "<red>8x Feu d'artifice"),
                    new Offer(Material.SADDLE, 1, 300, "<gold>1x Selle"),
                    new Offer(Material.SPYGLASS, 1, 400, "<white>1x Longue-vue"),
                    new Offer(Material.ENDER_PEARL, 4, 500, "<light_purple>4x Perle d'Ender"),
                    new Offer(Material.BUNDLE, 1, 600, "<gold>1x Bundle")
            )),
            new Category("rare", "<dark_purple><bold>Objets rares", Material.SHULKER_BOX, List.of(
                    new Offer(Material.WITHER_SKELETON_SKULL, 1, 5000, "<gray>1x Tete de Wither Skeleton",
                            "block2core.grade.perk.shop.rare", "Aguerris"),
                    new Offer(Material.HEART_OF_THE_SEA, 1, 6000, "<aqua>1x Coeur de la mer",
                            "block2core.grade.perk.shop.rare", "Aguerris"),
                    new Offer(Material.SHULKER_BOX, 1, 8000, "<gray>1x Shulker Box",
                            "block2core.grade.perk.shop.rare", "Aguerris"),
                    new Offer(Material.BEACON, 1, 40000, "<aqua>1x Balise (Beacon)",
                            "block2core.grade.perk.shop.legendary", "Master"),
                    new Offer(Material.TOTEM_OF_UNDYING, 1, 20000, "<yellow>1x Totem d'Immortalite",
                            "block2core.grade.perk.shop.legendary", "Master"),
                    new Offer(Material.ELYTRA, 1, 60000, "<light_purple>1x Elytre",
                            "block2core.grade.perk.shop.legendary", "Master")
            ))
    );

    public ShopGUI(Block2Core plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inventory = plugin.getServer().createInventory(new ShopMainHolder(), 27,
                TextUtil.parse("<gold><bold>Boutique Block2Coins"));

        ItemStack filler = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < 27; i++) {
            inventory.setItem(i, filler);
        }

        for (int i = 0; i < CATEGORIES.size() && i < CATEGORY_SLOTS.length; i++) {
            Category category = CATEGORIES.get(i);
            inventory.setItem(CATEGORY_SLOTS[i], new ItemBuilder(category.icon())
                    .name(category.displayName())
                    .loreLine("<gray>" + category.offers().size() + " objet(s)")
                    .loreLine(" ")
                    .loreLine("<yellow>Clique pour ouvrir")
                    .build());
        }
        player.openInventory(inventory);
    }

    private void openCategory(Player player, String categoryId) {
        Category category = findCategory(categoryId);
        if (category == null) return;

        Inventory inventory = plugin.getServer().createInventory(new ShopCategoryHolder(categoryId), GRID_SIZE,
                TextUtil.parse(category.displayName()));

        ItemStack filler = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < GRID_SIZE; i++) {
            inventory.setItem(i, filler);
        }

        List<Offer> offers = category.offers();
        for (int i = 0; i < offers.size() && i < ITEM_SLOTS.length; i++) {
            inventory.setItem(ITEM_SLOTS[i], buildOfferItem(player, offers.get(i)));
        }
        inventory.setItem(BACK_SLOT, new ItemBuilder(Material.ARROW).name("<gray>« Retour").build());
        player.openInventory(inventory);
    }

    private Category findCategory(String id) {
        for (Category category : CATEGORIES) {
            if (category.id().equals(id)) return category;
        }
        return null;
    }

    private ItemStack buildOfferItem(Player player, Offer offer) {
        boolean locked = offer.requiredPermission() != null && !player.hasPermission(offer.requiredPermission());
        if (locked) {
            String plainName = offer.displayName().replaceAll("<[^>]+>", "");
            return new ItemBuilder(Material.BARRIER)
                    .name("<dark_gray>" + plainName)
                    .loreLine("<dark_gray>🔒 Reserve au grade <white>" + offer.unlockHint() + "+")
                    .loreLine("<gray>Prix : <gold>" + (long) offer.price() + " Block2Coins")
                    .build();
        }
        return new ItemBuilder(offer.material(), offer.amount())
                .name(offer.displayName())
                .loreLine("<gray>Prix : <gold>" + (long) offer.price() + " Block2Coins")
                .loreLine("<yellow>Clique pour acheter")
                .build();
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof ShopMainHolder) && !(holder instanceof ShopCategoryHolder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || event.getClickedInventory().getHolder() != holder) return;

        Player player = (Player) event.getWhoClicked();

        if (holder instanceof ShopMainHolder) {
            int index = indexOf(CATEGORY_SLOTS, event.getSlot());
            if (index < 0 || index >= CATEGORIES.size()) return;
            openCategory(player, CATEGORIES.get(index).id());
            return;
        }

        ShopCategoryHolder categoryHolder = (ShopCategoryHolder) holder;
        if (event.getSlot() == BACK_SLOT) {
            open(player);
            return;
        }
        int index = indexOf(ITEM_SLOTS, event.getSlot());
        if (index < 0) return;
        Category category = findCategory(categoryHolder.categoryId());
        if (category == null || index >= category.offers().size()) return;

        purchase(player, category.offers().get(index));
        // Rafraichir la categorie (solde/deblocage a jour) plutot que de fermer le menu.
        openCategory(player, categoryHolder.categoryId());
    }

    private int indexOf(int[] slots, int slot) {
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == slot) return i;
        }
        return -1;
    }

    private void purchase(Player player, Offer offer) {
        if (offer.requiredPermission() != null && !player.hasPermission(offer.requiredPermission())) {
            player.sendMessage(TextUtil.parse("<red>Cet objet est reserve au grade " + offer.unlockHint() + "+."));
            return;
        }
        double balance = plugin.getEconomyManager().getBalance(player.getUniqueId());
        if (balance < offer.price()) {
            player.sendMessage(TextUtil.parse("<red>Solde insuffisant ! Il te manque <white>" +
                    (long) (offer.price() - balance) + " Block2Coins<red>."));
            return;
        }
        plugin.getEconomyManager().withdraw(player.getUniqueId(), offer.price());
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack(offer.material(), offer.amount()));
        leftover.values().forEach(extra -> player.getWorld().dropItemNaturally(player.getLocation(), extra));
        player.sendMessage(TextUtil.parse("<green>Achat effectue : ").append(TextUtil.parse(offer.displayName())));
    }

    public static class ShopMainHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }

    public static class ShopCategoryHolder implements InventoryHolder {
        private final String categoryId;

        public ShopCategoryHolder(String categoryId) {
            this.categoryId = categoryId;
        }

        public String categoryId() {
            return categoryId;
        }

        @Override
        public Inventory getInventory() {
            throw new UnsupportedOperationException("Marqueur uniquement");
        }
    }
}
