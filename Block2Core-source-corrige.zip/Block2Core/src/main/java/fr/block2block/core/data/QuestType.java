package fr.block2block.core.data;

/**
 * Type d'objectif d'une quete. CUSTOM = validee manuellement par le staff.
 */
public enum QuestType {
    BLOCK_BREAK,
    BLOCK_PLACE,
    MOB_KILL,
    CUSTOM
}
