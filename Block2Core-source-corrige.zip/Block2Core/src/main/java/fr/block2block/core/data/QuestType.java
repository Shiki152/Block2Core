package fr.block2block.core.data;

/**
 * Type d'objectif d'une quete. Toutes les quetes du serveur sont suivies automatiquement
 * (plus de type CUSTOM valide manuellement : les 90 quetes fournies par defaut n'en ont pas
 * besoin, voir QuestManager).
 */
public enum QuestType {
    BLOCK_BREAK,
    BLOCK_PLACE,
    MOB_KILL
}
