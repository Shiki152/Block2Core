package fr.block2block.core.listeners;

import fr.block2block.core.Block2Core;
import fr.block2block.core.data.ClaimChunk;
import fr.block2block.core.data.PlayerData;
import fr.block2block.core.data.PlayerTeam;
import fr.block2block.core.util.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Centralise les protections de gameplay : claims (break/place/interact),
 * freeze (immobilisation), prison (confinement) et god mode (immunite).
 * Priorite LOW pour s'executer avant les listeners de quete/log (qui
 * utilisent ignoreCancelled = true et doivent voir l'evenement deja annule
 * si la protection s'applique).
 */
public class ProtectionListener implements Listener {

    /** -1 = pas encore calcule (force une notification a la premiere verification). */
    private static final long UNCLAIMED = 0L;

    private final Block2Core plugin;
    /** Dernier claim connu par joueur (id du claim, 0 = zone libre), pour ne notifier qu'au changement de zone. */
    private final Map<UUID, Long> lastClaimId = new ConcurrentHashMap<>();

    public ProtectionListener(Block2Core plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // CLAIMS
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!canBuild(event.getPlayer(), event.getBlock().getChunk())) {
            event.setCancelled(true);
            notifyProtected(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!canBuild(event.getPlayer(), event.getBlock().getChunk())) {
            event.setCancelled(true);
            notifyProtected(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        // Mode inspection /co : prioritaire sur tout le reste, ne declenche jamais l'interaction normale
        if (plugin.getLogManager().isInspecting(player.getUniqueId())
                && (event.getAction() == Action.LEFT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_BLOCK)
                && event.getClickedBlock() != null) {
            event.setCancelled(true);
            plugin.getLogManager().inspectBlock(event.getClickedBlock(), entries -> {
                if (entries.isEmpty()) {
                    player.sendMessage(TextUtil.parse("<gray>Aucune modification enregistree sur ce bloc."));
                    return;
                }
                player.sendMessage(TextUtil.parse("<aqua><bold>--- Historique du bloc ---"));
                for (var entry : entries) {
                    player.sendMessage(TextUtil.parse("<gray>" + entry.playerName() + " <white>" + entry.action() +
                            " <gray>" + entry.blockType()));
                }
            });
            return;
        }

        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
        Block block = event.getClickedBlock();
        boolean sensitive = block.getState() instanceof InventoryHolder
                || isDoorLike(block.getType());
        if (!sensitive) return;

        if (!canBuild(event.getPlayer(), block.getChunk())) {
            event.setCancelled(true);
            notifyProtected(event.getPlayer());
        }
    }

    private boolean isDoorLike(Material material) {
        String name = material.name();
        return name.endsWith("_DOOR") || name.endsWith("_TRAPDOOR") || name.endsWith("_FENCE_GATE") || name.endsWith("_GATE");
    }

    private boolean canBuild(Player player, org.bukkit.Chunk chunk) {
        if (player.hasPermission("block2core.bypass.claim")) return true;
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        Integer teamId = data != null ? data.getTeamId() : null;
        return plugin.getClaimManager().canBuild(player.getUniqueId(), chunk, teamId);
    }

    private void notifyProtected(Player player) {
        player.sendMessage(TextUtil.parse("<red>Cette zone est protegee (claim)."));
    }

    // ---------------------------------------------------------------
    // FREEZE / PRISON
    // ---------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (event.getFrom().distanceSquared(event.getTo()) == 0) return;

        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data != null && data.isFrozen() && !player.hasPermission("block2core.bypass.freeze")) {
            event.setTo(event.getFrom());
            return;
        }

        if (plugin.getJailManager().isJailed(player.getUniqueId())) {
            var state = plugin.getJailManager().getState(player.getUniqueId());
            Location jailLoc = plugin.getJailManager().getJailLocation(state.jailName());
            int radius = plugin.getJailManager().getJailRadius(state.jailName());
            if (jailLoc != null && event.getTo().getWorld().equals(jailLoc.getWorld())
                    && event.getTo().distance(jailLoc) > radius) {
                event.setTo(event.getFrom());
            }
        }

        Chunk fromChunk = event.getFrom().getChunk();
        Chunk toChunk = event.getTo().getChunk();
        if (fromChunk.getX() != toChunk.getX() || fromChunk.getZ() != toChunk.getZ()
                || !fromChunk.getWorld().equals(toChunk.getWorld())) {
            notifyClaimChange(player, toChunk);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastClaimId.remove(event.getPlayer().getUniqueId());
    }

    /** /freeze est documente comme "immobile, sans commandes" : on bloque donc aussi toute commande. */
    @EventHandler(ignoreCancelled = true)
    public void onCommandWhileFrozen(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("block2core.bypass.freeze")) return;

        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data != null && data.isFrozen()) {
            event.setCancelled(true);
            player.sendMessage(TextUtil.parse("<red>Tu es fige par un membre du staff, tu ne peux pas utiliser de commandes."));
        }
    }

    /** Affiche en actionbar le territoire (claim/spawn protege/team/wilderness) quand le joueur change de chunk. */
    private void notifyClaimChange(Player player, Chunk newChunk) {
        ClaimChunk claim = plugin.getClaimManager().getClaim(newChunk);
        long claimId = claim != null ? claim.id() : UNCLAIMED;

        Long previous = lastClaimId.put(player.getUniqueId(), claimId);
        if (previous != null && previous == claimId) return; // meme zone qu'avant, rien a afficher

        Component message;
        if (claim == null) {
            message = TextUtil.parse("<gray>Zone libre");
        } else if (claim.unesco()) {
            message = TextUtil.parse("<gold><bold>⬥ Zone protegee (spawn / staff)");
        } else if (claim.owner() != null) {
            String ownerName = Bukkit.getOfflinePlayer(claim.owner()).getName();
            message = TextUtil.parse("<green>⬥ Territoire de <white>" + (ownerName != null ? ownerName : "?"));
        } else if (claim.teamId() != null) {
            PlayerTeam team = plugin.getTeamManager().getTeam(claim.teamId());
            message = TextUtil.parse("<aqua>⬥ Territoire de l'equipe <white>" + (team != null ? team.getName() : "?"));
        } else {
            message = TextUtil.parse("<gray>Zone libre");
        }
        player.sendActionBar(message);
    }

    // ---------------------------------------------------------------
    // GOD MODE
    // ---------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        PlayerData data = plugin.getPlayerData(player.getUniqueId());
        if (data != null && data.isGod()) {
            event.setCancelled(true);
        }
    }
}
