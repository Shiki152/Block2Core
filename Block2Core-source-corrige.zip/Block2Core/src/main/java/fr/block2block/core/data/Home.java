package fr.block2block.core.data;

import java.util.UUID;

public record Home(UUID owner, String name, String world, double x, double y, double z, float yaw, float pitch) {
}
