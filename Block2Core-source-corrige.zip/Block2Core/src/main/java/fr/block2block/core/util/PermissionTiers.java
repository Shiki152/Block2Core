package fr.block2block.core.util;

import fr.block2block.core.data.StaffRank;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Definit les permissions accordees automatiquement selon le grade staff
 * (via un PermissionAttachment applique au join, voir JoinQuitListener).
 * <p>
 * Cumulatif : un grade herite de toutes les permissions des grades inferieurs.
 * Cette repartition n'etait pas explicitement demandee dans le cahier des
 * charges (qui ne precise que les couleurs des grades staff) : c'est un choix
 * raisonnable pour eviter qu'un simple Helper puisse blacklist ou taper
 * /broadcast. Entierement modifiable ci-dessous ou via un plugin de
 * permissions classique (LuckPerms...), qui prendra toujours le dessus.
 */
public final class PermissionTiers {

    private static final Map<StaffRank, List<String>> ADDED_PER_TIER = new LinkedHashMap<>();

    static {
        ADDED_PER_TIER.put(StaffRank.HELPER, List.of(
                "block2core.staff",
                "block2core.command.staffchat",
                "block2core.command.stafflist",
                "block2core.command.invsee",
                "block2core.command.enderchest",
                "block2core.command.reports",
                "block2core.command.warn",
                "block2core.command.warnings",
                "block2core.command.delwarn",
                "block2core.command.clearwarns",
                "block2core.command.kick",
                "block2core.command.mute",
                "block2core.command.tempmute",
                "block2core.command.unmute",
                "block2core.command.freeze",
                "block2core.command.tp",
                "block2core.command.tphere",
                "block2core.command.back",
                "block2core.command.vanish",
                "block2core.command.history",
                "block2core.command.logs",
                "block2core.bypass.vanishsee",
                "block2core.bypass.freeze"
        ));
        ADDED_PER_TIER.put(StaffRank.STAFF, List.of(
                "block2core.command.tempban",
                "block2core.command.jail",
                "block2core.command.unjail",
                "block2core.command.heal",
                "block2core.command.feed",
                "block2core.command.god",
                "block2core.command.gm",
                "block2core.command.clear",
                "block2core.command.repair",
                "block2core.command.sudo",
                "block2core.command.mutechat",
                "block2core.command.unmutechat",
                "block2core.command.slowchat",
                "block2core.command.staffmode",
                "block2core.bypass.mutechat",
                "block2core.bypass.slowchat"
        ));
        ADDED_PER_TIER.put(StaffRank.MODERATEUR, List.of(
                "block2core.command.ban",
                "block2core.command.unban",
                "block2core.command.ipban",
                "block2core.command.unipban",
                "block2core.command.tppos",
                "block2core.command.tpall",
                "block2core.command.kill",
                "block2core.command.clearlag",
                "block2core.bypass.claim"
        ));
        ADDED_PER_TIER.put(StaffRank.ADMIN, List.of(
                "block2core.command.blacklist",
                "block2core.command.unblacklist",
                "block2core.command.broadcast",
                "block2core.command.unesco",
                "block2core.command.co",
                "block2core.command.b2c",
                "block2core.command.setwarp",
                "block2core.command.delwarp",
                "block2core.command.rank",
                "block2core.command.rank.set",
                "block2core.command.maintenance",
                "block2core.command.setspawn"
        ));
        ADDED_PER_TIER.put(StaffRank.OWNER, List.of(
                "block2core.command.staff",
                "block2core.*"
        ));
    }

    private PermissionTiers() {
    }

    /** Retourne la liste cumulee des permissions pour un grade staff donne (ou aucun grade = liste vide). */
    public static List<String> permissionsFor(StaffRank rank) {
        List<String> result = new ArrayList<>();
        if (rank == null) {
            return result;
        }
        for (StaffRank tier : StaffRank.values()) {
            result.addAll(ADDED_PER_TIER.getOrDefault(tier, List.of()));
            if (tier == rank) {
                break;
            }
        }
        return result;
    }
}
