package fr.block2block.core.commands.report;

import fr.block2block.core.Block2Core;
import fr.block2block.core.util.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReportCommand implements CommandExecutor {

    private final Block2Core plugin;

    public ReportCommand(Block2Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Commande reservee aux joueurs.");
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(TextUtil.parse("<yellow>Usage : /report <joueur> <raison>"));
            return true;
        }
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        plugin.getReportManager().create(player, args[0], reason);
        player.sendMessage(TextUtil.parse("<green>Signalement envoye au staff. Merci !"));
        return true;
    }
}
