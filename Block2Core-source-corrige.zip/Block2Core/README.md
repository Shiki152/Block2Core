# Block2Core

Plugin coeur du serveur **Block2BlockFr** pour Paper 1.21.8 / Java 21 : rankup, économie
(Block2Coins), kits, tutoriel, quêtes/titres, tab/scoreboard, aide en GUI, reports,
pack de modération complet (dont `/staffmode`), claims/teams/UNESCO, QOL/téléportation,
authentification (register/login, mode offline, support Bedrock/Floodgate).

Tout est stocké en SQLite (via HikariCP, aucun serveur externe requis) et le texte utilise Adventure/MiniMessage.

---

## 1. Prérequis

- **Java 21**
- **Maven 3.9+**
- Un serveur **Paper 1.21.8**
- **Vault** installé sur le serveur (dépendance obligatoire, `depend` dans plugin.yml)
- **PlaceholderAPI** installé (optionnel, `softdepend`) pour les placeholders `%block2core_*%`
  et `%server_online%` dans le tab/scoreboard
- **Aucune base de données externe requise** : le plugin utilise **SQLite** (un simple fichier
  `database.db` stocké dans `plugins/Block2Core/`), généré et géré automatiquement.
- Le serveur doit tourner en **`online-mode: false`** (server.properties). C'est indispensable
  pour accepter à la fois les comptes premium et non-premium : dans ce mode Mojang ne peut
  garantir l'identité d'un pseudo, d'où le système `/register` `/login` maison (mot de passe
  hashé en SHA-256 + sel aléatoire, stocké dans `b2c_auth`).

## 2. Compilation

### Option A — en local (nécessite Java 21 + Maven + accès internet)

```bash
mvn clean package
```

Le jar final auto-suffisant est généré dans `target/Block2Core-1.0.0.jar`
(HikariCP + driver SQLite sont embarqués dans le jar ; Paper API / Vault / PlaceholderAPI
restent `provided`, fournis par le serveur).

### Option B — via GitHub Actions (si tu n'as pas Maven/JDK sous la main)

Un workflow est fourni dans `.github/workflows/build.yml`. Pousse ce projet dans un dépôt
GitHub (public ou privé) : le jar compilé est automatiquement produit et disponible en
téléchargement dans l'onglet **Actions** de ton dépôt (artifact `Block2Core-jar`), sans
rien installer sur ta machine.

> **Important** : ce projet a été généré sans accès réseau (sandbox sans accès à Maven
> Central / repo.papermc.io / JitPack) et sans JDK complet (seulement un JRE, `javac`
> indisponible), donc **je n'ai pas pu compiler le jar moi-même** ni même faire une
> vérification syntaxique avec javac. Le code a été relu ligne par ligne et vérifié avec des
> passes automatiques (équilibre des accolades, cohérence des packages/imports/méthodes
> appelées), mais lance une des deux options ci-dessus et renvoie-moi le message d'erreur
> exact si la compilation échoue quelque part : je corrige immédiatement.

## 3. Installation

1. Place `Block2Core-1.0.0.jar` dans `plugins/`
2. Démarre le serveur une fois pour générer `plugins/Block2Core/config.yml` et le fichier
   `plugins/Block2Core/database.db` (SQLite, aucune configuration necessaire)
3. Renseigne les liens dans `info.*` (discord/don/youtube/site)
4. Redémarre / `/reload confirm` (ou redémarrage complet recommandé)

## 4. Structure du projet

```
fr.block2block.core
├── Block2Core.java          # classe principale, initialise tout
├── config/                  # ConfigManager (accès typé à config.yml)
├── database/                # DatabaseManager (HikariCP + schema SQLite)
├── data/                    # modèles (records/enums) : Grade, StaffRank, Kit, Home...
├── managers/                # logique métier (18 managers, 1 par système)
├── commands/                # exécuteurs de commandes, regroupés par thème
├── listeners/                # écouteurs d'évènements Bukkit
├── gui/                     # Help / Shop / InvSee (inventaires personnalisés)
├── placeholder/             # extension PlaceholderAPI
└── util/                    # TextUtil (MiniMessage), TimeUtil, ItemBuilder, PermissionTiers
```

## 5. Décisions de conception (zones non précisées dans le cahier des charges)

Le cahier des charges était très détaillé mais laissait quelques zones ouvertes. Voici les
choix faits, tous ajustables :

- **Grade staff vs grade joueur dans le chat** : le format de chat n'a qu'un seul
  emplacement de "grade". Si le joueur a un grade staff, c'est celui-ci qui s'affiche
  (couleur staff) à la place du grade joueur ; sinon c'est le grade joueur normal.
- **Attribution des grades staff** : le cahier des charges ne donnait pas de commande
  équivalente à `/rank set` pour les grades staff. J'ai ajouté `/staff set <joueur> <grade>`
  (permission `block2core.command.staff`, réservée Owner par défaut).
- **Permissions par grade staff** : la répartition Helper→Owner des ~45 commandes de
  modération n'était pas détaillée (seules les couleurs l'étaient). Une hiérarchie cumulative
  raisonnable est appliquée automatiquement (voir `util/PermissionTiers.java`), entièrement
  modifiable dans ce fichier ou surchargeable via un plugin de permissions classique.
- **Économie/Vault** : Block2Core s'enregistre lui-même comme fournisseur `Economy` de Vault
  (aucun autre plugin d'économie n'est nécessaire). Le coût de rankup est payé dans la même
  monnaie Block2Coins que la boutique.
- **Contenu de la boutique `/shop`** : non précisé dans le cahier des charges, un catalogue
  d'exemple fonctionnel est fourni dans `gui/ShopGUI.java` (facile à adapter, section `OFFERS`).
- **`/coinflip <mise>`** : un seul joueur contre "la banque" (50/50), pas de duel PvP (la
  syntaxe donnée n'incluait pas de second joueur).
- **Étape "/home set" et "/team create" du tutoriel** : interprétées comme les vraies commandes
  implémentées `/sethome` et `/team create <nom> <cout>`.
- **`/co` (inspecteur de blocs)** : implémente inspection (clic), recherche (`lookup`) et un
  rollback simplifié (restaure les blocs modifiés dans un rayon/une période). Ce n'est pas un
  clone complet de CoreProtect (diff/tree de rollback avancé), mais c'est fonctionnel pour de
  l'usage courant.
- **Claims d'équipe** : limite = `grade_level_du_owner × teams.claims-multiplier` (config,
  séparée de la limite personnelle des joueurs), pool indépendant des claims personnels.
- **UNESCO** : traité comme une protection permanente admin-only (aucun propriétaire), non
  supprimable via `/unclaim` sauf permission `block2core.command.unesco`.
- **Stockage SQLite au lieu de MySQL** : le cahier des charges initial demandait explicitement
  du MySQL, mais le plugin a été basculé sur **SQLite** à la demande de l'utilisateur (accès
  MySQL indisponible sur son hébergement). Toutes les requêtes ont été portées en syntaxe
  SQLite (`INSERT ... ON CONFLICT DO UPDATE`, `INSERT OR IGNORE`, `INTEGER PRIMARY KEY
  AUTOINCREMENT`, index créés séparément). Le pool HikariCP est volontairement limité à une
  connexion (SQLite = un seul écrivain à la fois), avec le mode WAL activé pour fluidifier les
  accès concurrents malgré tout.
- **Annonces chat + écrans de sanction** : ban/tempban/mute/tempmute/kick/ipban/blacklist
  diffusent maintenant un message dans le chat serveur (`sanctions-broadcast` dans config.yml)
  et affichent un écran multi-lignes formaté (`sanctions-screens`), entièrement personnalisable.
  Les warns et les levées de sanction (unban/unmute...) restent silencieux (pas de diffusion),
  jugé plus cohérent avec l'usage habituel sur la plupart des serveurs.
- **Mode maintenance (`/maintenance`)** : ajouté a posteriori (non present dans le cahier des
  charges initial). `/maintenance [on|off]` bloque la connexion a tous sauf : les OP, les
  membres du staff (grade staff en base), et les pseudos ajoutes via
  `/maintenance whitelist add|remove|list <joueur>`.
- **`/setspawn`** : ajoute pour permettre un spawn personnalise (independant du spawn vanilla
  du monde). `/spawn` utilise ce point s'il est defini, sinon retombe sur le spawn du monde.
  La zone (3x3 chunks) autour du spawn actif est automatiquement protegee en UNESCO.
- **Liens cliquables** : tous les liens affiches (/discord /don /youtube /site, ecrans
  de sanction) utilisent les balises MiniMessage `<click:open_url:...>` + une infobulle
  "Cliquer pour ouvrir".

## 6. Base de données

19 tables créées automatiquement au démarrage (`b2c_players`, `b2c_auth`, `b2c_homes`,
`b2c_warps`, `b2c_claims`, `b2c_trust`, `b2c_teams`, `b2c_team_members`, `b2c_kit_cooldowns`,
`b2c_punishments`, `b2c_reports`, `b2c_quests`, `b2c_quest_progress`, `b2c_titles_unlocked`,
`b2c_ignores`, `b2c_block_logs`, `b2c_jails_active`, `b2c_staffmode`, `b2c_action_logs`). Voir
`database/DatabaseManager.java` pour le schéma complet.

Tout est stocké dans un unique fichier `plugins/Block2Core/database.db` (SQLite, mode WAL
activé). Pour sauvegarder les données du serveur, il suffit de copier ce fichier (ainsi que
les fichiers `database.db-wal` et `database.db-shm` s'ils existent) **serveur arrêté**, ou
via un outil de backup compatible SQLite pris à chaud. Aucun identifiant, mot de passe ou
port réseau à gérer.

## 7. Notes complémentaires

- Toutes les opérations SQLite sont **asynchrones** (HikariCP + `Bukkit.getScheduler()`),
  jamais bloquantes sur le thread principal, sauf au tout premier démarrage (test de connexion).
- Les recommandes de vérification de bannissement (`AsyncPlayerPreLoginEvent`) s'exécutent
  déjà hors thread principal : les requêtes SQL y sont donc directement bloquantes (pas besoin
  de ré-asynchroniser), c'est le comportement normal/attendu pour cet évènement Bukkit.
- Le tri du tab list par grade utilise le classique système de scoreboard teams nommées avec
  un préfixe numérique (`0_owner`, `1_admin`, ... `9_paysan`), qui colore aussi les pseudos.

## 8. Audit complet (bugs corrigés)

Une relecture intégrale du plugin a été faite à la demande de l'utilisateur. Bugs réels trouvés
et corrigés :

- **Exploit budget de vol Master** : le budget quotidien (30min/jour) n'était jamais sauvegardé
  en base, un simple `/relog` redonnait 30 minutes fraîches à volonté. Persisté désormais
  (toutes les 10s en vol + à la déconnexion + à chaque reset quotidien).
- **`/unclaim` sur un claim de team** : n'importe quel joueur (même hors de la team) pouvait
  libérer un chunk appartenant à une équipe. Corrigé : seuls les membres de la team (ou un
  admin) peuvent le faire.
- **`team_id` jamais mis à jour** : la colonne `b2c_players.team_id` n'était jamais écrite,
  donc l'appartenance à une équipe se "perdait" en mémoire après chaque reconnexion (chat
  d'équipe, permissions de build dans les claims de team...). Chargé désormais depuis la vraie
  source de vérité (`b2c_team_members`, déjà correctement tenue à jour par ailleurs).
- **Remboursement `/team create`** : si la création échouait en base après le retrait des
  Block2Coins, l'argent était perdu sans création de team. Remboursement automatique ajouté.
- **Équipes dissoutes = claims fantômes** : quand une équipe disparaissait (dernier membre
  qui quitte), ses claims restaient bloqués indéfiniment. Libérés automatiquement désormais.
- **Bug de casse répété** : `/rank info`, `/unipban`, `/co lookup <joueur>` et `/logs <joueur>`
  échouaient silencieusement si la casse du pseudo ne correspondait pas exactement (même
  famille de bug que celui déjà corrigé pour `/mute`). Toutes les recherches par pseudo sont
  désormais insensibles à la casse / préfèrent le joueur en ligne s'il y en a un.
- **Tutoriel `/claim` qui matchait `/claims`** : la détection de progression du tuto utilisait
  un simple `startsWith`, donc taper `/claims list` validait par erreur l'étape "claim".
  Remplacé par une comparaison mot-par-mot.
- **Prison non persistée** : un redémarrage du serveur libérait silencieusement tous les
  joueurs emprisonnés. Les emprisonnements actifs sont maintenant sauvegardés en base et
  restaurés au démarrage.
- **Permission de bypass RTP incohérente** : le cooldown de `/rtp` vérifiait la permission
  `block2core.bypass.freeze` (sans rapport). Remplacé par un bypass staff cohérent.
- **Accès aux kits pour le staff** : `/kit` ne regardait que le grade *joueur*, pas le statut
  staff — un admin resté "Paysan" côté grade joueur n'avait accès qu'au kit Paysan. Le staff a
  désormais accès à tous les kits, quel que soit son grade joueur nominal.
- **Croissance illimitée des caches mémoire** : plusieurs `Map` internes (positions `/back`,
  cibles `/reply`, demandes `/tpa`, cooldowns `/rtp`, invitations d'équipe, compteurs
  `/slowchat`) grossissaient indéfiniment sans jamais être nettoyées. Un nouveau
  `CacheCleanupManager` purge tout ça périodiquement (configurable, `cache-cleanup:` dans
  config.yml), et purge aussi les vieilles entrées des tables de logs (`log-retention-days`,
  30 jours par défaut) pour éviter que le fichier SQLite ne grossisse indéfiniment.

## 9. Deuxième audit (relecture complète du dépôt fourni)

Relecture intégrale des 77 fichiers Java, de `config.yml`, `plugin.yml`, `pom.xml` et du
workflow GitHub Actions, sans accès réseau donc sans compilation réelle possible (relecture
manuelle fichier par fichier, avec vérification croisée systématique de chaque appel de
méthode contre sa définition). Résultat :

**🔴 Bug bloquant la compilation, corrigé :**
- `ClaimManager.protectSpawnChunks()` et `TeleportQolCommand` (`/spawn`, `/setspawn`)
  appelaient `ConfigManager.getCustomSpawn()` / `setCustomSpawn()` / `hasCustomSpawn()`, qui
  n'existaient nulle part dans `ConfigManager.java`. Le build GitHub Actions aurait
  immédiatement échoué. Les trois méthodes ont été ajoutées (persistance dans `config.yml`
  sous `spawn.custom.*`), sans rien changer au comportement déjà prévu par ces deux
  appelants (protection UNESCO 3x3 chunks autour du spawn personnalisé).

**🔴 Failles de sécurité, corrigées :**
- **Permissions staff accordées au join, avant authentification.** `JoinQuitListener`
  appelait `applyStaffPermissions()` dès la connexion, sans attendre `/login` — exactement ce
  que le cahier des charges demande d'éviter, puisque le serveur tourne en mode offline
  (n'importe qui peut se connecter sous un pseudo staff tant qu'il ne prouve pas son
  identité). Les permissions sont désormais accordées uniquement après une authentification
  réussie (`AuthManager.finalizeAuthentication()`, appelé depuis `/register`, `/login` et
  l'auto-authentification Bedrock).
- **`/rank set` accessible à tous.** La sous-commande vérifiait `block2core.command.rank`,
  accordée à tout le monde par défaut (pour `/rankup`, `/rank info`, `/rank top`) —
  n'importe quel joueur pouvait donc s'auto-promouvoir Partenaire. Nouvelle permission dédiée
  `block2core.command.rank.set`, réservée Admin+.
- **`/quest admin create` accessible à tous.** Même bug exact sur `block2core.command.quest`
  (accordée à tous pour la consultation des quêtes). Nouvelle permission dédiée
  `block2core.command.quest.admin`, réservée Admin+.
- **Aucune protection anti-bruteforce sur `/login`.** Un mot de passe pouvait être testé
  indéfiniment. Expulsion automatique ajoutée après `auth.max-login-attempts` échecs (5 par
  défaut, configurable).
- **Verrouillage pré-connexion incomplet.** Seuls le mouvement, les commandes et les dégâts
  étaient bloqués avant authentification. Étendu à la casse/pose de blocs, aux interactions
  (blocs et entités), aux clics d'inventaire, au drop d'objets et au changement d'objet en
  main.
- **Aucune alerte en cas de connexion non authentifiée sur un compte staff.** Ajoutée : tout
  le staff en ligne est prévenu dès qu'un compte possédant un grade staff se connecte sans
  encore avoir validé `/login`.

**🟠 Fonctionnalités du cahier des charges absentes du code, implémentées :**
- **`/staffmode`** n'existait nulle part (ni commande, ni logique, ni table SQL) malgré sa
  présence dans le cahier des charges. Implémenté intégralement : bascule survie ↔ créatif,
  inventaire de survie sauvegardé en base (nouvelle table `b2c_staffmode`, sérialisation via
  `BukkitObjectOutputStream`) avant même d'être vidé, restauration automatique à la
  reconnexion authentifiée si le joueur s'est déconnecté (crash ou `/quit`) sans avoir
  désactivé le mode staff.
- **Support Bedrock/Floodgate** totalement absent. Ajouté via une nouvelle classe
  `BedrockSupport`, détection par réflexion (Floodgate en softdepend, aucune dépendance
  obligatoire) : authentification automatique des joueurs Bedrock au join.
- **`/freeze` ne bloquait pas les commandes**, contrairement à sa description dans
  `plugin.yml` ("immobile, sans commandes"). Blocage des commandes ajouté (sauf pour les
  détenteurs de `block2core.bypass.freeze`).

**🟢 Autres corrections :**
- Dernières occurrences visibles joueur de « B2C » remplacées par « Block2Coins » dans
  `B2CAdminCommand` (`/b2c top`, `/b2c give`, `/b2c take`, `/b2c set`).

**🗑️ Retiré à la demande de l'utilisateur :** la commande `/vote` (et tout ce qui s'y
rattachait : permission, section `vote:` de `config.yml`, entrée dans le GUI `/help` et dans
le fallback console de `/help`) a été entièrement supprimée.

Comme pour le premier audit, aucune compilation réelle n'a été possible (pas d'accès réseau
pour Maven dans cet environnement) : chaque modification a été vérifiée par relecture croisée
manuelle de tous ses appelants/appelés, plus une validation de la syntaxe YAML de
`plugin.yml`/`config.yml` et un contrôle d'équilibre des accolades/parenthèses sur les 79
fichiers Java du projet. Il est recommandé de laisser GitHub Actions confirmer la compilation
au premier push.
